function T = make_recoil_table_from_PSTAR_v3()
% make_recoil_table_from_PSTAR_v3
% Version 3:
%   - Adds delta_R for recoils: delta_R = (pi/2 - theta_R), reported in mrad
%   - Uses recoil kinematics consistent with small-|t| fixed-target pp elastic scattering:
%       p_perp = sqrt(|t|),  p_par = |t|/(2*p_beam)
%       delta_R = atan2(p_par, p_perp),  theta_R = pi/2 - delta_R
%   - Fixes the "Transverse extent" printout to use delta_R (near-90° geometry)
%
% Reads: PSTAR_stopping_power_protons-in-Si.dat
% File format (as provided):
%   Kinetic Energy [MeV]   CSDA Range [g/cm^2]
%
% Produces a recoil-proton table for elastic pp recoil in CNI:
%   TR = |t|/(2 mp), p = sqrt(TR(TR+2 mp))
% and interpolates the CSDA range in Si for each TR.
%
% Output:
%   - prints a table to the command window
%   - prints key kinematic parameters for both beam energies
%   - returns a MATLAB table variable T

clc;

%% --- User inputs ---
fname = 'PSTAR_stopping_power_protons-in-Si.dat';

% Representative |t| values in (GeV/c)^2 (edit as needed)
t_vals = [1e-3, 2e-3, 3e-3, 5e-3, 1e-2, 1.5e-2, 2e-2, 3e-2];

% Detector distance (radial) for TOF / extent examples
x_det_m = 0.220;  % 220 mm

% Beam energies (TOTAL energies) [GeV]
E_beam_low  = 23.5;   % injection
E_beam_high = 275.0;  % flattop

%% --- Constants ---
mp_GeV = 0.938272088;     % proton mass [GeV/c^2]
c      = 299792458;       % [m/s]
rho_Si = 2.329;           % silicon density [g/cm^3]

%% --- Print fixed-target beam kinematics (for reference) ---
fprintf('========================================================================\n');
fprintf('Fixed-Target pp Elastic Scattering Kinematics\n');
fprintf('========================================================================\n\n');

kin_low  = calc_fixed_target_kinematics(E_beam_low,  mp_GeV);
kin_high = calc_fixed_target_kinematics(E_beam_high, mp_GeV);

print_kinematics(sprintf('E_beam = %.1f GeV (injection)', E_beam_low), kin_low);
fprintf('\n');
print_kinematics(sprintf('E_beam = %.0f GeV (flattop)',   E_beam_high), kin_high);

fprintf('\n========================================================================\n\n');

%% --- Read PSTAR file (robustly skip header) ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);

% Convert CSDA range to equivalent thickness in Si:
%   R[g/cm^2] = rho[g/cm^3] * x[cm]  => x[cm] = R/rho
R_cm  = R_gcm2 ./ rho_Si;
R_um  = 1e4 * R_cm;  % 1 cm = 1e4 um

%% --- Recoil kinematics from |t| (target recoil) ---
TR_GeV = t_vals ./ (2*mp_GeV);         % [GeV]
TR_MeV = TR_GeV * 1e3;                 % [MeV]

pR_GeV = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));  % [GeV/c]
pR_MeV = pR_GeV * 1e3;                          % [MeV/c]

% beta from kinetic energy: gamma = 1 + TR/mp
gammaR = 1 + (TR_GeV ./ mp_GeV);
betaR  = sqrt(1 - 1./(gammaR.^2));

% TOF to detector (straight-line estimate; field-bending can be added later)
tof_s  = x_det_m ./ (betaR*c);
tof_ns = tof_s * 1e9;

%% --- Interpolate CSDA range at TR ---
Rinterp_um = interp1(E_MeV, R_um, TR_MeV, 'pchip', 'extrap');

%% --- Recoil angular variables for fixed-target geometry ---
% We define:
%   delta_R = (pi/2 - theta_R), in mrad,
% where theta_R is the lab recoil angle w.r.t. the beam axis.
%
% For small-|t| elastic scattering off a stationary proton:
%   p_perp = sqrt(|t|),  p_par = |t|/(2*p_beam),
%   delta_R = atan2(p_par, p_perp),  theta_R = pi/2 - delta_R.
%
% This yields delta_R in the few–tens of mrad range (near-90° recoil),
% which is the useful quantity for detector footprint at radius L.

delta_low_mrad  = zeros(size(t_vals));
delta_high_mrad = zeros(size(t_vals));

theta_low_mrad  = zeros(size(t_vals));   % kept for completeness (near 90°)
theta_high_mrad = zeros(size(t_vals));

for i = 1:numel(t_vals)
    [delta_low_mrad(i),  theta_low_mrad(i)]  = calc_recoil_delta_theta_fixed_target(t_vals(i), kin_low);
    [delta_high_mrad(i), theta_high_mrad(i)] = calc_recoil_delta_theta_fixed_target(t_vals(i), kin_high);
end

%% --- Build table ---
T = table();
T.t_GeV2               = t_vals(:);
T.TR_MeV               = TR_MeV(:);
T.p_MeVc               = pR_MeV(:);
T.beta                 = betaR(:);

% User-requested quantity: deviation from 90°
T.delta_R_23GeV_mrad    = delta_low_mrad(:);
T.delta_R_275GeV_mrad   = delta_high_mrad(:);

T.tof_ns_220mm          = tof_ns(:);
T.CSDA_um_Si            = Rinterp_um(:);

disp('Recoil table (from PSTAR CSDA range in Si) with recoil delta_R:');
disp(T);
%% --- Detector footprint / transverse extent (no B-field) ---
% For a detector at radius r_det from the target (perpendicular to beam),
% the displacement along beam-direction on that detector plane is:
%   z ≈ r_det * tan(delta_R),
% where delta_R = (pi/2 - theta_R) is the deviation from 90°.
r_det_mm = x_det_m * 1e3;

delta_low_rad  = delta_low_mrad  * 1e-3;
delta_high_rad = delta_high_mrad * 1e-3;

delta_z_low_mm  = r_det_mm * abs(tan(delta_low_rad(end))  - tan(delta_low_rad(1)));
delta_z_high_mm = r_det_mm * abs(tan(delta_high_rad(end)) - tan(delta_high_rad(1)));

fprintf('\nExtent of CNI region on detector surface (no B-field) at r = %.0f mm:\n', r_det_mm);
fprintf('  At E_beam = %.1f GeV: Δz ≈ %.1f mm (delta %.2f to %.2f mrad)\n', ...
    E_beam_low,  delta_z_low_mm,  delta_low_mrad(1),  delta_low_mrad(end));
fprintf('  At E_beam = %.0f GeV: Δz ≈ %.1f mm (delta %.2f to %.2f mrad)\n', ...
    E_beam_high, delta_z_high_mm, delta_high_mrad(1), delta_high_mrad(end));

%% --- Write CSV (optional) ---
writetable(T, 'recoil_table_from_PSTAR_v3.csv');
fprintf('\nTable saved to: recoil_table_from_PSTAR_v3.csv\n');

end

%% =======================================================================
function kin = calc_fixed_target_kinematics(E_beam_GeV, mp_GeV)
% Kinematic parameters for a fixed-target pp collision (beam on stationary proton).
% Inputs:
%   E_beam_GeV : total beam energy [GeV]
%   mp_GeV     : proton mass [GeV/c^2]
% Output:
%   kin struct

kin.E_beam = E_beam_GeV;
kin.mp     = mp_GeV;

% Beam momentum
kin.p_beam = sqrt(E_beam_GeV^2 - mp_GeV^2);

% Beam gamma and beta
kin.gamma_beam = E_beam_GeV / mp_GeV;
kin.beta_beam  = kin.p_beam / E_beam_GeV;

% Mandelstam s for fixed target: s = m^2 + m^2 + 2 m E_beam = 2 m (m + E_beam)
kin.s      = 2 * mp_GeV * (mp_GeV + E_beam_GeV);
kin.sqrt_s = sqrt(kin.s);

end

%% =======================================================================
function print_kinematics(title_str, kin)
fprintf('%s:\n', title_str);
fprintf('  Beam energy (total):     E_beam = %.2f GeV\n', kin.E_beam);
fprintf('  Beam momentum:           p_beam = %.2f GeV/c\n', kin.p_beam);
fprintf('  Beam Lorentz factor:     γ_beam = %.2f\n', kin.gamma_beam);
fprintf('  Beam velocity:           β_beam = %.6f\n', kin.beta_beam);
fprintf('  CM energy:               √s = %.3f GeV\n', kin.sqrt_s);
end

%% =======================================================================
function [delta_mrad, theta_mrad] = calc_recoil_delta_theta_fixed_target(t_GeV2, kin)
% Recoil angular variables in the lab for small-|t| pp elastic scattering (fixed target).
%
% Define:
%   p_perp = sqrt(|t|)
%   p_par  = |t|/(2 p_beam)
% Then:
%   delta = atan2(p_par, p_perp)  = (pi/2 - theta)
%   theta = pi/2 - delta
%
% Outputs:
%   delta_mrad : deviation from 90° [mrad]
%   theta_mrad : lab recoil angle w.r.t. beam axis [mrad] (near 90°)

p_beam = kin.p_beam;          % [GeV/c]
p_perp = sqrt(t_GeV2);        % [GeV/c]
p_par  = t_GeV2 / (2*p_beam); % [GeV/c]

delta_rad = atan2(p_par, p_perp);
theta_rad = (pi/2) - delta_rad;

delta_mrad = delta_rad * 1e3;
theta_mrad = theta_rad * 1e3;
end

%% =======================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads PSTAR file numeric lines with:
%   Energy(MeV)  Range(g/cm^2)
if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end

fid = fopen(fname,'r');
if fid < 0
    error('Could not open %s', fname);
end

E = [];
R = [];

while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end

    ln = strtrim(ln);
    if isempty(ln), continue; end

    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end

fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end

% Ensure monotonic energy for interpolation
[E_MeV, idx] = sort(E);
R_gcm2 = R(idx);

end
