function R = toyMC_run_v1()
% toyMC_run_v1.m
%
% Toy MC for bunch association using machine t0, bunch spacing tau_b,
% and recoil energy TR to predict t_TOF. Self contained, no external files.
%
% Usage:
%   R = toyMC_run_v1();
%
% Output:
%   R is a struct with parameters, binned performance vs |t|, and summaries.

clc;

% -------------------- Parameters --------------------
P = params_v1();

rng(P.rngSeed);

fprintf('\nToy MC v1\n');
fprintf('  Nevents            = %d\n', P.Nevents);
fprintf('  |t| range           = [%.3g, %.3g] (GeV/c)^2\n', P.t_min_GeV2, P.t_max_GeV2);
fprintf('  tau_b              = %.6f ns\n', P.tau_b_ns);
fprintf('  sigma_bunch (rms)  = %.6f ns\n', P.sigma_bunch_ns);
fprintf('  L_path model       = %.3f mm (straight)\n', P.L_path_mm);
fprintf('  nmax tested        = %d\n', P.nmax);

% -------------------- Generate truth --------------------
T = generate_events_v1(P);

% -------------------- Run scenarios --------------------
R = struct();
R.P = P;
R.truth = rmfield(T, {'phi_rad'});  % keep it small, phi not used in v1

R.scenarios = struct([]);
for is = 1:numel(P.sigma_det_ns_list)
    sigma_det_ns = P.sigma_det_ns_list(is);

    M = smear_measurements_v1(P, T, sigma_det_ns);
    A = assign_bunch_v1(P, M);

    S = summarize_vs_t_v1(P, T, A);

    R.scenarios(is).sigma_det_ns = sigma_det_ns;
    R.scenarios(is).assign = A;
    R.scenarios(is).summary = S;

    fprintf('\nScenario: sigma_det = %.3f ns\n', sigma_det_ns);
    fprintf('  Correct fraction   = %.4f\n', S.frac_correct_all);
    fprintf('  Ambiguous fraction = %.4f\n', S.frac_ambiguous_all);
    fprintf('  Wrong fraction     = %.4f\n', S.frac_wrong_all);
    fprintf('  Unassigned fraction= %.4f\n', S.frac_unassigned_all);
end

% -------------------- Plots --------------------
make_plots_v1(P, R);

fprintf('\nDone.\n');

end

% =====================================================================
% Parameters
% =====================================================================
function P = params_v1()

P = struct();

% Physics constants
P.mp_MeV = 938.2720813;     % proton mass
P.c_mps  = 299792458;

% Event generation
P.Nevents     = 1000000;     % start modest, increase later
P.t_min_GeV2  = 1e-3;
P.t_max_GeV2  = 2e-2;

% Timing and bunch structure (EIC flattop example)
P.tau_b_ns        = 11.027;   % bunch spacing
P.sigma_bunch_ns  = 0.200;    % rms bunch time width (Table II style number)

% Geometry, straight path model for v1
P.L_path_mm = 220.0;

% Detector resolution scenarios
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Energy measurement model (toy)
% Use either relative TR resolution or absolute. Keep only one active.
P.use_TR_rel_smear = true;
P.sigma_TR_rel     = 0.03;     % 3 percent rms on TR
P.sigma_TR_MeV     = 0.20;     % used only if use_TR_rel_smear = false

% Bunch assignment search and consistency window
P.nmax        = 5;            % test n = 0..nmax
P.window_k    = 3.0;          % acceptance if |residual| < k * sigma_eff
P.sigma_model_ns = 0.0;       % extra model uncertainty, set later if needed

% Binning for performance vs |t|
P.t_edges_GeV2 = linspace(P.t_min_GeV2, P.t_max_GeV2, 9);

% Random seed
P.rngSeed = 1;

end

% =====================================================================
% Event generation (truth)
% =====================================================================
function T = generate_events_v1(P)

N = P.Nevents;

% Sample |t| and phi (phi not used in v1, kept for later)
t_GeV2  = P.t_min_GeV2 + (P.t_max_GeV2 - P.t_min_GeV2) * rand(N,1);
phi_rad = 2*pi*rand(N,1);

% TR from |t|: |t| ≃ 2 m_p T_R
mp_GeV = P.mp_MeV * 1e-3;
TR_GeV = t_GeV2 ./ (2*mp_GeV);
TR_MeV = TR_GeV * 1e3;

% Relativistic recoil momentum from TR
E_MeV  = P.mp_MeV + TR_MeV;
p_MeVc = sqrt(max(E_MeV.^2 - P.mp_MeV^2, 0));
beta   = p_MeVc ./ E_MeV;

% Straight path time of flight
L_m = P.L_path_mm * 1e-3;
tTOF_s  = L_m ./ (beta * P.c_mps);
tTOF_ns = 1e9 * tTOF_s;

% True integer offset set by the actual TOF relative to tau_b
n_true = floor(tTOF_ns ./ P.tau_b_ns);

T = struct();
T.t_GeV2   = t_GeV2;
T.phi_rad  = phi_rad;
T.TR_MeV   = TR_MeV;
T.p_MeVc   = p_MeVc;
T.beta     = beta;
T.tTOF_ns  = tTOF_ns;
T.n_true   = n_true;

end

% =====================================================================
% Smearing (measured quantities)
% =====================================================================
function M = smear_measurements_v1(P, T, sigma_det_ns)

N = numel(T.t_GeV2);

% Machine reference time per crossing (relative), smeared by bunch length
t0_true_ns = zeros(N,1);
t0_meas_ns = t0_true_ns + P.sigma_bunch_ns * randn(N,1);

% True detector hit time, wrapped into the observed window by subtracting n*tau_b
tHit_true_ns = t0_true_ns + T.tTOF_ns - T.n_true .* P.tau_b_ns;

% Detector time measurement
tHit_meas_ns = tHit_true_ns + sigma_det_ns * randn(N,1);

% Measured Delta t
Delta_ns = tHit_meas_ns - t0_meas_ns;

% Energy measurement
if P.use_TR_rel_smear
    TR_meas_MeV = T.TR_MeV .* (1 + P.sigma_TR_rel * randn(N,1));
else
    TR_meas_MeV = T.TR_MeV + P.sigma_TR_MeV * randn(N,1);
end
TR_meas_MeV = max(TR_meas_MeV, 0);

% Predicted beta and TOF from measured TR
E_meas_MeV  = P.mp_MeV + TR_meas_MeV;
p_meas_MeVc = sqrt(max(E_meas_MeV.^2 - P.mp_MeV^2, 0));
beta_meas   = p_meas_MeVc ./ max(E_meas_MeV, 1e-12);

L_m = P.L_path_mm * 1e-3;
tTOF_pred_ns = 1e9 * (L_m ./ (beta_meas * P.c_mps));

M = struct();
M.sigma_det_ns  = sigma_det_ns;
M.t0_meas_ns    = t0_meas_ns;
M.tHit_meas_ns  = tHit_meas_ns;
M.Delta_ns      = Delta_ns;
M.TR_meas_MeV   = TR_meas_MeV;
M.tTOF_pred_ns  = tTOF_pred_ns;

end

% =====================================================================
% Bunch assignment
% =====================================================================
function A = assign_bunch_v1(P, M)

N = numel(M.Delta_ns);

n_best      = nan(N,1);
is_assigned = false(N,1);
is_ambig    = false(N,1);

% Consistency window
sigma_eff_ns = sqrt(M.sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);
W_ns = P.window_k * sigma_eff_ns;

% Test candidate n = 0..nmax
n_test = (0:P.nmax);
Rmat = zeros(N, numel(n_test));  % residuals

for k = 1:numel(n_test)
    n = n_test(k);
    Rmat(:,k) = (M.Delta_ns + n*P.tau_b_ns) - M.tTOF_pred_ns;
end

pass = abs(Rmat) < W_ns;

for i = 1:N
    idx = find(pass(i,:));
    if isempty(idx)
        continue;
    end
    is_assigned(i) = true;
    if numel(idx) > 1
        is_ambig(i) = true;
    end
    [~,jmin] = min(abs(Rmat(i,idx)));
    n_best(i) = n_test(idx(jmin));
end

A = struct();
A.n_best      = n_best;
A.is_assigned = is_assigned;
A.is_ambig    = is_ambig;
A.W_ns        = W_ns;
A.sigma_eff_ns = sigma_eff_ns;

end

% =====================================================================
% Summary vs |t|
% =====================================================================
function S = summarize_vs_t_v1(P, T, A)

N = numel(T.t_GeV2);

is_unassigned = ~A.is_assigned;
is_wrong = A.is_assigned & (A.n_best ~= T.n_true);
is_correct = A.is_assigned & (A.n_best == T.n_true);
is_ambig = A.is_assigned & A.is_ambig;

S = struct();
S.frac_correct_all    = mean(is_correct);
S.frac_wrong_all      = mean(is_wrong);
S.frac_ambiguous_all  = mean(is_ambig);
S.frac_unassigned_all = mean(is_unassigned);

edges = P.t_edges_GeV2(:);
nb = numel(edges) - 1;

S.t_bin_center = zeros(nb,1);
S.Nbin         = zeros(nb,1);
S.frac_correct = zeros(nb,1);
S.frac_wrong   = zeros(nb,1);
S.frac_ambig   = zeros(nb,1);
S.frac_unass   = zeros(nb,1);

for b = 1:nb
    inb = (T.t_GeV2 >= edges(b)) & (T.t_GeV2 < edges(b+1));
    nbN = sum(inb);
    S.Nbin(b) = nbN;
    S.t_bin_center(b) = 0.5*(edges(b)+edges(b+1));
    if nbN == 0
        S.frac_correct(b) = nan;
        S.frac_wrong(b)   = nan;
        S.frac_ambig(b)   = nan;
        S.frac_unass(b)   = nan;
    else
        S.frac_correct(b) = mean(is_correct(inb));
        S.frac_wrong(b)   = mean(is_wrong(inb));
        S.frac_ambig(b)   = mean(is_ambig(inb));
        S.frac_unass(b)   = mean(is_unassigned(inb));
    end
end

end

% =====================================================================
% Plots
% =====================================================================
function make_plots_v1(P, R)

figure('Color','w');
hold on; grid on;

for is = 1:numel(R.scenarios)
    S = R.scenarios(is).summary;
    plot(S.t_bin_center, S.frac_correct, 'o-');
end

xlabel('|t| [(\mathrm{GeV}/c)^2]');
ylabel('Correct bunch fraction');
leg = cell(numel(R.scenarios),1);
for is = 1:numel(R.scenarios)
    leg{is} = sprintf('\\sigma_{\\mathrm{det}} = %.1f ns', R.scenarios(is).sigma_det_ns);
end
legend(leg,'Location','best');

title(sprintf('Toy MC bunch assignment, window k = %.1f, Nevents = %d', P.window_k, P.Nevents));

end
