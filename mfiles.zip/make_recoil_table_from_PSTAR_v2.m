function T = make_recoil_table_from_PSTAR_v2()
% make_recoil_table_from_PSTAR_v2
% Version 2: Adds recoil angle calculations for fixed-target pp scattering
%
% Reads: PSTAR_stopping_power_protons-in-Si.dat
% File format (as provided):
%   Kinetic Energy [MeV]   CSDA Range [g/cm^2]
%
% Produces a recoil-proton table for elastic pp recoil in CNI:
%   TR = |t|/(2 mp), p = sqrt(TR(TR+2 mp))
% and interpolates the CSDA range in Si for each TR.
%
% NEW in v2: Calculates lab-frame recoil angle theta_R for fixed-target
% collisions at two EIC beam energies: 23.5 GeV and 275 GeV
%
% Output:
%   - prints a table to the command window
%   - prints key kinematic parameters for both beam energies
%   - returns a MATLAB table variable T

clc;

%% --- User inputs ---
fname = 'PSTAR_stopping_power_protons-in-Si.dat';

% Choose ~5–7 representative |t| values in (GeV/c)^2 (edit as needed)
t_vals = [1e-3, 2e-3, 3e-3, 5e-3, 1e-2, 1.5e-2, 2e-2, 3e-2];

% Detector distance for TOF example (optional)
x_det_m = 0.220;  % 220 mm

% Beam energies (TOTAL energies) for EIC [GeV]
E_beam_low  = 23.5;   % injection
E_beam_high = 275.0;  % flattop

%% --- Constants ---
mp_GeV = 0.938272088;     % proton mass [GeV/c^2]
c      = 299792458;       % [m/s]
rho_Si = 2.329;           % silicon density [g/cm^3] (room temp)

%% --- Calculate kinematic parameters for both beam energies ---
fprintf('========================================================================\n');
fprintf('Fixed-Target pp Elastic Scattering Kinematics\n');
fprintf('========================================================================\n\n');

kin_low  = calc_fixed_target_kinematics(E_beam_low,  mp_GeV);
kin_high = calc_fixed_target_kinematics(E_beam_high, mp_GeV);

print_kinematics('E_beam = 23.5 GeV (injection)', kin_low);
fprintf('\n');
print_kinematics('E_beam = 275 GeV (flattop)', kin_high);

fprintf('\n========================================================================\n\n');

%% --- Read PSTAR file (robustly skip header) ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);

% Convert CSDA range to equivalent thickness in Si
% R[g/cm^2] = rho[g/cm^3] * x[cm]  => x[cm] = R/rho
R_cm  = R_gcm2 ./ rho_Si;
R_mm  = 10.0 * R_cm;
R_um  = 1e4 * R_cm;  % 1 cm = 1e4 um

%% --- Recoil kinematics from |t| ---
TR_GeV = t_vals ./ (2*mp_GeV);         % [GeV]
TR_MeV = TR_GeV * 1e3;                 % [MeV]

p_GeV  = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));  % [GeV/c]
p_MeV  = p_GeV * 1e3;                           % [MeV/c]

% beta from kinetic energy: gamma = 1 + TR/mp
gamma = 1 + (TR_GeV ./ mp_GeV);
beta  = sqrt(1 - 1./(gamma.^2));

% TOF to detector (straight-line estimate; field-bending can be added later)
tof_s  = x_det_m ./ (beta*c);
tof_ns = tof_s * 1e9;

%% --- Interpolate CSDA range at TR ---
Rinterp_um = interp1(E_MeV, R_um, TR_MeV, 'pchip', 'extrap');

%% --- Calculate recoil angles for both beam energies ---
theta_R_low_mrad  = zeros(size(t_vals));
theta_R_high_mrad = zeros(size(t_vals));

for i = 1:length(t_vals)
    theta_R_low_mrad(i)  = calc_recoil_angle_fixed_target(t_vals(i), E_beam_low,  mp_GeV, kin_low);
    theta_R_high_mrad(i) = calc_recoil_angle_fixed_target(t_vals(i), E_beam_high, mp_GeV, kin_high);
end

%% --- Make a nice table ---
T = table();
T.t_GeV2            = t_vals(:);
T.TR_MeV            = TR_MeV(:);
T.p_MeVc            = p_MeV(:);
T.beta              = beta(:);
T.theta_R_23GeV_mrad  = theta_R_low_mrad(:);
T.theta_R_275GeV_mrad = theta_R_high_mrad(:);
T.tof_ns_220mm      = tof_ns(:);
T.CSDA_um_Si        = Rinterp_um(:);

disp('Recoil table (from PSTAR CSDA range in Si) with recoil angles:');
disp(T);

%% --- Calculate transverse extents ---
% Δr ≈ r × |tan(θ_max) - tan(θ_min)|
% Convert mrad to rad for calculation
r_det_mm = x_det_m * 1e3;  % detector distance in mm

theta_R_low_rad  = theta_R_low_mrad  * 1e-3;
theta_R_high_rad = theta_R_high_mrad * 1e-3;

delta_r_low  = r_det_mm * abs(tan(theta_R_low_rad(end))  - tan(theta_R_low_rad(1)));
delta_r_high = r_det_mm * abs(tan(theta_R_high_rad(end)) - tan(theta_R_high_rad(1)));

fprintf('\nTransverse extent of CNI region on detector surface (no B-field):\n');
fprintf('  At E_beam = %.1f GeV: Δr ≈ %.1f mm (%.1f to %.1f mrad)\n', ...
    E_beam_low, delta_r_low, theta_R_low_mrad(1), theta_R_low_mrad(end));
fprintf('  At E_beam = %.0f GeV: Δr ≈ %.1f mm (%.1f to %.1f mrad)\n', ...
    E_beam_high, delta_r_high, theta_R_high_mrad(1), theta_R_high_mrad(end));

%% --- Also write CSV for quick sharing (optional) ---
writetable(T, 'recoil_table_from_PSTAR_v2.csv');
fprintf('\nTable saved to: recoil_table_from_PSTAR_v2.csv\n');

end

%% =======================================================================
function kin = calc_fixed_target_kinematics(E_beam_GeV, mp_GeV)
% Calculate kinematic parameters for fixed-target pp collision
%
% Inputs:
%   E_beam_GeV : total beam energy [GeV]
%   mp_GeV     : proton mass [GeV/c^2]
%
% Output:
%   kin : structure with kinematic parameters

kin.E_beam = E_beam_GeV;
kin.mp = mp_GeV;

% Beam momentum
kin.p_beam = sqrt(E_beam_GeV^2 - mp_GeV^2);

% Beam gamma and beta
kin.gamma_beam = E_beam_GeV / mp_GeV;
kin.beta_beam = kin.p_beam / E_beam_GeV;

% Center-of-mass energy
kin.s = 2 * mp_GeV * (mp_GeV + E_beam_GeV);
kin.sqrt_s = sqrt(kin.s);

% CM momentum
kin.p_cm = sqrt(kin.s - 4*mp_GeV^2) / (2*kin.sqrt_s);

% CM frame Lorentz factors
kin.gamma_cm = (E_beam_GeV + mp_GeV) / kin.sqrt_s;
kin.beta_cm = sqrt(1 - 1/kin.gamma_cm^2);

% CM frame rapidity
kin.y_cm = 0.5 * log((E_beam_GeV + kin.p_beam) / (E_beam_GeV - kin.p_beam));

end

%% =======================================================================
function print_kinematics(title_str, kin)
% Print kinematic parameters in a formatted way

fprintf('%s:\n', title_str);
fprintf('  Beam energy (total):     E_beam = %.2f GeV\n', kin.E_beam);
fprintf('  Beam momentum:           p_beam = %.2f GeV/c\n', kin.p_beam);
fprintf('  Beam Lorentz factor:     γ_beam = %.2f\n', kin.gamma_beam);
fprintf('  Beam velocity:           β_beam = %.6f\n', kin.beta_beam);
fprintf('  CM energy:               √s = %.3f GeV\n', kin.sqrt_s);
fprintf('  CM momentum:             p_cm = %.3f GeV/c\n', kin.p_cm);
fprintf('  CM frame Lorentz factor: γ_cm = %.3f\n', kin.gamma_cm);
fprintf('  CM frame velocity:       β_cm = %.6f\n', kin.beta_cm);
fprintf('  CM frame rapidity:       y_cm = %.3f\n', kin.y_cm);

end

%% =======================================================================
function theta_R_mrad = calc_recoil_angle_fixed_target(t_GeV2, E_beam_GeV, mp_GeV, kin)
% Calculate lab-frame recoil angle for fixed-target pp elastic scattering
%
% Inputs:
%   t_GeV2     : momentum transfer squared [(GeV/c)^2]
%   E_beam_GeV : total beam energy [GeV]
%   mp_GeV     : proton mass [GeV/c^2]
%   kin        : kinematic parameters structure (from calc_fixed_target_kinematics)
%
% Output:
%   theta_R_mrad : lab-frame recoil angle [mrad]

% Use pre-calculated kinematic parameters
sqrt_s = kin.sqrt_s;
p_cm = kin.p_cm;
gamma_cm = kin.gamma_cm;
beta_cm = kin.beta_cm;

% Step 1: CM scattering angle
theta_cm = acos(1 - t_GeV2 / (2*p_cm^2));

% Step 2: Recoil proton momentum in CM (goes backward)
E_cm = sqrt(p_cm^2 + mp_GeV^2);

% CM momentum components (recoil goes backward)
p_cm_parallel = -p_cm * cos(theta_cm);  % backward in CM
p_cm_perp     =  p_cm * sin(theta_cm);

% Step 3: Boost to lab frame
p_lab_parallel = gamma_cm * (p_cm_parallel + beta_cm * E_cm);
p_lab_perp     = p_cm_perp;  % unchanged by longitudinal boost

% Step 4: Lab-frame recoil angle
theta_R_rad = atan2(p_lab_perp, p_lab_parallel);
theta_R_mrad = theta_R_rad * 1e3;  % convert to mrad

end

%% =======================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads the provided PSTAR file format:
%   header lines, then numeric lines with: Energy(MeV)  Range(g/cm^2)

if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end

fid = fopen(fname,'r');
if fid < 0
    error('Could not open %s', fname);
end

E = [];
R = [];

while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    
    ln = strtrim(ln);
    if isempty(ln), continue; end
    
    % Try to parse two floats from the line
    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end

fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end

E_MeV  = E;
R_gcm2 = R;

% Ensure monotonic energy for interpolation
[E_MeV, idx] = sort(E_MeV);
R_gcm2 = R_gcm2(idx);

end