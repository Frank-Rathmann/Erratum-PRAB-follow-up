function plot_deposited_charge_v2()
% plot_deposited_charge_v2
% Computes the charge deposited by a proton of kinetic energy E as it
% traverses a silicon detector of thickness t_Si (default 320 um), using
% the CSDA range table from the NIST PSTAR database.
%
% Method (range-difference / CSDA approximation):
%   Let R(E) be the CSDA range in Si.
%     - If R(E0) <= t_Si:  proton stops in the detector. E_dep = E0.
%     - If R(E0) >  t_Si:  proton punches through.
%                          Residual range after t_Si is  R_res = R(E0) - t_Si.
%                          Inverting R(E) gives the exit energy E_exit.
%                          E_dep = E0 - E_exit.
%   Q [C] = (E_dep / W_Si) * e,    with W_Si = 3.62 eV/(e-h pair) in Si.
%
% Reads:  PSTAR_stopping_power_protons-in-Si.dat
% Writes: deposited_charge_320um_Si.pdf  (vector PDF figure)
%
% All figure text uses the LaTeX interpreter.

clc; close all;

%% --- User inputs ---
fname    = 'PSTAR_stopping_power_protons-in-Si.dat';
t_Si_um  = 320;                 % detector thickness [um]
E_lo     = 0.05;                % plot range [MeV]
E_hi     = 20.0;                % plot range [MeV]
N_grid   = 4000;                % number of energy points

% Representative energies for the printed/LaTeX table [MeV]
E_table  = [0.5, 1.0, 2.0, 3.0, 4.5, 6.0, 7.0, 10.0, 16.0, 20.0];

% Points to annotate on the plot [MeV]
E_marks  = [0.5, 16];

%% --- Physical constants ---
rho_Si   = 2.329;               % Si density [g/cm^3]
W_Si_eV  = 3.62;                % mean energy per e-h pair in Si [eV]
e_C      = 1.602176634e-19;     % elementary charge [C]

%% --- Use LaTeX for all figure text ---
set(groot, 'defaultTextInterpreter',         'latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter',       'latex');

%% --- Read PSTAR file ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);
R_um = (R_gcm2 ./ rho_Si) * 1e4;        % CSDA range in Si [um]

%% --- Sweep proton energy ---
E_grid = logspace(log10(E_lo), log10(E_hi), N_grid).';
R0_um  = interp1(E_MeV, R_um, E_grid, 'pchip');

E_dep         = zeros(size(E_grid));
stops         = R0_um <= t_Si_um;
E_dep(stops)  = E_grid(stops);                                % stops -> all
punch         = ~stops;
R_res         = R0_um(punch) - t_Si_um;
E_exit        = interp1(R_um, E_MeV, R_res, 'pchip');         % invert R(E)
E_dep(punch)  = E_grid(punch) - E_exit;                       % punches through

Q_fC = E_dep .* 1e6 ./ W_Si_eV .* e_C .* 1e15;

%% --- Peak (proton just barely stops:  R(E) = t_Si) ---
E_peak = interp1(R_um, E_MeV, t_Si_um, 'pchip');
Q_peak = E_peak * 1e6 / W_Si_eV * e_C * 1e15;

%% --- Marker values for plot ---
Q_marks = interp1(E_grid, Q_fC, E_marks);

%% --- Build and print the representative table -----------------------
% Insert the peak energy into the printed list.
E_print    = sort([E_table, E_peak]);
R_print    = interp1(E_MeV,  R_um,  E_print, 'pchip');
Edep_print = interp1(E_grid, E_dep, E_print, 'pchip');
Q_print    = interp1(E_grid, Q_fC,  E_print, 'pchip');

fprintf('\n  Deposited charge in %.0f um of Si\n', t_Si_um);
fprintf('  Si density = %.3f g/cm^3,   W_Si = %.2f eV/(e-h pair)\n\n', ...
        rho_Si, W_Si_eV);
fprintf('     E [MeV]      R [um]    E_dep [MeV]    Q [fC]\n');
fprintf('     -------      ------    -----------    ------\n');
for k = 1:numel(E_print)
    mk = ' ';
    if abs(E_print(k) - E_peak) < 1e-9, mk = '*'; end
    fprintf('  %c %8.3f   %9.2f   %10.3f    %7.2f\n', mk, ...
            E_print(k), R_print(k), Edep_print(k), Q_print(k));
end
fprintf('\n  (* peak: proton range equals detector thickness)\n\n');

%% --- Plot -----------------------------------------------------------
fig = figure('Color','w','Units','centimeters','Position',[2 2 16 11]);
plot(E_grid, Q_fC, 'b-', 'LineWidth', 1.8); hold on; grid on; box on;

% Markers
plot(E_peak,     Q_peak,     'p', 'MarkerSize', 14, ...
     'MarkerFaceColor',[0.20 0.70 0.20], 'MarkerEdgeColor','k');
plot(E_marks(1), Q_marks(1), 'o', 'MarkerSize',  9, ...
     'MarkerFaceColor',[0.10 0.45 0.85], 'MarkerEdgeColor','k');
plot(E_marks(2), Q_marks(2), 'o', 'MarkerSize',  9, ...
     'MarkerFaceColor',[1.00 0.55 0.10], 'MarkerEdgeColor','k');

% LaTeX text annotations
text(E_peak + 1, 0.78 * Q_peak, ...
     sprintf('Peak: $E=%.2f$~MeV, $Q=%.1f$~fC', E_peak, Q_peak), ...
     'FontSize', 10);
text(E_marks(1) + 0.8, Q_marks(1) + 10, ...
     sprintf('$E=%.1f$~MeV', E_marks(1)), 'FontSize', 10);
text(E_marks(2) + 0.4, Q_marks(2) + 10, ...
     sprintf('$E=%g$~MeV',   E_marks(2)), 'FontSize', 10);

xlabel('Proton kinetic energy $E$~[MeV]');
ylabel('Deposited charge $Q$~[fC]');
title(sprintf('Charge deposited in $%d~\\mu$m silicon (PSTAR CSDA)', t_Si_um));
legend({'CSDA estimate', ...
        sprintf('Peak ($R = %d~\\mu$m)', t_Si_um), ...
        sprintf('$E = %.1f$~MeV', E_marks(1)), ...
        sprintf('$E = %g$~MeV',   E_marks(2))}, ...
        'Location','northeast');
xlim([0 E_hi]);
ylim([0 1.12*Q_peak]);

%% --- Export as vector PDF ------------------------------------------
pdf_name = 'deposited_charge_320um_Si.pdf';
exportgraphics(fig, pdf_name, 'ContentType', 'vector');
fprintf('  Figure saved to: %s\n', pdf_name);

end

%% =====================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads PSTAR file numeric lines with:
%   Energy(MeV)  Range(g/cm^2)

if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end
fid = fopen(fname,'r');
if fid < 0, error('Could not open %s', fname); end

E = []; R = [];
while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    ln = strtrim(ln);
    if isempty(ln), continue; end
    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end
fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end
[E_MeV, idx] = sort(E);
R_gcm2 = R(idx);
end
