function T = make_recoil_table_from_PSTAR_v4()
% make_recoil_table_from_PSTAR_v5
% Version 5:
%   - Calculates actual recoil angles theta_R from complete 4-momentum conservation
%   - Computes z-positions on detector surface at r = 220 mm
%   - Uses formula: z = r / tan(theta_R)
%   - Replaces delta_R with actual scattering angles
%
% Reads: PSTAR_stopping_power_protons-in-Si.dat
% File format (as provided):
%   Kinetic Energy [MeV]   CSDA Range [g/cm^2]
%
% Produces a recoil-proton table for elastic pp recoil in CNI:
%   TR = |t|/(2 mp), p = sqrt(TR(TR+2 mp))
% and interpolates the CSDA range in Si for each TR.
%
% Output:
%   - prints a table to the command window
%   - prints key kinematic parameters for both beam energies
%   - returns a MATLAB table variable T

clc;

%% --- User inputs ---
fname = 'PSTAR_stopping_power_protons-in-Si.dat';

% Representative |t| values in (GeV/c)^2 (edit as needed)
t_vals = [1e-3, 2e-3, 3e-3, 5e-3, 1e-2, 1.5e-2, 2e-2, 3e-2];

% Detector distance (radial) for z-position calculation
r_det_mm = 220;  % 220 mm
r_det_m = r_det_mm / 1e3;  % Convert to meters for TOF

% Beam energies (TOTAL energies) [GeV]
E_beam_low  = 23.5;   % injection
E_beam_high = 275.0;  % flattop

%% --- Constants ---
mp_GeV = 0.938272088;     % proton mass [GeV/c^2]
c      = 299792458;       % [m/s]
rho_Si = 2.329;           % silicon density [g/cm^3]

%% --- Print fixed-target beam kinematics (for reference) ---
fprintf('========================================================================\n');
fprintf('Fixed-Target pp Elastic Scattering Kinematics\n');
fprintf('========================================================================\n\n');

kin_low  = calc_fixed_target_kinematics(E_beam_low,  mp_GeV);
kin_high = calc_fixed_target_kinematics(E_beam_high, mp_GeV);

print_kinematics(sprintf('E_beam = %.1f GeV (injection)', E_beam_low), kin_low);
fprintf('\n');
print_kinematics(sprintf('E_beam = %.0f GeV (flattop)',   E_beam_high), kin_high);

fprintf('\n========================================================================\n\n');

%% --- Read PSTAR file (robustly skip header) ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);

% Convert CSDA range to equivalent thickness in Si:
%   R[g/cm^2] = rho[g/cm^3] * x[cm]  => x[cm] = R/rho
R_cm  = R_gcm2 ./ rho_Si;
R_um  = 1e4 * R_cm;  % 1 cm = 1e4 um

%% --- Recoil kinematics from |t| (target recoil) ---
TR_GeV = t_vals ./ (2*mp_GeV);         % [GeV]
TR_MeV = TR_GeV * 1e3;                 % [MeV]

pR_GeV = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));  % [GeV/c]
pR_MeV = pR_GeV * 1e3;                          % [MeV/c]

% beta from kinetic energy: gamma = 1 + TR/mp
gammaR = 1 + (TR_GeV ./ mp_GeV);
betaR  = sqrt(1 - 1./(gammaR.^2));

% TOF to detector (straight-line estimate; field-bending can be added later)
tof_s  = r_det_m ./ (betaR*c);
tof_ns = tof_s * 1e9;

%% --- Interpolate CSDA range at TR ---
Rinterp_um = interp1(E_MeV, R_um, TR_MeV, 'pchip', 'extrap');

%% --- Calculate recoil angles and z-positions for both beam energies ---
% From complete 4-momentum conservation

theta_R_low_deg  = zeros(size(t_vals));
theta_R_high_deg = zeros(size(t_vals));
z_low_mm  = zeros(size(t_vals));
z_high_mm = zeros(size(t_vals));

for i = 1:numel(t_vals)
    [theta_R_low_deg(i), z_low_mm(i)]   = calc_recoil_angle_and_z(t_vals(i), kin_low, r_det_mm);
    [theta_R_high_deg(i), z_high_mm(i)] = calc_recoil_angle_and_z(t_vals(i), kin_high, r_det_mm);
end

%% --- Build table ---
T = table();
T.t_GeV2               = t_vals(:);
T.TR_MeV               = TR_MeV(:);
T.p_MeVc               = pR_MeV(:);
T.beta                 = betaR(:);

% Recoil angles from 4-momentum conservation
T.theta_R_23GeV_deg    = theta_R_low_deg(:);
T.z_23GeV_mm           = z_low_mm(:);
T.theta_R_275GeV_deg   = theta_R_high_deg(:);
T.z_275GeV_mm          = z_high_mm(:);

T.tof_ns_220mm         = tof_ns(:);
T.CSDA_um_Si           = Rinterp_um(:);

disp('Recoil table with actual scattering angles and z-positions:');
disp(T);

%% --- Summary of detector footprint ---
z_low_min  = min(z_low_mm);
z_low_max  = max(z_low_mm);
z_low_center = (z_low_min + z_low_max) / 2;
delta_z_low = z_low_max - z_low_min;

z_high_min  = min(z_high_mm);
z_high_max  = max(z_high_mm);
z_high_center = (z_high_min + z_high_max) / 2;
delta_z_high = z_high_max - z_high_min;

fprintf('\n========================================================================\n');
fprintf('Detector Footprint Summary (r = %.0f mm)\n', r_det_mm);
fprintf('========================================================================\n\n');

fprintf('At E_beam = %.1f GeV:\n', E_beam_low);
fprintf('  z_min    = %6.2f mm\n', z_low_min);
fprintf('  z_max    = %6.2f mm\n', z_low_max);
fprintf('  z_center = %6.2f mm  (downstream from interaction point)\n', z_low_center);
fprintf('  Δz       = %6.2f mm\n', delta_z_low);

fprintf('\nAt E_beam = %.0f GeV:\n', E_beam_high);
fprintf('  z_min    = %6.2f mm\n', z_high_min);
fprintf('  z_max    = %6.2f mm\n', z_high_max);
fprintf('  z_center = %6.2f mm  (downstream from interaction point)\n', z_high_center);
fprintf('  Δz       = %6.2f mm\n', delta_z_high);

fprintf('\n========================================================================\n');
fprintf('Physical Interpretation:\n');
fprintf('========================================================================\n');
fprintf('Recoil angles are θ_R ≈ 85-89° from the beam axis.\n');
fprintf('These angles are LESS than 90°, meaning recoils have a small forward\n');
fprintf('(positive z) momentum component and hit the detector downstream.\n\n');
fprintf('The extent Δz ≈ 17 mm is approximately the same at both energies\n');
fprintf('because the recoil angle depends primarily on the transverse momentum\n');
fprintf('transfer p_perp ≈ sqrt(|t|), which is independent of beam energy.\n');
fprintf('========================================================================\n');

%% --- Write CSV (optional) ---
writetable(T, 'recoil_table_from_PSTAR_v5.csv');
fprintf('\nTable saved to: recoil_table_from_PSTAR_v5.csv\n');

end

%% =======================================================================
function kin = calc_fixed_target_kinematics(E_beam_GeV, mp_GeV)
% Kinematic parameters for a fixed-target pp collision (beam on stationary proton).
% Inputs:
%   E_beam_GeV : total beam energy [GeV]
%   mp_GeV     : proton mass [GeV/c^2]
% Output:
%   kin struct

kin.E_beam = E_beam_GeV;
kin.mp     = mp_GeV;

% Beam momentum
kin.p_beam = sqrt(E_beam_GeV^2 - mp_GeV^2);

% Beam gamma and beta
kin.gamma_beam = E_beam_GeV / mp_GeV;
kin.beta_beam  = kin.p_beam / E_beam_GeV;

% Mandelstam s for fixed target: s = m^2 + m^2 + 2 m E_beam = 2 m (m + E_beam)
kin.s      = 2 * mp_GeV * (mp_GeV + E_beam_GeV);
kin.sqrt_s = sqrt(kin.s);

end

%% =======================================================================
function print_kinematics(title_str, kin)
fprintf('%s:\n', title_str);
fprintf('  Beam energy (total):     E_beam = %.2f GeV\n', kin.E_beam);
fprintf('  Beam momentum:           p_beam = %.2f GeV/c\n', kin.p_beam);
fprintf('  Beam Lorentz factor:     γ_beam = %.2f\n', kin.gamma_beam);
fprintf('  Beam velocity:           β_beam = %.6f\n', kin.beta_beam);
fprintf('  CM energy:               √s = %.3f GeV\n', kin.sqrt_s);
end

%% =======================================================================
function [theta_R_deg, z_mm] = calc_recoil_angle_and_z(t_GeV2, kin, r_det_mm)
% Calculate recoil angle and z-position from complete 4-momentum conservation
%
% Inputs:
%   t_GeV2    : momentum transfer squared [GeV^2]
%   kin       : beam kinematics struct
%   r_det_mm  : detector radial distance [mm]
%
% Outputs:
%   theta_R_deg : recoil angle from beam axis [degrees]
%   z_mm        : z-position on detector surface [mm]

mp_GeV = kin.mp;
E_beam = kin.E_beam;
p_beam = kin.p_beam;

% Recoil proton kinematics
T_R = t_GeV2 / (2 * mp_GeV);
E4 = mp_GeV + T_R;
p4 = sqrt(E4^2 - mp_GeV^2);

% Scattered beam proton
E3 = E_beam + mp_GeV - E4;
p3 = sqrt(E3^2 - mp_GeV^2);

% Scattered beam angle from Mandelstam t
t_mandelstam = -t_GeV2;
cos_theta3 = (t_mandelstam - 2*mp_GeV^2 + 2*E_beam*E3) / (2*p_beam*p3);
theta3_rad = acos(cos_theta3);
sin_theta3 = sin(theta3_rad);

% Recoil angle from transverse momentum conservation
% sin(theta_R) = p3 * sin(theta3) / p4
sin_theta_R = (p3 * sin_theta3) / p4;
theta_R_rad = asin(sin_theta_R);
theta_R_deg = rad2deg(theta_R_rad);

% z-position on detector surface at perpendicular distance r
% z = r / tan(theta_R)
z_mm = r_det_mm / tan(theta_R_rad);

end

%% =======================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads PSTAR file numeric lines with:
%   Energy(MeV)  Range(g/cm^2)
if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end

fid = fopen(fname,'r');
if fid < 0
    error('Could not open %s', fname);
end

E = [];
R = [];

while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end

    ln = strtrim(ln);
    if isempty(ln), continue; end

    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end

fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end

% Ensure monotonic energy for interpolation
[E_MeV, idx] = sort(E);
R_gcm2 = R(idx);

end