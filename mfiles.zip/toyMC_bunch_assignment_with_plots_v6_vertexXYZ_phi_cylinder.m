% toyMC_bunch_assignment_with_plots_v6_vertexXYZ_phi_cylinder.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% Based on toyMC_bunch_assignment_with_plots_v5_vertexXYZ_phi_cylinder.m
%
% Fixed in v6:
%  - Extended color palette to support all 9 sigma_det values
%  - Added distinguishable line styles for better visualization
%  - Improved legend placement and readability

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Physics
P.mp_GeV      = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns  = 0.299792458;      % speed of light in m/ns

% Detector geometry (cylinder)
P.Rdet_m      = 0.220;            % detector radius (m)

% Beam beta for bunch-passage timing shift across z0
P.beta_beam   = 1.0;              % approx 1 at EIC flattop

% Vertex distribution (EIC IP4 flattop, Table II)
P.sigma_x_m   = 1.610e-3;         % sigma_x = 1.610 mm
P.sigma_y_m   = 0.268e-3;         % sigma_y = 0.268 mm
P.z0_min_m    = -5e-3;            % -5 mm
P.z0_max_m    = +5e-3;            % +5 mm

% Bunch timing
P.tau_b_ns        = 11.027;       % bunch spacing (ns), EIC flattop
P.sigma_bunch_ns  = 0.200;        % rms bunch temporal width (ns)
P.sigma_model_ns  = 0.0;          % extra model uncertainty (ns), optional

% Detector timing scenarios - EXTENDED RANGE FOR SYSTEMATIC STUDY
P.sigma_det_ns_list = [0.3, 0.4, 0.5, 0.6, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;                   % test n = 0..nmax
P.window_k = 5.0;                 % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges = [ ...
    0.0005, 0.0015, 0.0025, 0.0040, ...
    0.0075, 0.0125, 0.0175, 0.0250, 0.0350 ];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins     = numel(P.t_centers);

% Plot export
P.writePNGs = true;
P.pngDPI    = 300;                % 300 for LaTeX
P.figPosIn  = [1 1 10 6];         % inches, wider for legend

% Plot defaults (LaTeX friendly)
set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultLegendFontSize', 20, ...
    'defaultFigureColor', 'w');

rng(1);

%% -------------------- Generate truth |t| --------------------
bin_id = randi(P.Nbins, P.Nevents, 1);
bin_id = bin_id(:);

t_lo = P.t_edges(bin_id);
t_hi = P.t_edges(bin_id + 1);
t_lo = t_lo(:);
t_hi = t_hi(:);

t_true = t_lo + (t_hi - t_lo) .* rand(P.Nevents, 1);   % (GeV/c)^2

% Recoil kinematics (toy, consistent with your existing approach)
TR_GeV = t_true ./ (2*P.mp_GeV);                        % TR in GeV
p_GeV  = sqrt(t_true);                                  % p_R ~ sqrt(|t|) (GeV/c)
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);          % recoil beta

%% -------------------- Vertex sampling: x0,y0 Gaussian, z0 uniform --------------------
x0_m = P.sigma_x_m .* randn(P.Nevents,1);
y0_m = P.sigma_y_m .* randn(P.Nevents,1);
z0_m = P.z0_min_m + (P.z0_max_m - P.z0_min_m) .* rand(P.Nevents,1);

% Bunch-passage timing shift at the vertex (ns)
dt_z_ns = z0_m ./ (P.beta_beam * P.c_m_per_ns);

%% -------------------- Uniform azimuth phi, theta_R = 90 deg (uz = 0) --------------------
phi = 2*pi .* rand(P.Nevents,1);
ux  = cos(phi);
uy  = sin(phi);
% uz = 0;

%% -------------------- Intersect with detector cylinder x^2+y^2 = Rdet^2 --------------------
% Track: r(s) = r0 + s*u, with u_z = 0, u_perp = 1
% Solve (x0 + s*ux)^2 + (y0 + s*uy)^2 = R^2
% => s^2 + 2*(x0*ux + y0*uy)*s + (x0^2+y0^2 - R^2) = 0

B = 2*(x0_m.*ux + y0_m.*uy);
C = (x0_m.^2 + y0_m.^2 - P.Rdet_m^2);

disc = B.^2 - 4*C;

% Numerical safety: reject rare events if disc<0 (should not happen for small x0,y0)
valid = disc >= 0;

s_hit = nan(P.Nevents,1);
sqrt_disc = sqrt(max(disc,0));
% Physical (positive) root: s = (-B + sqrt_disc)/2
s_tmp = (-B + sqrt_disc) ./ 2;
s_hit(valid) = s_tmp(valid);

% Hit position
x_hit = x0_m + s_hit.*ux;
y_hit = y0_m + s_hit.*uy;
z_hit = z0_m;  % since uz=0

% Flight path length and TOF
L_m = s_hit;                                   % since |u|=1
tTOF_true_ns = L_m ./ (beta * P.c_m_per_ns);    % ns

%% -------------------- Assign a true bunch and build measured times --------------------
b_true = randi(2000, P.Nevents, 1);

dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

% Ideal measured hit time stamp (ns)
t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns + dt_z_ns;

% Measured dt relative to the "current" bunch marker:
b0     = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;   % in [0,tau_b)

% True offset in the bunch search convention
n_true = b0 - b_true;

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    tTOF_pred_ns = tTOF_true_ns;  % toy uses truth for TOF prediction

    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);   % Nevents x Nn
    res_ns  = cand_ns - tTOF_pred_ns;                % Nevents x Nn

    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';

    accept  = absmin < (P.window_k * sigma_eff_ns);
    correct = accept & (n_best == n_true);

    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns    = dt_meas_ns;
        REF.tTOF_pred_ns  = tTOF_pred_ns;
        REF.n_best        = n_best;
        REF.n_true        = n_true;
        REF.accept        = accept;
        REF.bin_id        = bin_id;
        REF.sigma_eff_ns  = sigma_eff_ns;
        REF.res_ns        = res_ns;
        REF.t_true        = t_true;
        % New bookkeeping
        REF.x0_m          = x0_m;
        REF.y0_m          = y0_m;
        REF.z0_m          = z0_m;
        REF.dt_z_ns       = dt_z_ns;
        REF.phi           = phi;
        REF.x_hit         = x_hit;
        REF.y_hit         = y_hit;
        REF.z_hit         = z_hit;
        REF.L_m           = L_m;
    end
end

%% -------------------- Plot 1: Correct fraction vs |t| --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

% Extended color palette for 9 curves - distinguishable colors
colors = [
    0.00, 0.00, 0.80;   % dark blue
    0.00, 0.50, 0.80;   % medium blue
    0.00, 0.75, 0.75;   % cyan
    0.93, 0.69, 0.13;   % gold
    0.85, 0.33, 0.10;   % orange-red
    0.64, 0.08, 0.18;   % dark red
    0.49, 0.18, 0.56;   % purple
    0.47, 0.67, 0.19;   % green
    0.30, 0.30, 0.30    % dark gray
];

% Different line styles for better distinction
lineStyles = {'-', '-', '-', '-', '-', '--', '--', '--', '--'};
markers = {'o', 'o', 'o', 'o', 's', 's', 'd', 'd', '^'};

h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), ...
        'LineStyle', lineStyles{is}, ...
        'Marker', markers{is}, ...
        'LineWidth', 2.5, ...
        'MarkerSize', 9, ...
        'MarkerFaceColor', colors(is,:), ...
        'Color', colors(is,:));
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '$|t|$ [(GeV/$c$)$^2$]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');
ylabel(ax, 'Correct bunch fraction', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');

ylim(ax, [0.7, 1.02]);
xlim(ax, [0, max(P.t_edges)]);

leg = cell(numel(P.sigma_det_ns_list), 1);
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('$\\sigma_{\\mathrm{det}} = %.1f$ ns', P.sigma_det_ns_list(is));
end

lgd = legend(ax, h, leg, ...
    'Location', 'eastoutside', ...
    'Box', 'on', ...
    'Interpreter', 'latex', ...
    'FontSize', 16); %#ok<NASGU>

ax.Position(3) = 0.58;  % Adjust axes width to fit legend

if P.writePNGs
    exportgraphics(fig, sprintf('toyMC_correctFraction_vs_t_k%.1f_v6.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_correctFraction_vs_t_k%.1f_v6.png\n', P.window_k);
end

%% -------------------- Plot 2: tTOF vs |t| with m*tau_b lines --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

tgrid = linspace(min(P.t_edges), max(P.t_edges), 600).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
% For plotting, use nominal L = Rdet (theta=90 deg); actual event L differs by mm-scale via vertex
tTOFgrid = P.Rdet_m ./ (betagrid * P.c_m_per_ns);

plot(ax, tgrid, tTOFgrid, '-', 'LineWidth', 3.5, 'Color', [0.0 0.3 0.7]);

mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(ax, m*P.tau_b_ns, '-', ...
        'LineWidth', 1.8, ...
        'Color', [0.85 0.33 0.10], ...
        'Alpha', 1);
    text(ax, max(P.t_edges)*0.98, m*P.tau_b_ns, ...
        sprintf(' %d\\tau_b', m), ...
        'FontSize', 24, ...
        'VerticalAlignment', 'bottom', ...
        'HorizontalAlignment', 'right', ...
        'Color', [0.85 0.33 0.10]);
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '|{\it t}| [(GeV/{\it c})^2]', 'FontSize', 24, 'FontWeight', 'bold');
ylabel(ax, '{\it t}_{TOF} [ns]', 'FontSize', 24, 'FontWeight', 'bold');

xlim(ax, [0, max(P.t_edges)]);
ylim(ax, [0, 30]);

if P.writePNGs
    exportgraphics(fig, 'toyMC_tTOF_vs_t_v6.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_tTOF_vs_t_v6.png\n');
end

%% -------------------- Plot 3: Residual histograms for reference sigma_det --------------------
if ref_keep
    [~, idxBest] = min(abs(REF.res_ns), [], 2);
    resBest = REF.res_ns(sub2ind(size(REF.res_ns), (1:P.Nevents).', idxBest));

    ib1 = 1;
    ib2 = min(P.Nbins, 5);

    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib1) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Time-of-flight residual $r_n$ [ns]', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Probability density', 'Interpreter','latex', 'FontSize',36);

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f_v6.png', ib1, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f_v6.png\n', ib1, ref_sigma_det);
    end

    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib2) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Time-of-flight residual $r_n$ [ns]', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Probability density', 'Interpreter','latex', 'FontSize',36);

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f_v6.png', ib2, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f_v6.png\n', ib2, ref_sigma_det);
    end
end

%% -------------------- Plot 4: n_best distribution --------------------
if ref_keep
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

    histogram(ax, REF.n_best(REF.accept), 'BinMethod','integers');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Selected bunch offset $n_{\rm best}$', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Counts (accepted)', 'FontSize', 36, 'Interpreter', 'latex');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_nBest_sigmaDet%.1f_v6.png', ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_nBest_sigmaDet%.1f_v6.png\n', ref_sigma_det);
    end
end

%% -------------------- NEW: Plot 5: Quantitative analysis for systematic budget --------------------
% Calculate metrics to determine required timing resolution

% 1. Calculate f_wrong for each timing resolution
f_wrong = 1 - correctFrac;  % Nbins x Nsigma matrix

% 2. Calculate average f_wrong (unweighted and weighted)
f_wrong_avg_unweighted = mean(f_wrong, 1);  % average across |t| bins

% 3. For weighted average, we need A_y(|t|) and dN/d|t|
% Using approximate A_y values from CNI region (you can refine these)
% A_y peaks around 0.04-0.05 in the CNI region
Ay_approx = [0.037, 0.040, 0.042, 0.043, 0.042, 0.040, 0.038, 0.035];
if numel(Ay_approx) ~= P.Nbins
    Ay_approx = 0.04 * ones(1, P.Nbins);  % fallback
end

% Approximate dN/d|t| (elastic cross section in CNI region)
% Roughly exponential decay with |t|
dN_dt_approx = exp(-P.t_centers / 0.01);  % normalized later

% Weight: A_y^2 * dN/d|t| (since precision scales as 1/(A_y*sqrt(N)))
weight = (Ay_approx.^2 .* dN_dt_approx)';
weight = weight / sum(weight);  % normalize

f_wrong_avg_weighted = f_wrong' * weight;  % Nsigma x 1

% Print results
fprintf('\n========== BUNCH MIS-IDENTIFICATION SYSTEMATIC ANALYSIS ==========\n');
fprintf('Target: f_wrong < 0.001 (0.1%%) for Delta_P/P < 0.1%% systematic\n');
fprintf('        f_wrong < 0.0005 (0.05%%) for Delta_P/P < 0.05%% systematic\n');
fprintf('==================================================================\n\n');
fprintf('sigma_det [ns]  |  f_wrong (unweighted avg)  |  f_wrong (weighted avg)\n');
fprintf('----------------------------------------------------------------\n');
for is = 1:numel(P.sigma_det_ns_list)
    fprintf('    %.1f         |        %.4f (%.2f%%)        |       %.4f (%.2f%%)\n', ...
        P.sigma_det_ns_list(is), ...
        f_wrong_avg_unweighted(is), f_wrong_avg_unweighted(is)*100, ...
        f_wrong_avg_weighted(is), f_wrong_avg_weighted(is)*100);
end
fprintf('==================================================================\n');

% Find required timing resolution by interpolation
target_f_wrong = [0.001, 0.0005, 0.0001];  % 0.1%, 0.05%, 0.01%
target_labels = {'0.1%', '0.05%', '0.01%'};

fprintf('\nREQUIRED TIMING RESOLUTION (by interpolation):\n');
fprintf('------------------------------------------------------\n');
for it = 1:numel(target_f_wrong)
    % Unweighted
    if min(f_wrong_avg_unweighted) <= target_f_wrong(it)
        sigma_req_unwt = interp1(f_wrong_avg_unweighted(end:-1:1), ...
            P.sigma_det_ns_list(end:-1:1), target_f_wrong(it), 'linear', 'extrap');
    else
        sigma_req_unwt = NaN;  % need better timing than tested
    end
    
    % Weighted
    if min(f_wrong_avg_weighted) <= target_f_wrong(it)
        sigma_req_wt = interp1(f_wrong_avg_weighted(end:-1:1), ...
            P.sigma_det_ns_list(end:-1:1), target_f_wrong(it), 'linear', 'extrap');
    else
        sigma_req_wt = NaN;
    end
    
    fprintf('For f_wrong < %s:  sigma_det < %.2f ns (unwt),  < %.2f ns (weighted)\n', ...
        target_labels{it}, sigma_req_unwt, sigma_req_wt);
end
fprintf('======================================================\n\n');

% Plot: f_wrong vs sigma_det
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

plot(ax, P.sigma_det_ns_list, f_wrong_avg_unweighted*100, '-o', ...
    'LineWidth', 3, 'MarkerSize', 10, 'MarkerFaceColor', [0.0 0.45 0.74], ...
    'Color', [0.0 0.45 0.74], 'DisplayName', 'Unweighted average');

plot(ax, P.sigma_det_ns_list, f_wrong_avg_weighted*100, '-s', ...
    'LineWidth', 3, 'MarkerSize', 10, 'MarkerFaceColor', [0.85 0.33 0.10], ...
    'Color', [0.85 0.33 0.10], 'DisplayName', 'Weighted by $A_y^2 \cdot dN/d|t|$');

% Reference lines
yline(ax, 0.1, '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], ...
    'Label', '0.1% target', 'FontSize', 18, 'LabelHorizontalAlignment', 'left');
yline(ax, 0.05, '-.', 'LineWidth', 2, 'Color', [0.7 0.7 0.7], ...
    'Label', '0.05% target', 'FontSize', 18, 'LabelHorizontalAlignment', 'left');

set(ax, 'FontSize', 22, 'LineWidth', 1.5, 'YScale', 'log');
xlabel(ax, '$\sigma_{\mathrm{det}}$ [ns]', 'FontSize', 26, 'Interpreter', 'latex');
ylabel(ax, 'Bunch mis-identification $f_{\mathrm{wrong}}$ [%]', ...
    'FontSize', 26, 'Interpreter', 'latex');
ylim(ax, [0.01, 20]);

legend(ax, 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 20);

if P.writePNGs
    exportgraphics(fig, 'toyMC_fwrong_vs_sigmaDet_v6.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_fwrong_vs_sigmaDet_v6.png\n');
end

%% -------------------- Done --------------------
fprintf('\nAll done (v6: fixed color array + systematic analysis).\n');
fprintf('Check console output above for required timing resolution.\n\n');