% compute_fields_from_geometry_v7b.m
%
% Field calculation for the coil geometry defined in a separate geometry .m file.
%
% Features
%  - Prompts for which coil pair to compute (Bx, By, or Bz) — NO "ALL".
%  - Reads geometry parameters by parsing the geometry file text (does not execute it).
%  - Supports simple assignments/expressions like z_bz = s; and R_bz = r_circle + a/2;
%  - Computes Bx, By, Bz, and |B| on an Ngrid^3 cube x,y,z in [-Lbox, +Lbox] mm.
%  - Scales current so the intended component at the origin is +0.400 T.
%  - ALWAYS makes 1D sanity plots along x, y, z axes for the selected pair.
%  - Saves a per-pair .mat file:  Bfield_map_Bx_Pair.mat / ..._By_... / ..._Bz_...
%    with overwrite protection (default: do NOT overwrite existing file).
%
% Model
%  - Filament centerline loops (Biot–Savart via discretized line elements):
%      * Bx pair: square loops in yz plane at x = ±d, side length 2*s
%      * By pair: square loops in xz plane at y = ±d, side length 2*s
%      * Bz pair: circular loops in xy plane at z = ±z_bz, radius R_bz
%
% Notes on MAT-file interoperability (Python)
%  - Saved as MAT v7 (not v7.3) so scipy.io.loadmat can read it easily.
%  - The file contains ONE variable: "results" (a MATLAB struct).
%
% Contents and units:
%   results.geometryFile                     (string)
%   results.P.<...>_mm                       (mm)
%   results.Lbox_mm                          (mm)
%   results.Ngrid                            (scalar)
%   results.x_mm, results.y_mm, results.z_mm (mm vectors)
%   results.<Pair>Pair.I                     (A)
%   results.<Pair>Pair.B0                    (T, 1x3, at origin)
%   results.<Pair>Pair.Bx,By,Bz,Bmag         (T, Ngrid x Ngrid x Ngrid)
%
% Increase Ngrid / NsubSquare / NphiCircle after debugging.

clear; close all; clc;

%% -------------------- User settings --------------------
geometryFile = 'xyz_sketch_3d_det220_plusBz.m';  % must exist in current folder or on path

% Cube half-size and grid
Lbox_mm = 250;
Ngrid   = 101;           % odd -> origin lies on the grid

% Discretization
NsubSquare = 60;          % subdivisions per straight segment (square loops)
NphiCircle = 360;         % number of circle segments (polygon)

% Target field at origin (selected component)
Btarget = 0.400;          % Tesla

% Plot controls
makeQuickPlots = true;

% MAT save format (Python-friendly)
matSaveVersion = '-v7';

% PNG export (names include whichPair)
writePNGs = true;
pngDPI    = 200;   % pick 150–300

set(groot, ...
    'defaultAxesFontSize', 16, ...
    'defaultAxesLabelFontSizeMultiplier', 1.2, ...
    'defaultAxesTitleFontSizeMultiplier', 1.4, ...
    'defaultLineLineWidth', 2.0, ...
    'defaultFigureColor', 'w');

fig = figure('Color','w', ...
    'Units','inches', ...
    'Position',[1 1 7.0 4.5]);   % width x height for LaTeX


%% -------------------- Ask which coil pair --------------------
fprintf('\nSelect coil pair to compute:\n');
fprintf('  1 = Bx coil pair (square loops in yz plane at x = ±d)\n');
fprintf('  2 = By coil pair (square loops in xz plane at y = ±d)\n');
fprintf('  3 = Bz coil pair (circular loops in xy plane at z = ±z_bz)\n');
sel = input('Enter selection (1..3): ');
if isempty(sel) || ~ismember(sel,1:3)
    error('Invalid selection.');
end

switch sel
    case 1, whichPair = 'Bx';
    case 2, whichPair = 'By';
    case 3, whichPair = 'Bz';
end

outFile = sprintf('Bfield_map_%s_Pair.mat', whichPair);

%% -------------------- Geometry file existence --------------------
if ~isfile(geometryFile)
    error('Geometry file not found: %s\nSet geometryFile at the top of this script.', geometryFile);
end

%% -------------------- Read geometry parameters (from YOUR file) --------------------
P = readGeometryParamsSafe(geometryFile);

fprintf('\nParsed geometry from %s:\n', geometryFile);
fprintf('  d        = %.6g mm\n', P.d_mm);
fprintf('  s        = %.6g mm\n', P.s_mm);
fprintf('  L_coil   = %.6g mm\n', P.L_coil_mm);
fprintf('  a        = %.6g mm\n', P.a_mm);
fprintf('  r_circle = %.6g mm\n', P.r_circle_mm);
fprintf('  R_bz     = %.6g mm\n', P.R_bz_mm);
fprintf('  z_bz     = %.6g mm\n', P.z_bz_mm);

%% -------------------- Build field grid --------------------
x_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
y_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
z_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
[Xmm, Ymm, Zmm] = ndgrid(x_mm, y_mm, z_mm);

r_m = [Xmm(:), Ymm(:), Zmm(:)] * 1e-3;   % meters
sz  = size(Xmm);
mid = (Ngrid+1)/2;

%% -------------------- Compute map (always) --------------------
fprintf('\nComputing %s pair...\n', whichPair);
[Bcube,Ireq,B0] = computePairScaled(whichPair, r_m, P, Btarget, NsubSquare, NphiCircle);

%% -------------------- Package results struct --------------------
results = struct();
results.geometryFile = geometryFile;
results.P = P;
results.Lbox_mm = Lbox_mm;
results.Ngrid = Ngrid;
results.x_mm = x_mm;
results.y_mm = y_mm;
results.z_mm = z_mm;

pairFieldName = [whichPair,'Pair'];  % 'BxPair', 'ByPair', 'BzPair'
results.(pairFieldName) = struct();
results.(pairFieldName).I    = Ireq;
results.(pairFieldName).B0   = B0;
results.(pairFieldName).Bx   = reshape(Bcube(:,1), sz);
results.(pairFieldName).By   = reshape(Bcube(:,2), sz);
results.(pairFieldName).Bz   = reshape(Bcube(:,3), sz);
results.(pairFieldName).Bmag = reshape(vecnorm(Bcube,2,2), sz);

%% -------------------- Save (optional overwrite protection) --------------------
doSave = true;
if isfile(outFile)
    a = input(sprintf('File exists: %s. Recompute done; overwrite file? y/n [n]: ', outFile), 's');
    if isempty(a), a = 'n'; end
    if lower(a(1)) ~= 'y'
        doSave = false;
        fprintf('Not overwriting existing file.\n');
    end
end

if doSave
    save(outFile,'results',matSaveVersion);
    fprintf('Saved: %s  (variable: results struct; units: mm, T, A)\n', outFile);
end

%% -------------------- Quick 2D plot (slice at z=0) --------------------
if makeQuickPlots
    fig = figure('Color','w');
    switch whichPair
        case 'Bx'
            imagesc(x_mm,y_mm,squeeze(results.BxPair.Bx(:,:,mid))'); axis image;
            title('Bx from Bx pair at z = 0 [T]');
        case 'By'
            imagesc(x_mm,y_mm,squeeze(results.ByPair.By(:,:,mid))'); axis image;
            title('By from By pair at z = 0 [T]');
        case 'Bz'
            imagesc(x_mm,y_mm,squeeze(results.BzPair.Bz(:,:,mid))'); axis image;
            title('Bz from Bz pair at z = 0 [T]');
    end
    set(gca,'YDir','normal'); colorbar;
    xlabel('x [mm]'); ylabel('y [mm]');

    if writePNGs
        fn = sprintf('fig_fieldmap_%s_z0.png', whichPair);
        exportgraphics(fig, fn, 'Resolution', pngDPI);
        fprintf('Wrote PNG: %s\n', fn);
    end
end

%% -------------------- 1D sanity plots along axes --------------------
PF = results.(pairFieldName);

sanityPlot3(results.x_mm, squeeze(PF.Bx(:,mid,mid)), squeeze(PF.By(:,mid,mid)), squeeze(PF.Bz(:,mid,mid)), ...
    sprintf('%s-pair: along x (y=z=0)', whichPair), sprintf('fig_sanity_%s_along_x.png', whichPair));

sanityPlot3(results.y_mm, squeeze(PF.Bx(mid,:,mid)), squeeze(PF.By(mid,:,mid)), squeeze(PF.Bz(mid,:,mid)), ...
    sprintf('%s-pair: along y (x=z=0)', whichPair), sprintf('fig_sanity_%s_along_y.png', whichPair));

sanityPlot3(results.z_mm, squeeze(PF.Bx(mid,mid,:)), squeeze(PF.By(mid,mid,:)), squeeze(PF.Bz(mid,mid,:)), ...
    sprintf('%s-pair: along z (x=y=0)', whichPair), sprintf('fig_sanity_%s_along_z.png', whichPair));

fprintf('\nDone.\n');

%% =====================================================================
%% Functions
%% =====================================================================

function [Bcube,Ireq,B0_scaled] = computePairScaled(whichPair, r_m, P, Btarget, NsubSquare, NphiCircle)
    r0 = [0 0 0];
    B1 = computePairField(whichPair, r0, 1.0, P, NsubSquare, NphiCircle);

    switch whichPair
        case 'Bx', comp = 1;
        case 'By', comp = 2;
        case 'Bz', comp = 3;
        otherwise, error('Unknown pair.');
    end

    if abs(B1(comp)) < 1e-15
        error('%s pair: selected component at origin is too small for scaling.', whichPair);
    end

    Ireq = Btarget / B1(comp);   % keeps sign; produces +Btarget in that component
    fprintf('  For 1 A: B(0) = [%.3e %.3e %.3e] T\n', B1(1),B1(2),B1(3));
    fprintf('  Current for target: I = %.6g A\n', Ireq);

    Bcube = computePairField(whichPair, r_m, Ireq, P, NsubSquare, NphiCircle);
    B0_scaled = computePairField(whichPair, r0, Ireq, P, NsubSquare, NphiCircle);
    fprintf('  Check: B(0) = [%.6f %.6f %.6f] T\n', B0_scaled(1),B0_scaled(2),B0_scaled(3));
end

function B = computePairField(whichPair, r_m, I, P, NsubSquare, NphiCircle)
    if isrow(r_m), r_m = reshape(r_m,1,3); end
    mu0 = 4*pi*1e-7;

    s = P.s_mm * 1e-3;
    d = P.d_mm * 1e-3;

    B = zeros(size(r_m));

    switch whichPair
        case 'Bx'
            loop1 = squareLoopYZ(+d, s);
            loop2 = squareLoopYZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'By'
            loop1 = squareLoopXZ(+d, s);
            loop2 = squareLoopXZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'Bz'
            R  = P.R_bz_mm * 1e-3;
            z0 = P.z_bz_mm * 1e-3;
            circ1 = circleLoopXY(+z0, R, NphiCircle);
            circ2 = circleLoopXY(-z0, R, NphiCircle);
            B = B + biotSavartPolyline(r_m, circ1, I, mu0, 1);
            B = B + biotSavartPolyline(r_m, circ2, I, mu0, 1);

        otherwise
            error('Unknown pair.');
    end
end

function pts = squareLoopXZ(y0, s)
    pts = [-s, y0, -s;
            s, y0, -s;
            s, y0,  s;
           -s, y0,  s;
           -s, y0, -s];
end

function pts = squareLoopYZ(x0, s)
    pts = [x0, -s, -s;
           x0,  s, -s;
           x0,  s,  s;
           x0, -s,  s;
           x0, -s, -s];
end

function pts = circleLoopXY(z0, R, Nphi)
% Closed polyline for a circle in the xy plane at z=z0 with radius R.
% Enforce exact closure to avoid floating-point mismatch.
    phi = linspace(0,2*pi,Nphi+1);
    pts = [R*cos(phi(:)), R*sin(phi(:)), z0*ones(numel(phi),1)];
    pts(end,:) = pts(1,:);
end

function B = biotSavartPolyline(r, pts, I, mu0, NsubPerSegment)
% Biot–Savart for a (closed) polyline, tolerant closure check.

    tol = 1e-12; % meters
    if norm(pts(end,:) - pts(1,:), 2) > tol
        error('Polyline must be closed (last point equals first within tol=%.1e).', tol);
    end
    pts(end,:) = pts(1,:); % enforce exact closure

    pref = (mu0*I)/(4*pi);
    B = zeros(size(r));

    M = size(pts,1)-1;
    for m = 1:M
        p1 = pts(m,:);
        p2 = pts(m+1,:);
        B = B + pref * biotSegmentMidpointSum(r, p1, p2, NsubPerSegment);
    end
end

function dB = biotSegmentMidpointSum(r, p1, p2, Nsub)
    v  = (p2 - p1);
    dl = v / Nsub;

    k  = (1:Nsub)';
    rp = p1 + (k - 0.5).*(v/Nsub);   % Nsub x 3

    dB = zeros(size(r));
    for j = 1:Nsub
        R  = r - rp(j,:);
        R2 = sum(R.^2,2);
        R3 = R2 .* sqrt(R2);

        mask = (R3 > 0);
        if ~any(mask), continue; end

        Rx = R(mask,1); Ry = R(mask,2); Rz = R(mask,3);

        cx = dl(2)*Rz - dl(3)*Ry;
        cy = dl(3)*Rx - dl(1)*Rz;
        cz = dl(1)*Ry - dl(2)*Rx;

        invR3 = 1 ./ R3(mask);

        dB(mask,1) = dB(mask,1) + cx .* invR3;
        dB(mask,2) = dB(mask,2) + cy .* invR3;
        dB(mask,3) = dB(mask,3) + cz .* invR3;
    end
end

function P = readGeometryParamsSafe(fname)
% Parses scalar definitions from the geometry file text, including simple expressions.
% Allowed tokens in expressions: numbers, identifiers, + - * / ( ) and whitespace.

    txt = fileread(fname);
    env = struct();

    env.d        = parseScalar(txt,'d',env);
    env.a        = parseScalar(txt,'a',env);
    env.L_coil   = parseScalar(txt,'L_coil',env);
    env.s        = parseScalar(txt,'s',env);
    env.r_circle = parseScalar(txt,'r_circle',env);

    if hasVar(txt,'R_bz')
        env.R_bz = parseScalar(txt,'R_bz',env);
    else
        env.R_bz = env.r_circle + env.a/2;
    end

    if hasVar(txt,'z_bz')
        env.z_bz = parseScalar(txt,'z_bz',env);
    else
        env.z_bz = env.s;
    end

    P.d_mm        = env.d;
    P.a_mm        = env.a;
    P.L_coil_mm   = env.L_coil;
    P.s_mm        = env.s;
    P.r_circle_mm = env.r_circle;
    P.R_bz_mm     = env.R_bz;
    P.z_bz_mm     = env.z_bz;
end

function tf = hasVar(txt,varname)
    pat = ['(?m)^\s*', regexptranslate('escape',varname), '\s*='];
    tf = ~isempty(regexp(txt, pat, 'once'));
end

function val = parseScalar(txt, varname, env)
% Extracts RHS from "varname = <expr>;" and evaluates <expr> safely.

    pat = ['(?m)^\s*', regexptranslate('escape',varname), '\s*=\s*([^;]+)\s*;'];
    tok = regexp(txt, pat, 'tokens', 'once');
    if isempty(tok)
        error('Could not parse "%s" from geometry file.', varname);
    end
    expr = strtrim(tok{1});

    if ~isempty(regexp(expr, '[^0-9A-Za-z_\.\+\-\*\/\(\)\s]', 'once'))
        error('Unsafe characters in expression for %s: "%s"', varname, expr);
    end

    names = fieldnames(env);
    for k = 1:numel(names)
        nm = names{k};
        expr = regexprep(expr, ['(?<![A-Za-z0-9_])', nm, '(?![A-Za-z0-9_])'], num2str(env.(nm), '%.17g'));
    end

    if ~isempty(regexp(expr, '[A-Za-z_]', 'once'))
        error('Unknown identifier in %s expression after substitution: "%s"', varname, expr);
    end

    val = str2num(expr); %#ok<ST2NM>
    if isempty(val) || ~isfinite(val) || ~isscalar(val)
        error('Failed to evaluate %s expression: "%s"', varname, expr);
    end
end

function sanityPlot3(coord_mm, Bx, By, Bz, titleStr, outPng)
% sanityPlot3(coord_mm, Bx, By, Bz)
% sanityPlot3(coord_mm, Bx, By, Bz, titleStr)
% sanityPlot3(coord_mm, Bx, By, Bz, titleStr, outPng)

    if nargin < 5 || isempty(titleStr)
        titleStr = '';
    end
    if nargin < 6
        outPng = '';
    end

    figure('Color','w');
    plot(coord_mm, Bx, 'r-', 'LineWidth', 4); hold on;
    plot(coord_mm, By, 'g-', 'LineWidth', 4);
    plot(coord_mm, Bz, 'b-', 'LineWidth', 4);
    grid on;

    set(gca,'FontSize',32,'LineWidth',1.2);     % bigger tick/axis fonts
    xlabel('position [mm]','FontSize',32);
    ylabel('B [T]','FontSize',32);
    legend('Bx','By','Bz','Location','best','FontSize',28);

    if ~isempty(titleStr)
        title(titleStr,'FontSize',32,'FontWeight','bold');
    end

    % Write PNG if requested
    if ~isempty(outPng)
        set(gcf,'InvertHardcopy','off');
        print(gcf, outPng, '-dpng', '-r300');   % 300 dpi
        fprintf('Wrote PNG: %s\n', outPng);
    end
end
