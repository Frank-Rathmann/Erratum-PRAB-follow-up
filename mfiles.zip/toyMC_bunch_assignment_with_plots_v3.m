% toyMC_bunch_assignment_with_plots_v3_fixed.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% Diagnostic plots for presentations and PNG export for LaTeX.
%
% Key idea:
%  - Measured dt = t_hit - floor(t_hit/tau_b)*tau_b  (in [0,tau_b))
%  - Test candidate offsets n = 0..nmax
%  - Accept best n if | (dt + n*tau_b) - tTOF_pred | < k*sigma_eff

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Physics and geometry
P.mp_GeV      = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns  = 0.299792458;      % speed of light in m/ns
P.Lpath_m     = 0.220;            % effective flight path (m), toy model

% Bunch timing
P.tau_b_ns        = 11.027;       % bunch spacing (ns)
P.sigma_bunch_ns  = 0.200;        % rms bunch temporal width (ns)
P.sigma_model_ns  = 0.0;          % extra model uncertainty (ns), optional

% Detector timing scenarios
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;                   % test n = 0..nmax
P.window_k = 3.0;                 % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges   = [0.002, 0.004, 0.0065, 0.009, 0.012, 0.014, 0.0165, 0.019];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins     = numel(P.t_centers);

% Plot export
P.writePNGs = true;
P.pngDPI    = 300;                % 300 for LaTeX
P.figPosIn  = [1 1 8.5 5.5];      % inches

% Plot defaults (LaTeX friendly)
set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultLegendFontSize', 24, ...
    'defaultFigureColor', 'w');

rng(1);

%% -------------------- Generate truth |t| --------------------
% Choose a bin uniformly, then uniform within that bin
bin_id = randi(P.Nbins, P.Nevents, 1);   % column vector

% Force column vectors to avoid dimension mismatch
bin_id = bin_id(:);

% Get bin edges - CRITICAL: ensure these stay as column vectors
t_lo = P.t_edges(bin_id);
t_hi = P.t_edges(bin_id + 1);

% Force column vectors
t_lo = t_lo(:);
t_hi = t_hi(:);

% Uniform within bin (all column vectors)
t_true = t_lo + (t_hi - t_lo) .* rand(P.Nevents, 1);   % (GeV/c)^2

% Recoil kinematics (toy)
TR_GeV = t_true ./ (2*P.mp_GeV);        % TR in GeV (non-rel approx in CNI)
p_GeV  = sqrt(t_true);                  % p_R ~ sqrt(|t|) (GeV/c)
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

tTOF_true_ns = P.Lpath_m ./ (beta * P.c_m_per_ns);     % ns

%% -------------------- Assign a true bunch and build measured times --------------------
% True bunch index (only relative offsets matter)
b_true = randi(2000, P.Nevents, 1);     % arbitrary large range

% Bunch arrival time jitter (intrinsic bunch width)
dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

% Ideal measured hit time stamp (ns)
t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns;

% Measured dt relative to the "current" bunch marker:
b0     = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;            % in [0,tau_b)

% True offset in the bunch search convention
n_true = b0 - b_true;                                  % integer >= 0 typically

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;                                      % 1 x Nn
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

% Keep one scenario as reference for diagnostic plots
ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    % Add detector timing noise
    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    % Effective sigma for window
    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    % Predicted TOF from measured energy (toy: use truth here)
    tTOF_pred_ns = tTOF_true_ns;

    % Residuals for candidate n: res = (dt_meas + n*tau_b) - tTOF_pred
    % Nevents x Nn (with implicit expansion only in 2nd dimension)
    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);      % Nevents x Nn
    res_ns  = cand_ns - tTOF_pred_ns;                   % Nevents x Nn

    % Best n by minimum absolute residual
    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';                         % column

    % Window cut
    accept = absmin < (P.window_k * sigma_eff_ns);

    % Correct bunch assignment
    correct = accept & (n_best == n_true);

    % Bin-by-bin correct fraction
    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    % Save reference arrays
    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns    = dt_meas_ns;
        REF.tTOF_pred_ns  = tTOF_pred_ns;
        REF.n_best        = n_best;
        REF.n_true        = n_true;
        REF.accept        = accept;
        REF.bin_id        = bin_id;
        REF.sigma_eff_ns  = sigma_eff_ns;
        REF.res_ns        = res_ns;                     % Nevents x Nn
        REF.t_true        = t_true;
    end
end

%% -------------------- Plot 1: Correct fraction vs |t| --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), '-o');
end

set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
xlabel(ax, '|t| [(GeV/c)^2]', 'FontSize', 36);
ylabel(ax, 'Correct bunch fraction', 'FontSize', 36);
title(ax, sprintf('Toy MC bunch assignment, k = %.1f, N_{events} = %d', ...
    P.window_k, P.Nevents), 'FontSize', 34, 'FontWeight','bold');

% Create legend labels with tex interpreter
leg = cell(numel(P.sigma_det_ns_list), 1);
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('\\sigma_{det} = %.1f ns', P.sigma_det_ns_list(is));
end

lgd = legend(ax, h, leg, ...
    'Location','northoutside', ...
    'Orientation','horizontal', ...
    'NumColumns', 3, ...
    'Box','off', ...
    'Interpreter','tex');
lgd.FontSize = 26;

if P.writePNGs
    exportgraphics(fig, sprintf('toyMC_correctFraction_vs_t_k%.1f.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_correctFraction_vs_t_k%.1f.png\n', P.window_k);
end

%% -------------------- Plot 2: tTOF vs |t| with m*tau_b lines --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

tgrid = linspace(min(P.t_edges), max(P.t_edges), 600).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
tTOFgrid = P.Lpath_m ./ (betagrid * P.c_m_per_ns);

plot(ax, tgrid, tTOFgrid, '-', 'LineWidth', 3.0);
set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
xlabel(ax, '|t| [(GeV/c)^2]', 'FontSize', 36);
ylabel(ax, 't_{TOF} [ns]', 'FontSize', 36);
title(ax, sprintf('TOF vs |t| for L = %.0f mm', 1e3*P.Lpath_m), ...
    'FontSize', 34, 'FontWeight','bold');

mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(ax, m*P.tau_b_ns, ':', sprintf('%d\\tau_b', m), ...
        'LineWidth', 1.5, ...
        'LabelHorizontalAlignment','left', ...
        'LabelVerticalAlignment','middle');
end

if P.writePNGs
    exportgraphics(fig, 'toyMC_tTOF_vs_t.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_tTOF_vs_t.png\n');
end

%% -------------------- Plot 3: Residual histograms for reference sigma_det --------------------
if ref_keep
    % residual of best candidate
    [~, idxBest] = min(abs(REF.res_ns), [], 2);
    resBest = REF.res_ns(sub2ind(size(REF.res_ns), (1:P.Nevents).', idxBest));

    % Choose two bins
    ib1 = 1;
    ib2 = min(P.Nbins, 5);

    % Bin 1
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib1) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Residual [ns]', 'FontSize', 36);
    ylabel(ax, 'PDF', 'FontSize', 36);
    title(ax, sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ...
        ib1, ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f.png', ib1, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f.png\n', ib1, ref_sigma_det);
    end

    % Bin 2
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib2) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Residual [ns]', 'FontSize', 36);
    ylabel(ax, 'PDF', 'FontSize', 36);
    title(ax, sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ...
        ib2, ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f.png', ib2, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f.png\n', ib2, ref_sigma_det);
    end
end

%% -------------------- Plot 4: n_best distribution and dt mod tau_b diagnostic --------------------
if ref_keep
    % n_best distribution
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

    histogram(ax, REF.n_best(REF.accept), 'BinMethod','integers');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Selected bunch offset n_{best}', 'FontSize', 36);
    ylabel(ax, 'Counts (accepted)', 'FontSize', 36);
    title(ax, sprintf('Chosen bunch offsets, \\sigma_{det}=%.1f ns, k=%.1f', ...
        ref_sigma_det, P.window_k), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_nBest_sigmaDet%.1f.png', ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_nBest_sigmaDet%.1f.png\n', ref_sigma_det);
    end

    % dt mod tau_b vs |t| (subset)
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

    Nsub = min(20000, P.Nevents);
    dt_mod = mod(REF.dt_meas_ns, P.tau_b_ns);

    scatter(ax, REF.t_true(1:Nsub), dt_mod(1:Nsub), 18, 'filled');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, '|t| [(GeV/c)^2]', 'FontSize', 36);
    ylabel(ax, 't_{hit} mod \tau_b [ns]', 'FontSize', 36);
    title(ax, sprintf('Diagnostic scatter (subset), \\sigma_{det}=%.1f ns', ...
        ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_dtMod_vs_t_sigmaDet%.1f.png', ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_dtMod_vs_t_sigmaDet%.1f.png\n', ref_sigma_det);
    end
end

%% -------------------- Done --------------------
fprintf('\nAll done.\n');