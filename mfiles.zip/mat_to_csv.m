% Define input filename
inputFile = 'Bfield_map_Bz_Pair.mat';

% Extract base name (without .mat extension)
[~, baseName, ~] = fileparts(inputFile);

% Load the data
data = load(inputFile);
results = data.results;

% Determine which field pair to use (BxPair, ByPair, or BzPair)
fieldNames = fieldnames(results);
pairField = fieldNames{contains(fieldNames, 'Pair', 'IgnoreCase', true)};

% Export coordinate arrays
writematrix(results.x_mm', 'x_mm.csv');
writematrix(results.y_mm', 'y_mm.csv');
writematrix(results.z_mm', 'z_mm.csv');

% Export parameters
params = [results.(pairField).I; results.(pairField).B0'];
writematrix(params, 'parameters.csv');

% Export 3D field data - flatten to 2D format
% Each row: x, y, z, Bx, By, Bz, Bmag
Nx = length(results.x_mm);
Ny = length(results.y_mm);
Nz = length(results.z_mm);

% Create meshgrid
[X, Y, Z] = meshgrid(results.x_mm, results.y_mm, results.z_mm);

% Flatten arrays
x_flat = X(:);
y_flat = Y(:);
z_flat = Z(:);
Bx_flat = results.(pairField).Bx(:);
By_flat = results.(pairField).By(:);
Bz_flat = results.(pairField).Bz(:);
Bmag_flat = results.(pairField).Bmag(:);

% Combine into table
field_data = [x_flat, y_flat, z_flat, Bx_flat, By_flat, Bz_flat, Bmag_flat];

% Add header and save with automatic output filename
header = {'x_mm', 'y_mm', 'z_mm', 'Bx_T', 'By_T', 'Bz_T', 'Bmag_T'};
T = array2table(field_data, 'VariableNames', header);
outputFile = [baseName, '.csv'];
writetable(T, outputFile);

fprintf('Exported files:\n');
fprintf('  x_mm.csv, y_mm.csv, z_mm.csv (coordinate arrays)\n');
fprintf('  parameters.csv (I and B0)\n');
fprintf('  %s (full 3D field data, %d rows)\n', outputFile, size(field_data,1));