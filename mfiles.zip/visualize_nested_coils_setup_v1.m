function visualize_nested_coils_setup_v1()
% visualize_nested_coils_setup_v1
% 3D-Visualisierung eines würfelfreien Zentralvolumens + Spulen + Detektoren.
% Keine externen Funktionen nötig, alles ist in dieser Datei enthalten.

%% Einheiten
mm = 1e-3;

%% Zentrale freie Region (Materialfrei): 100 x 100 x 100 mm^3
cubeFree.side = 100*mm;   % Kantenlänge
cubeFree.center = [0 0 0];

%% Dominantes Feld: By (Spulen liegen in x-z Ebene, Normalenvektor ~ y)
% Hauptspulenpaar (square coils) für By
mainCoil.sideOuter = 150*mm;   % äußere Kantenlänge (freie Öffnung als Quadrat)
mainCoil.thickness = 20*mm;    % Spulenkörper-Dicke (nur grafisch als "Band")
mainCoil.ypos = +150*mm;       % geändert von 100 mm -> 150 mm
mainCoil.yneg = -150*mm;
mainCoil.centerX = 0*mm;
mainCoil.centerZ = 0*mm;

% Optional: nested inner coil in gleicher Ebene (z. B. 110 mm), lässt 100x100 mm frei
nested.enable = true;
nested.sideInner = 110*mm;
nested.thickness = 20*mm;

%% Kompensationsspulen (für Int B dx ~ 0 entlang x, ebenfalls By-orientiert)
comp.enable = true;

% Idee: zusätzliche By-Coils bei x = ±200 mm, mit Zentren bei y = ±120 mm
% (du kannst daraus auch nur ein Paar machen, oder die y-Lage variieren)
comp.side = 110*mm;        % Beispiel: 110 mm
comp.thickness = 20*mm;
comp.xList = [+200*mm, -200*mm];
comp.yList = [+120*mm, -120*mm];
comp.z = 0*mm;

%% Detektoren (Punkte oder kleine Boxen)
det.enable = true;
det.x = [+250*mm, -250*mm];
det.y = [0*mm, 0*mm];
det.z = [0*mm, 0*mm];
det.box = [20 20 20]*mm;   % nur Darstellung: Kantenlänge der Box (je Detektor)

%% Plot
figure('Color','w'); hold on; grid on;
axis equal; view(35,20);
xlabel('x [m]'); ylabel('y [m]'); zlabel('z [m]');
title('3D-Layout: freie Mitte + By-Spulen + Detektoren');

% Freier Zentralwürfel (nur als Drahtgitter)
drawCubeWire(cubeFree.center, cubeFree.side);

% Hauptspulen (äußere)
cMainPos = [mainCoil.centerX, mainCoil.ypos, mainCoil.centerZ];
cMainNeg = [mainCoil.centerX, mainCoil.yneg, mainCoil.centerZ];

drawSquareCoilXZ(cMainPos, mainCoil.sideOuter, mainCoil.thickness, 'Hauptspule +y');
drawSquareCoilXZ(cMainNeg, mainCoil.sideOuter, mainCoil.thickness, 'Hauptspule -y');

% Nested innere Spulen (optional)
if nested.enable
    drawSquareCoilXZ(cMainPos, nested.sideInner, nested.thickness, 'Nested +y');
    drawSquareCoilXZ(cMainNeg, nested.sideInner, nested.thickness, 'Nested -y');
end

% Kompensationsspulen (optional)
if comp.enable
    for ix = 1:numel(comp.xList)
        for iy = 1:numel(comp.yList)
            cComp = [comp.xList(ix), comp.yList(iy), comp.z];
            drawSquareCoilXZ(cComp, comp.side, comp.thickness, 'Komp.');
        end
    end
end

% Detektoren
if det.enable
    for k = 1:numel(det.x)
        cDet = [det.x(k), det.y(k), det.z(k)];
        drawDetectorBox(cDet, det.box, sprintf('Det %d',k));
    end
end

% Hilfsachsen durch Ursprung
L = 0.35; % m
plot3([-L L],[0 0],[0 0],'k:');
plot3([0 0],[-L L],[0 0],'k:');
plot3([0 0],[0 0],[-L L],'k:');

% Plotgrenzen passend setzen
pad = 0.05; % m
xlim([min([det.x comp.xList 0])-pad, max([det.x comp.xList 0])+pad]);
ylim([-(max(abs([mainCoil.ypos comp.yList 0]))+pad), +(max(abs([mainCoil.ypos comp.yList 0]))+pad)]);
zlim([-(mainCoil.sideOuter/2+pad), +(mainCoil.sideOuter/2+pad)]);

legend('Location','bestoutside');
hold off;

%% ========== lokale Funktionen ==========

function drawCubeWire(c, side)
    % Drahtgitter eines Würfels
    s = side/2;
    V = [
        c + [-s -s -s];
        c + [ s -s -s];
        c + [ s  s -s];
        c + [-s  s -s];
        c + [-s -s  s];
        c + [ s -s  s];
        c + [ s  s  s];
        c + [-s  s  s];
    ];
    E = [
        1 2; 2 3; 3 4; 4 1;   % unten
        5 6; 6 7; 7 8; 8 5;   % oben
        1 5; 2 6; 3 7; 4 8    % vertikal
    ];
    for i=1:size(E,1)
        p1 = V(E(i,1),:); p2 = V(E(i,2),:);
        plot3([p1(1) p2(1)],[p1(2) p2(2)],[p1(3) p2(3)],'LineWidth',1.0,'DisplayName','freier 100mm-Würfel');
    end
end

function drawSquareCoilXZ(c, side, thick, labelStr)
    % Quadrat in x-z Ebene bei y=c(2), als "Band" mit kleiner Dicke in y
    s = side/2;
    t = thick/2;

    % 8 Eckpunkte eines dünnen "Rahmens" als Rechteckring (vereinfachte Darstellung):
    % Wir zeichnen nur den äußeren Rechteckrahmen als 2 parallele Rechtecke (y±t)
    P = [
        c + [-s -t -s];
        c + [ s -t -s];
        c + [ s -t  s];
        c + [-s -t  s];
        c + [-s  t -s];
        c + [ s  t -s];
        c + [ s  t  s];
        c + [-s  t  s];
    ];

    % Kanten
    edges = [
        1 2; 2 3; 3 4; 4 1;   % unten (y=-t)
        5 6; 6 7; 7 8; 8 5;   % oben  (y=+t)
        1 5; 2 6; 3 7; 4 8    % Verbindung
    ];

    for i=1:size(edges,1)
        p1 = P(edges(i,1),:); p2 = P(edges(i,2),:);
        plot3([p1(1) p2(1)],[p1(2) p2(2)],[p1(3) p2(3)],'LineWidth',2.0,'DisplayName',labelStr);
    end
end

function drawDetectorBox(c, box, labelStr)
    % Kleine Box als Detektor-Markierung
    sx = box(1)/2; sy = box(2)/2; sz = box(3)/2;
    V = [
        c + [-sx -sy -sz];
        c + [ sx -sy -sz];
        c + [ sx  sy -sz];
        c + [-sx  sy -sz];
        c + [-sx -sy  sz];
        c + [ sx -sy  sz];
        c + [ sx  sy  sz];
        c + [-sx  sy  sz];
    ];
    E = [
        1 2; 2 3; 3 4; 4 1;
        5 6; 6 7; 7 8; 8 5;
        1 5; 2 6; 3 7; 4 8
    ];
    for i=1:size(E,1)
        p1 = V(E(i,1),:); p2 = V(E(i,2),:);
        plot3([p1(1) p2(1)],[p1(2) p2(2)],[p1(3) p2(3)],'LineWidth',1.5,'DisplayName',labelStr);
    end
    plot3(c(1),c(2),c(3),'o','MarkerSize',6,'LineWidth',1.5,'DisplayName',labelStr);
    text(c(1),c(2),c(3),['  ' labelStr],'FontSize',10);
end

end
