% calc_deflection_circular_coils_fixed_png.m
% Produces TWO separate PNG files for Appendix figures:
%   fig_By_x.png      : By(x,0,0) along x-axis
%   fig_traj_zx.png   : z(x) trajectories for two t values
%
% Fixes included:
%   - Enforce +By at origin by consistent current sign
%   - Correct recoil momentum p(t) for recoil proton initially at rest
%   - Use momentum-kick integrator dpz = -q By dx (unit-clean)
%   - Optional field on-trajectory By(x,0,z) (enabled)
%
% Export fixes for LaTeX:
%   - Set physical figure size in inches (APS-like single column width)
%   - Force large fonts on axes/labels/legend/text objects
%   - Match PaperPosition/PaperSize to avoid truncation
%   - Export at high DPI (600) so labels remain readable after LaTeX scaling
%
% Output files:
%   fig_By_x.png
%   fig_traj_zx.png

clear; close all; clc;

%% Constants (SI)
mu0 = 4*pi*1e-7;                 % T*m/A
c   = 299792458;                 % m/s
qe  = 1.602176634e-19;           % C
mp_MeV = 938.272088;             % MeV/c^2
mp_GeV = mp_MeV*1e-3;            % GeV/c^2

%% Coil geometry and target field
%R_coil   = 50e-3;    % [m]
R_coil   = 33.1e-3;    % [m]
y_coil   = 80e-3;    % coils at y = ±y_coil [m]
%y_coil   = 33.1e-3;    % coils at y = ±y_coil [m]
B_target = 0.4;      % desired By at origin [T], positive
r_det   = 0.22;     % detector radius [m] - CHANGED FROM 250

%% Analytic current magnitude for desired on-axis field at origin
d = y_coil;
geom_factor = (mu0/2) * R_coil^2 / (R_coil^2 + d^2)^(3/2);   % T/A for one coil at origin
I_required = B_target / (2*geom_factor);                     % A (magnitude)

%% Enforce +By at origin for numerical Biot–Savart routine
n_seg_field = 800;  % segments for Biot–Savart
By0_num = calc_By_at_point_xz(0, 0, R_coil, y_coil, I_required, mu0, n_seg_field);
if By0_num < 0
    I_required = -I_required;
    By0_num = -By0_num;
end

fprintf('Current (chosen for +By at origin): I = %.2f A\n', I_required);
fprintf('Numerical By at origin: By(0,0,0) = %.3f T\n\n', By0_num);

%% Recoil proton parameters (correct p(t)), recoil proton initially at rest
t_values = [1e-3, 5e-3, 1e-2, 2e-2];   % treat as |t| in GeV^2

% TR = |t|/(2 mp), p = sqrt(TR (TR + 2 mp))  (GeV/c)
TR_GeV = t_values ./ (2*mp_GeV);
p_recoil_GeV = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));          % GeV/c
p_recoil_SI  = p_recoil_GeV * 1e9 * qe / c;                  % kg*m/s

fprintf('Recoil proton kinematics:\n');
for k = 1:numel(t_values)
    fprintf('  |t| = %.1e (GeV/c)^2:  TR = %.3f MeV,  p = %.1f MeV/c\n', ...
        t_values(k), ...
        TR_GeV(k)*1e3, ...
        p_recoil_GeV(k)*1e3);
end
fprintf('\n');

%% Trajectory setup
x_max   = r_det;      % [m]
n_steps = 2000;
x_traj  = linspace(0, x_max, n_steps);
dx      = x_traj(2) - x_traj(1);

%% Field along x-axis (z=0) for Appendix plot
By_axis = zeros(size(x_traj));
for i = 1:numel(x_traj)
    By_axis(i) = calc_By_at_point_xz(x_traj(i), 0, R_coil, y_coil, I_required, mu0, n_seg_field);
end

%% Trajectories using momentum-kick method
% dpz = -q By dx, theta = pz/p, z_{i+1} = z_i + theta dx
use_field_on_trajectory = true;  % true: By(x,0,z) each step, false: By(x,0,0)
z_store = zeros(2, numel(x_traj));

for k = 1:4
    p  = p_recoil_SI(k);
    pz = 0;
    z  = 0;

    for i = 1:(numel(x_traj)-1)
        x = x_traj(i);

        if use_field_on_trajectory
            By = calc_By_at_point_xz(x, z, R_coil, y_coil, I_required, mu0, n_seg_field);
        else
            By = By_axis(i);
        end

        pz = pz - qe * By * dx;
        z  = z + (pz/p) * dx;

        z_store(k, i+1) = z;
    end

    fprintf('Deflection at x=220 mm, t=%.1e: Dz = %.2f mm\n', t_values(k), z*1e3);
end
fprintf('\n');

%% Sanity check: uniform 0.4 T box field over 50 mm
Lbox = 50e-3;
xdet = x_max;
for k = 1:2
    p = p_recoil_SI(k);
    theta = qe*B_target*Lbox / p;
    z_box = theta*(xdet - Lbox/2);
    fprintf('Box-field estimate (By=0.4 T over 50 mm), t=%.1e: Dz ≈ %.2f mm\n', t_values(k), z_box*1e3);
end
fprintf('\n');

%% ---------- EXPORT SETTINGS (LaTeX / Appendix) ----------
% Choose a physical figure size (inches) so that fonts remain readable after LaTeX scaling.
% APS single-column width is ~3.37 in; for appendices and readability, 6.5 in is typical.
figW = 6.5;   % inches
figH = 4.5;   % inches
dpi  = 600;   % export resolution

% Font sizes (tune as needed for your LaTeX scaling)
fs_label = 36;    % axis labels
fs_tick  = 28;    % tick labels
fs_legend= 26;    % legend
lw_axes  = 1.5;   % axis line width
lw_line  = 3.0;   % plot line width

%% ---------- FIGURE 1: By(x,0,0) ----------
fig1 = figure('Color','w');
set(fig1, 'Units','inches', 'Position',[1 1 figW figH]);
set(fig1, 'PaperUnits','inches');
set(fig1, 'PaperPosition', get(fig1,'Position'));
set(fig1, 'PaperSize', [figW figH]);

plot(x_traj*1e3, By_axis*1e3, 'LineWidth', lw_line);
xlabel('x [mm]');
ylabel('|B| = B_y(x,0,0) [mT]');
xlim([0 r_det*1000]);
xticks(0:25:250);
yticks(-400:50:400);
grid on;

% Force large fonts everywhere
ax1 = gca;
set(ax1, 'FontSize', fs_tick, 'LineWidth', lw_axes);
ax1.XLabel.FontSize = fs_label;
ax1.YLabel.FontSize = fs_label;
set(findall(fig1,'Type','text'), 'FontSize', fs_tick);

print(fig1, 'fig_By_x.png', '-dpng', sprintf('-r%d', dpi));

%% ---------- FIGURE 2: z(x) trajectories ----------
fig2 = figure('Color','w');
set(fig2, 'Units','inches', 'Position',[1.2 1.2 figW figH]);
set(fig2, 'PaperUnits','inches');
set(fig2, 'PaperPosition', get(fig2,'Position'));
set(fig2, 'PaperSize', [figW figH]);

plot(x_traj*1e3, z_store(1,:)*1e3, 'LineWidth', lw_line); hold on;
plot(x_traj*1e3, z_store(2,:)*1e3, 'LineWidth', lw_line);
xlabel('x [mm]');
ylabel('z [mm]');
leg = legend('t = -10^{-3} (GeV/c)^2', 't = -2\times10^{-2} (GeV/c)^2', ...
             'Location','southwest');
set(leg,'Box','off','FontSize',fs_legend);
set(leg,'Box','off','FontSize',fs_legend);
xlim([0 r_det*1000]);
xticks(0:25:250);                 % every 25 mm
yticks(-50:5:50);                 % every 5 mm (adjust to your z-range)
grid on;

ax2 = gca;
set(ax2, 'FontSize', fs_tick, 'LineWidth', lw_axes);
ax2.XLabel.FontSize = fs_label;
ax2.YLabel.FontSize = fs_label;
set(findall(fig2,'Type','text'), 'FontSize', fs_tick);

print(fig2, 'fig_traj_zx.png', '-dpng', sprintf('-r%d', dpi));

fprintf('PNG files written:\n');
fprintf('  fig_By_x.png\n');
fprintf('  fig_traj_zx.png\n');

%% Helper function: By at point (x,0,z) from two coils at y = ±y0 in xz plane
function By = calc_By_at_point_xz(x, z, R, y0, I, mu0, n_seg)
    dphi = 2*pi/n_seg;
    phis = ((1:n_seg) - 0.5) * dphi;
    By_total = 0;

    for sgn = [+1, -1]
        yc = sgn * y0;

        for i = 1:n_seg
            phi = phis(i);

            xc = R*cos(phi);
            zc = R*sin(phi);

            dlx = -R*sin(phi) * dphi;
            dlz =  R*cos(phi) * dphi;

            rx = x - xc;
            ry = 0 - yc;
            rz = z - zc;
            rmag = sqrt(rx^2 + ry^2 + rz^2);

            cross_y = dlz*rx - dlx*rz;
            By_total = By_total + (mu0*I/(4*pi)) * cross_y / rmag^3;
        end
    end

    By = By_total;
end
