function T = make_recoil_table_from_PSTAR()
% make_recoil_table_from_PSTAR
% Reads: PSTAR_stopping_power_protons-in-Si.dat
% File format (as provided):
%   Kinetic Energy [MeV]   CSDA Range [g/cm^2]
%
% Produces a recoil-proton table for elastic pp recoil in CNI:
%   TR = |t|/(2 mp), p = sqrt(TR(TR+2 mp))
% and interpolates the CSDA range in Si for each TR.
%
% Output:
%   - prints a table to the command window
%   - returns a MATLAB table variable T

clc;

%% --- User inputs ---
fname = 'PSTAR_stopping_power_protons-in-Si.dat';

% Choose ~5–7 representative |t| values in (GeV/c)^2 (edit as needed)
t_vals = [1e-3, 2e-3, 3e-3, 5e-3, 1e-2, 1.5e-2, 2e-2, 3e-2];

% Detector distance for TOF example (optional)
x_det_m = 0.220;  % 220 mm

%% --- Constants ---
mp_GeV = 0.938272088;     % proton mass [GeV/c^2]
c      = 299792458;       % [m/s]
rho_Si = 2.329;           % silicon density [g/cm^3] (room temp)

%% --- Read PSTAR file (robustly skip header) ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);

% Convert CSDA range to equivalent thickness in Si
% R[g/cm^2] = rho[g/cm^3] * x[cm]  => x[cm] = R/rho
R_cm  = R_gcm2 ./ rho_Si;
R_mm  = 10.0 * R_cm;
R_um  = 1e4 * R_cm;  % 1 cm = 1e4 um

%% --- Recoil kinematics from |t| ---
TR_GeV = t_vals ./ (2*mp_GeV);         % [GeV]
TR_MeV = TR_GeV * 1e3;                 % [MeV]

p_GeV  = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));  % [GeV/c]
p_MeV  = p_GeV * 1e3;                           % [MeV/c]

% beta from kinetic energy: gamma = 1 + TR/mp
gamma = 1 + (TR_GeV ./ mp_GeV);
beta  = sqrt(1 - 1./(gamma.^2));

% TOF to detector (straight-line estimate; field-bending can be added later)
tof_s  = x_det_m ./ (beta*c);
tof_ns = tof_s * 1e9;

%% --- Interpolate CSDA range at TR ---
% (PSTAR covers down to 1e-3 MeV; your TR is ~0.5–10 MeV in your examples.)
Rinterp_um = interp1(E_MeV, R_um, TR_MeV, 'pchip', 'extrap');
%Rinterp_mm = Rinterp_um * 1e-3;

%% --- Make a nice table ---
T = table();
T.t_GeV2      = t_vals(:);
T.TR_MeV      = TR_MeV(:);
T.p_MeVc      = p_MeV(:);
T.beta        = beta(:);
T.tof_ns_220mm= tof_ns(:);
T.CSDA_um_Si  = Rinterp_um(:);
%T.CSDA_mm_Si  = Rinterp_mm(:);

disp('Recoil table (from PSTAR CSDA range in Si):');
disp(T);

%% --- Also write CSV for quick sharing (optional) ---
writetable(T, 'recoil_table_from_PSTAR.csv');

end

%% =======================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads the provided PSTAR file format:
%   header lines, then numeric lines with: Energy(MeV)  Range(g/cm^2)

if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end

fid = fopen(fname,'r');
if fid < 0
    error('Could not open %s', fname);
end

E = [];
R = [];

while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    ln = strtrim(ln);
    if isempty(ln), continue; end

    % Try to parse two floats from the line
    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end

fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end

E_MeV  = E;
R_gcm2 = R;

% Ensure monotonic energy for interpolation
[E_MeV, idx] = sort(E_MeV);
R_gcm2 = R_gcm2(idx);

end
