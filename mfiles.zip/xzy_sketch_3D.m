% xyz_sketch_3d.m
% 3D visualization of HJET magnet and detector geometry

clear; close all; clc;

%% Parameters
r_det   = 250;     % detector radius [mm]
detSize = 100;     % detector square size [mm]
detCol  = [1 0 1]; % magenta

d       = 80;      % coil offset (centerline) [mm]
a       = 20;      % coil cross section side [mm]
L_coil  = 66.2;    % coil loop side length [mm]
s       = 33.1;    % half spacing (L_coil/2) [mm]
coilCol = [0 0 1]; % blue

r_circle = 50;     % inner circle radius [mm]
oct_R    = 100 / cosd(22.5);  % octagon radius for flats at ±100 mm

xlimv = 300;
ylimv = 300;
zlimv = 250;

fs1 = 12;
fs2 = 14;

%% Figure/axes
fig = figure('Color','w','Position',[100 100 1200 900]);
ax  = axes('Parent',fig); hold(ax,'on'); 
axis(ax,'equal');
grid(ax,'on');

xlim(ax,[-xlimv xlimv]);
ylim(ax,[-ylimv ylimv]);
zlim(ax,[-zlimv zlimv]);

xlabel(ax,'x [mm]','FontSize',fs2);
ylabel(ax,'y [mm]','FontSize',fs2);
zlabel(ax,'z [mm]','FontSize',fs2);

view(ax,3); % 3D view
set(ax,'FontSize',fs1);

%% 22.5° construction lines in xy-plane at z=0
L = 1.2*max(xlimv,ylimv);
angles = 0:22.5:337.5;
dashColor = [0.7 0.7 0.7];  % gray

for th = angles
    u = [cosd(th), sind(th)];
    p1 = -L*u;
    p2 = +L*u;
    plot3(ax,[p1(1) p2(1)],[p1(2) p2(2)],[0 0], '--', ...
        'Color', dashColor, 'LineWidth', 0.8);
end

%% Inner circle at z=0
t = linspace(0,2*pi,100);
plot3(ax, r_circle*cos(t), r_circle*sin(t), zeros(size(t)), ...
    'Color',[0 0.45 0.35],'LineWidth',2.0);

%% Octagon at z=0
k = 0:7;
phi0 = 22.5;
x8 = oct_R*cosd(phi0 + 45*k);
y8 = oct_R*sind(phi0 + 45*k);
plot3(ax,[x8 x8(1)],[y8 y8(1)],zeros(1,9), ...
    '-','Color',[1.0 0.6 0.0],'LineWidth',2.0);

%% By coils (horizontal, at y = ±d)
% Top coil (y = +80)
% Left leg at x = -33.1, y = 80
drawCoilLeg(ax, [-s, d, 0], a, a, L_coil, 'z', coilCol);
% Right leg at x = +33.1, y = 80
drawCoilLeg(ax, [s, d, 0], a, a, L_coil, 'z', coilCol);
% Connecting segments at z = ±s, connecting outer corners
% Connectors run from x=-43.1 to x=+43.1 (outer edges of legs)
drawConnector(ax, [-s-a/2, d, -s], [s+a/2, d, -s], a, coilCol);
drawConnector(ax, [-s-a/2, d, s], [s+a/2, d, s], a, coilCol);

% Bottom coil (y = -80)
% Left leg at x = +33.1, y = -80
drawCoilLeg(ax, [s, -d, 0], a, a, L_coil, 'z', coilCol);
% Right leg at x = -33.1, y = -80
drawCoilLeg(ax, [-s, -d, 0], a, a, L_coil, 'z', coilCol);
% Connecting segments - outer corners
drawConnector(ax, [-s-a/2, -d, -s], [s+a/2, -d, -s], a, coilCol);
drawConnector(ax, [-s-a/2, -d, s], [s+a/2, -d, s], a, coilCol);

%% Bx coils (vertical, at x = ±d)
% Right coil (x = +80)
% Bottom leg at x = 80, y = -33.1
drawCoilLeg(ax, [d, -s, 0], a, a, L_coil, 'z', coilCol);
% Top leg at x = 80, y = +33.1
drawCoilLeg(ax, [d, s, 0], a, a, L_coil, 'z', coilCol);
% Connecting segments - outer corners
drawConnector(ax, [d, -s-a/2, -s], [d, s+a/2, -s], a, coilCol);
drawConnector(ax, [d, -s-a/2, s], [d, s+a/2, s], a, coilCol);

% Left coil (x = -80)
% Bottom leg at x = -80, y = +33.1
drawCoilLeg(ax, [-d, s, 0], a, a, L_coil, 'z', coilCol);
% Top leg at x = -80, y = -33.1
drawCoilLeg(ax, [-d, -s, 0], a, a, L_coil, 'z', coilCol);
% Connecting segments - outer corners
drawConnector(ax, [-d, -s-a/2, -s], [-d, s+a/2, -s], a, coilCol);
drawConnector(ax, [-d, -s-a/2, s], [-d, s+a/2, s], a, coilCol);

%% Detectors (6 total) at r = 250 mm, 100×100 mm squares
detAngles = [0 180 45 225 135 315];

for th = detAngles
    % Center position
    cx = r_det*cosd(th);
    cy = r_det*sind(th);
    
    % Radial and tangent unit vectors
    rx = cosd(th);
    ry = sind(th);
    tx = -sind(th);
    ty = cosd(th);
    
    % Detector is a square perpendicular to radial direction
    % Extends ±50 mm in tangential direction and ±50 mm in z
    drawDetector(ax, [cx cy 0], [tx ty], detSize, detCol);
end

%% Coordinate axes - longer, thicker, colored
% x-axis: red
quiver3(ax, 0, 0, 0, xlimv*0.85, 0, 0, 0, 'r', 'LineWidth', 3, 'MaxHeadSize', 0.5);
% y-axis: green
quiver3(ax, 0, 0, 0, 0, ylimv*0.85, 0, 0, 'g', 'LineWidth', 3, 'MaxHeadSize', 0.5);
% z-axis: blue (beam direction)
quiver3(ax, 0, 0, 0, 0, 0, zlimv*0.85, 0, 'b', 'LineWidth', 3, 'MaxHeadSize', 0.5);

text(ax, xlimv*0.90, 0, 0, 'x', 'FontSize', fs2+2, 'FontWeight', 'bold', 'Color', 'r');
text(ax, 0, ylimv*0.90, 0, 'y', 'FontSize', fs2+2, 'FontWeight', 'bold', 'Color', 'g');
text(ax, 0, 0, zlimv*0.90, 'z', 'FontSize', fs2+2, 'FontWeight', 'bold', 'Color', 'b');

%% Enable rotation
rotate3d(ax, 'on');

fprintf('3D visualization complete. Use mouse to rotate.\n');

%% ---------- Local functions ----------

function drawCoilLeg(ax, center, width, height, length, direction, color)
    % Draw a rectangular coil leg centered at 'center'
    % For z-direction: width and height are the x and y extents (20 mm each)
    % direction: 'x', 'y', or 'z' - direction of leg extent
    
    cx = center(1);
    cy = center(2);
    cz = center(3);
    
    half_len = length/2;
    half_w = width/2;
    half_h = height/2;
    
    if direction == 'z'
        % Leg extends in z direction from cz-half_len to cz+half_len
        % Cross-section is width×height in xy plane (constant along z)
        % width = extent in x, height = extent in y
        corners = [
            cx-half_w, cy-half_h, cz-half_len;
            cx+half_w, cy-half_h, cz-half_len;
            cx+half_w, cy+half_h, cz-half_len;
            cx-half_w, cy+half_h, cz-half_len;
            cx-half_w, cy-half_h, cz+half_len;
            cx+half_w, cy-half_h, cz+half_len;
            cx+half_w, cy+half_h, cz+half_len;
            cx-half_w, cy+half_h, cz+half_len
        ];
    elseif direction == 'x'
        % Leg extends in x direction
        corners = [
            cx-half_len, cy-half_w, cz-half_h;
            cx+half_len, cy-half_w, cz-half_h;
            cx+half_len, cy+half_w, cz-half_h;
            cx-half_len, cy+half_w, cz-half_h;
            cx-half_len, cy-half_w, cz+half_h;
            cx+half_len, cy-half_w, cz+half_h;
            cx+half_len, cy+half_w, cz+half_h;
            cx-half_len, cy+half_w, cz+half_h
        ];
    elseif direction == 'y'
        % Leg extends in y direction
        corners = [
            cx-half_w, cy-half_len, cz-half_h;
            cx+half_w, cy-half_len, cz-half_h;
            cx+half_w, cy+half_len, cz-half_h;
            cx-half_w, cy+half_len, cz-half_h;
            cx-half_w, cy-half_len, cz+half_h;
            cx+half_w, cy-half_len, cz+half_h;
            cx+half_w, cy+half_len, cz+half_h;
            cx-half_w, cy+half_len, cz+half_h
        ];
    end
    
    % Define faces of rectangular box
    faces = [
        1 2 3 4;  % bottom
        5 6 7 8;  % top
        1 2 6 5;  % front
        2 3 7 6;  % right
        3 4 8 7;  % back
        4 1 5 8   % left
    ];
    
    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', 0.3, 'EdgeColor', color, 'LineWidth', 1.5);
end

function drawConnector(ax, p1, p2, width, color)
    % Draw rectangular connector between two points
    % Cross-section is width×width
    
    hw = width/2;
    
    % Direction vector
    v = [p2(1)-p1(1), p2(2)-p1(2), p2(3)-p1(3)];
    len = norm(v);
    v = v/len;
    
    % Find two perpendicular vectors
    if abs(v(3)) < 0.9
        u1 = cross(v, [0 0 1]);
    else
        u1 = cross(v, [1 0 0]);
    end
    u1 = u1/norm(u1);
    u2 = cross(v, u1);
    u2 = u2/norm(u2);
    
    % Four corners at each end
    c1 = [
        p1 - hw*u1 - hw*u2;
        p1 + hw*u1 - hw*u2;
        p1 + hw*u1 + hw*u2;
        p1 - hw*u1 + hw*u2
    ];
    
    c2 = [
        p2 - hw*u1 - hw*u2;
        p2 + hw*u1 - hw*u2;
        p2 + hw*u1 + hw*u2;
        p2 - hw*u1 + hw*u2
    ];
    
    corners = [c1; c2];
    
    faces = [
        1 2 3 4;      % end 1
        5 6 7 8;      % end 2
        1 2 6 5;      % side 1
        2 3 7 6;      % side 2
        3 4 8 7;      % side 3
        4 1 5 8       % side 4
    ];
    
    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', 0.3, 'EdgeColor', color, 'LineWidth', 1.5);
end

function drawDetector(ax, center, tangent, size, color)
    % Draw detector as thin square plate perpendicular to radial direction
    % tangent = [tx, ty] is the tangent direction in xy plane
    % Detector: 100×100 mm in tangent and z directions, 1 mm thick in radial
    
    cx = center(1);
    cy = center(2);
    cz = center(3);
    
    tx = tangent(1);
    ty = tangent(2);
    
    hs = size/2;  % half-size = 50 mm
    thickness = 1; % mm
    ht = thickness/2;  % half-thickness = 0.5 mm
    
    % Radial direction (outward from origin)
    rnorm = norm([cx cy]);
    rx = cx/rnorm;
    ry = cy/rnorm;
    
    % Define 8 corners of the thin rectangular box
    % The detector extends:
    %   ±hs in tangent direction (±50 mm)
    %   ±hs in z direction (±50 mm)  
    %   ±ht in radial direction (±0.5 mm)
    
    % Inner face (closer to origin) at -ht in radial direction
    corners = [
        cx - hs*tx - ht*rx, cy - hs*ty - ht*ry, cz - hs;  % 1: bottom-left inner
        cx + hs*tx - ht*rx, cy + hs*ty - ht*ry, cz - hs;  % 2: bottom-right inner
        cx + hs*tx - ht*rx, cy + hs*ty - ht*ry, cz + hs;  % 3: top-right inner
        cx - hs*tx - ht*rx, cy - hs*ty - ht*ry, cz + hs;  % 4: top-left inner
        % Outer face (farther from origin) at +ht in radial direction
        cx - hs*tx + ht*rx, cy - hs*ty + ht*ry, cz - hs;  % 5: bottom-left outer
        cx + hs*tx + ht*rx, cy + hs*ty + ht*ry, cz - hs;  % 6: bottom-right outer
        cx + hs*tx + ht*rx, cy + hs*ty + ht*ry, cz + hs;  % 7: top-right outer
        cx - hs*tx + ht*rx, cy - hs*ty + ht*ry, cz + hs   % 8: top-left outer
    ];
    
    faces = [
        1 2 3 4;  % inner face (toward origin)
        5 6 7 8;  % outer face (away from origin)
        1 2 6 5;  % bottom edge
        2 3 7 6;  % right edge
        3 4 8 7;  % top edge
        4 1 5 8   % left edge
    ];
    
    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', 0.5, 'EdgeColor', color, 'LineWidth', 2);
end