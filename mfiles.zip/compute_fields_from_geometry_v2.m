% compute_fields_from_geometry_v2.m
%
% Magnetic field calculator for the coil geometry defined in your geometry script.
%
% What it does
%  - Asks which coil pair to use: Bx, By, Bz (or ALL).
%  - Reads geometry parameters (d, s, r_circle, a, etc.) from the geometry .m file text
%    without executing it (so it is safe even if the geometry starts with clear/close/clc).
%  - Computes Bx, By, Bz and |B| on a coarse xyz cube: x,y,z in [-250, +250] mm.
%  - Scales the current for the selected pair such that the intended component at the origin
%    is +0.400 T (Bx for Bx-pair, By for By-pair, Bz for Bz-pair).
%
% Model
%  - Filament centerline loops:
%      * Bx/By: square loops of side length 2*s (as in the geometry), lying in yz (Bx) / xz (By).
%      * Bz: circular loops of radius R_bz = r_circle + a/2, lying in xy plane at z=±z_bz.
%  - Biot–Savart integral is approximated by subdividing each segment into straight line elements.
%
% Notes
%  - This is intended for debugging first: start coarse (Ngrid ~ 21).
%  - Later increase Ngrid (e.g. 41..81) and NsubSquare/NphiCircle as needed.
%
% Frank Rathmann, Jan 2026

clear; close all; clc;

%% -------------------- User settings --------------------
% Geometry file to parse (change to your actual filename).
% If you saved the uploaded geometry as "xyz_sketch_3d_det220.m", use that.
geometryFile = 'xzy_sketch_3D_det220_plusBz.m';

% Field cube half-size
Lbox_mm = 250;

% Coarse grid (odd recommended so that origin is exactly on grid)
Ngrid = 21;

% Discretization controls (increase later for accuracy)
NsubSquare = 60;     % subdivisions per square side segment
NphiCircle = 360;    % segments around circle (polygon)

% Target field at origin for each coil pair (separately)
Btarget = 0.400;     % Tesla

% Output
outMatFile = 'Bfield_map_selectedPair.mat';
makeQuickPlots = true;

%% -------------------- Choose coil pair --------------------
fprintf('\nSelect coil pair to compute:\n');
fprintf('  1 = Bx coil pair (square loops in yz plane at x=±d)\n');
fprintf('  2 = By coil pair (square loops in xz plane at y=±d)\n');
fprintf('  3 = Bz coil pair (circular loops in xy plane at z=±z_bz)\n');
fprintf('  4 = ALL (compute three maps)\n');

sel = input('Enter selection (1..4): ');
if isempty(sel) || ~ismember(sel, 1:4)
    error('Invalid selection.');
end

%% -------------------- Read geometry parameters --------------------
P = readGeometryParams(geometryFile);

fprintf('\nRead geometry from %s:\n', geometryFile);
fprintf('  d        = %.6g mm\n', P.d_mm);
fprintf('  s        = %.6g mm\n', P.s_mm);
fprintf('  L_coil   = %.6g mm  (for drawing only)\n', P.L_coil_mm);
fprintf('  a        = %.6g mm\n', P.a_mm);
fprintf('  r_circle = %.6g mm\n', P.r_circle_mm);
fprintf('  R_bz     = %.6g mm  (derived = r_circle + a/2)\n', P.R_bz_mm);
fprintf('  z_bz     = %.6g mm\n', P.z_bz_mm);

%% -------------------- Build field grid --------------------
x_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
y_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
z_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
[Xmm, Ymm, Zmm] = ndgrid(x_mm, y_mm, z_mm);

r_m = [Xmm(:), Ymm(:), Zmm(:)] * 1e-3;  % meters

% Helper for reshaping
sz = size(Xmm);
mid = (Ngrid+1)/2;

%% -------------------- Compute --------------------
results = struct();
results.geometryFile = geometryFile;
results.P = P;
results.Ngrid = Ngrid;
results.Lbox_mm = Lbox_mm;
results.x_mm = x_mm; results.y_mm = y_mm; results.z_mm = z_mm;

if sel == 1 || sel == 4
    fprintf('\n--- Computing Bx coil pair ---\n');
    [Bcube, Ireq, B0] = computePairScaled('Bx', r_m, P, Btarget, NsubSquare, NphiCircle);
    results.BxPair.I = Ireq;
    results.BxPair.B0 = B0;
    results.BxPair.Bx = reshape(Bcube(:,1), sz);
    results.BxPair.By = reshape(Bcube(:,2), sz);
    results.BxPair.Bz = reshape(Bcube(:,3), sz);
    results.BxPair.Bmag = reshape(vecnorm(Bcube,2,2), sz);
end

if sel == 2 || sel == 4
    fprintf('\n--- Computing By coil pair ---\n');
    [Bcube, Ireq, B0] = computePairScaled('By', r_m, P, Btarget, NsubSquare, NphiCircle);
    results.ByPair.I = Ireq;
    results.ByPair.B0 = B0;
    results.ByPair.Bx = reshape(Bcube(:,1), sz);
    results.ByPair.By = reshape(Bcube(:,2), sz);
    results.ByPair.Bz = reshape(Bcube(:,3), sz);
    results.ByPair.Bmag = reshape(vecnorm(Bcube,2,2), sz);
end

if sel == 3 || sel == 4
    fprintf('\n--- Computing Bz coil pair ---\n');
    [Bcube, Ireq, B0] = computePairScaled('Bz', r_m, P, Btarget, NsubSquare, NphiCircle);
    results.BzPair.I = Ireq;
    results.BzPair.B0 = B0;
    results.BzPair.Bx = reshape(Bcube(:,1), sz);
    results.BzPair.By = reshape(Bcube(:,2), sz);
    results.BzPair.Bz = reshape(Bcube(:,3), sz);
    results.BzPair.Bmag = reshape(vecnorm(Bcube,2,2), sz);
end

%% -------------------- Save --------------------
save(outMatFile, 'results');
fprintf('\nSaved results to %s\n', outMatFile);

%% -------------------- Quick plots (optional) --------------------
if makeQuickPlots
    if isfield(results,'BxPair')
        figure('Color','w');
        imagesc(x_mm, y_mm, squeeze(results.BxPair.Bx(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar;
        xlabel('x [mm]'); ylabel('y [mm]');
        title('Bx from Bx-pair in plane z=0 [T]');
    end

    if isfield(results,'ByPair')
        figure('Color','w');
        imagesc(x_mm, y_mm, squeeze(results.ByPair.By(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar;
        xlabel('x [mm]'); ylabel('y [mm]');
        title('By from By-pair in plane z=0 [T]');
    end

    if isfield(results,'BzPair')
        figure('Color','w');
        imagesc(x_mm, y_mm, squeeze(results.BzPair.Bz(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar;
        xlabel('x [mm]'); ylabel('y [mm]');
        title('Bz from Bz-pair in plane z=0 [T]');
    end
end

fprintf('\nDone.\n');

%% =====================================================================
%%                              FUNCTIONS
%% =====================================================================

function [Bcube, Ireq, B0_scaled] = computePairScaled(whichPair, r_m, P, Btarget, NsubSquare, NphiCircle)
% Compute field for 1 A, scale current to get target component at origin, then compute full cube.

    r0 = [0 0 0];  % origin
    B1 = computePairField(whichPair, r0, 1.0, P, NsubSquare, NphiCircle);

    switch whichPair
        case 'Bx'
            comp = 1;
        case 'By'
            comp = 2;
        case 'Bz'
            comp = 3;
        otherwise
            error('Unknown pair "%s"', whichPair);
    end

    if abs(B1(comp)) < 1e-15
        error('%s-pair: field component at origin for 1 A is ~0; cannot scale.', whichPair);
    end

    Ireq = Btarget / B1(comp);  % keep sign (can be negative depending on orientation)
    fprintf('For 1 A: B(0) = [%.3e %.3e %.3e] T\n', B1(1), B1(2), B1(3));
    fprintf('Scaling current: I = %.6g A to get %s(0)=%.3f T\n', Ireq, whichPair, Btarget);

    Bcube = computePairField(whichPair, r_m, Ireq, P, NsubSquare, NphiCircle);
    B0_scaled = computePairField(whichPair, r0, Ireq, P, NsubSquare, NphiCircle);
    fprintf('Check after scaling: B(0) = [%.6f %.6f %.6f] T\n', B0_scaled(1), B0_scaled(2), B0_scaled(3));
end

function B = computePairField(whichPair, r_m, I, P, NsubSquare, NphiCircle)
% Compute field at points r_m (Nx3 or 1x3) for selected pair and current I.

    if isrow(r_m)
        r_m = reshape(r_m, 1, 3);
    end
    if size(r_m,2) ~= 3
        error('r_m must be Nx3');
    end

    mu0 = 4*pi*1e-7;
    B = zeros(size(r_m));

    s = P.s_mm * 1e-3;
    d = P.d_mm * 1e-3;

    switch whichPair
        case 'By'
            % Two square loops in xz plane at y=±d
            loop1 = squareLoopXZ(+d, s);
            loop2 = squareLoopXZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'Bx'
            % Two square loops in yz plane at x=±d
            loop1 = squareLoopYZ(+d, s);
            loop2 = squareLoopYZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'Bz'
            % Two circular loops in xy plane at z=±z_bz with radius R_bz
            R  = P.R_bz_mm * 1e-3;
            z0 = P.z_bz_mm * 1e-3;

            circ1 = circleLoopXY(+z0, R, NphiCircle);
            circ2 = circleLoopXY(-z0, R, NphiCircle);

            % For circle, NsubPerSegment=1 is enough since we already segment the circle finely
            B = B + biotSavartPolyline(r_m, circ1, I, mu0, 1);
            B = B + biotSavartPolyline(r_m, circ2, I, mu0, 1);

        otherwise
            error('Unknown pair "%s"', whichPair);
    end
end

function pts = squareLoopXZ(y0, s)
% Closed polyline (5 points) for square loop in xz plane at y=y0.
% Corners: (±s, y0, ±s)
    pts = [
        -s, y0, -s;
         s, y0, -s;
         s, y0,  s;
        -s, y0,  s;
        -s, y0, -s
    ];
end

function pts = squareLoopYZ(x0, s)
% Closed polyline (5 points) for square loop in yz plane at x=x0.
% Corners: (x0, ±s, ±s)
    pts = [
        x0, -s, -s;
        x0,  s, -s;
        x0,  s,  s;
        x0, -s,  s;
        x0, -s, -s
    ];
end

function pts = circleLoopXY(z0, R, Nphi)
% Closed polyline for circle in xy plane at z=z0 with radius R.
    phi = linspace(0, 2*pi, Nphi+1);
    pts = [R*cos(phi(:)), R*sin(phi(:)), z0*ones(numel(phi),1)];
end

function B = biotSavartPolyline(r, pts, I, mu0, NsubPerSegment)
% Biot–Savart field from a closed polyline defined by pts (Mx3, last=first).
% Each segment is subdivided into NsubPerSegment straight line elements.
%
% dB = mu0 I / (4π) * (dl × R) / |R|^3

    if pts(1,1)~=pts(end,1) || pts(1,2)~=pts(end,2) || pts(1,3)~=pts(end,3)
        error('Polyline must be closed (last point must equal first).');
    end

    pref = (mu0*I)/(4*pi);
    B = zeros(size(r));

    M = size(pts,1) - 1; % number of segments
    for m = 1:M
        p1 = pts(m,:);
        p2 = pts(m+1,:);
        B = B + pref * biotFromSegmentSubdiv(r, p1, p2, NsubPerSegment);
    end
end

function dB = biotFromSegmentSubdiv(r, p1, p2, Nsub)
% Contribution from a straight segment p1->p2 using Nsub midpoint elements.

    v = (p2 - p1);
    dl = v / Nsub;  % 1x3

    % Midpoints of each sub-element
    k = (1:Nsub)';
    rp = p1 + (k - 0.5) .* (v / Nsub);   % Nsub x 3

    dB = zeros(size(r));

    % Loop over elements (Nsub ~ 60); vectorized over field points
    for j = 1:Nsub
        R = r - rp(j,:);                     % Nx3
        R2 = sum(R.^2, 2);                   % Nx1
        R3 = (R2 .* sqrt(R2));               % Nx1

        % Avoid singularities exactly on the filament (rare in your grid)
        mask = (R3 > 0);
        if ~any(mask); continue; end

        Rx = R(mask,1); Ry = R(mask,2); Rz = R(mask,3);

        % cross(dl, R) with dl fixed
        cx = dl(2)*Rz - dl(3)*Ry;
        cy = dl(3)*Rx - dl(1)*Rz;
        cz = dl(1)*Ry - dl(2)*Rx;

        invR3 = 1 ./ R3(mask);

        dB(mask,1) = dB(mask,1) + cx .* invR3;
        dB(mask,2) = dB(mask,2) + cy .* invR3;
        dB(mask,3) = dB(mask,3) + cz .* invR3;
    end
end

function P = readGeometryParams(fname)
% Parse required parameters from your geometry .m file without executing it.

    if ~isfile(fname)
        error('Geometry file not found: %s', fname);
    end
    txt = fileread(fname);

    P.d_mm        = readAssignNumber(txt, 'd');
    P.a_mm        = readAssignNumber(txt, 'a');
    P.L_coil_mm   = readAssignNumber(txt, 'L_coil');
    P.s_mm        = readAssignNumber(txt, 's');
    P.r_circle_mm = readAssignNumber(txt, 'r_circle');

    % In your geometry: R_bz = r_circle + a/2
    P.R_bz_mm = P.r_circle_mm + P.a_mm/2;

    % In your geometry: z_bz was set equal to s (coil pair at z=±s)
    % If you later change the geometry file to define z_bz explicitly, this keeps working:
    if hasAssign(txt,'z_bz')
        P.z_bz_mm = readAssignNumber(txt, 'z_bz');
    else
        P.z_bz_mm = P.s_mm;
    end
end

function tf = hasAssign(txt, varname)
    pat = ['(?m)^\s*' , regexptranslate('escape',varname) , '\s*='];
    tf = ~isempty(regexp(txt, pat, 'once'));
end

function val = readAssignNumber(txt, varname)
% Parses lines like: varname = 33.1;  (spaces allowed)

    pat = ['(?m)^\s*' , regexptranslate('escape',varname) , '\s*=\s*([0-9Ee\+\-\.]+)\s*;'];
    tok = regexp(txt, pat, 'tokens', 'once');
    if isempty(tok)
        error('Could not parse "%s" from geometry file.', varname);
    end
    val = str2double(tok{1});
    if ~isfinite(val)
        error('Parsed "%s" but it is not a finite number.', varname);
    end
end
