% toyMC_bunch_assignment_with_plots_v3_fixed.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% Diagnostic plots for presentations and PNG export for LaTeX.
%
% Key idea:
%  - Measured dt = t_hit - floor(t_hit/tau_b)*tau_b  (in [0,tau_b))
%  - Test candidate offsets n = 0..nmax
%  - Accept best n if | (dt + n*tau_b) - tTOF_pred | < k*sigma_eff

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Physics and geometry
P.mp_GeV      = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns  = 0.299792458;      % speed of light in m/ns
P.Lpath_m     = 0.220;            % effective flight path (m), toy model

% Bunch timing
P.tau_b_ns        = 11.027;       % bunch spacing (ns)
P.sigma_bunch_ns  = 0.200;        % rms bunch temporal width (ns)
P.sigma_model_ns  = 0.0;          % extra model uncertainty (ns), optional

% Detector timing scenarios
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;                   % test n = 0..nmax
P.window_k = 3.0;                 % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges = [ ...
    0.0005, 0.0015, 0.0025, 0.0040, ...
    0.0075, 0.0125, 0.0175, 0.0250, 0.0350 ];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins     = numel(P.t_centers);

% Plot export
P.writePNGs = true;
P.pngDPI    = 300;                % 300 for LaTeX
P.figPosIn  = [1 1 8.5 5.5];      % inches

% Plot defaults (LaTeX friendly)
set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultLegendFontSize', 24, ...
    'defaultFigureColor', 'w');

rng(1);

%% -------------------- Generate truth |t| --------------------
% Choose a bin uniformly, then uniform within that bin
bin_id = randi(P.Nbins, P.Nevents, 1);   % column vector

% Force column vectors to avoid dimension mismatch
bin_id = bin_id(:);

% Get bin edges - CRITICAL: ensure these stay as column vectors
t_lo = P.t_edges(bin_id);
t_hi = P.t_edges(bin_id + 1);

% Force column vectors
t_lo = t_lo(:);
t_hi = t_hi(:);

% Uniform within bin (all column vectors)
t_true = t_lo + (t_hi - t_lo) .* rand(P.Nevents, 1);   % (GeV/c)^2

% Recoil kinematics (toy)
TR_GeV = t_true ./ (2*P.mp_GeV);        % TR in GeV (non-rel approx in CNI)
p_GeV  = sqrt(t_true);                  % p_R ~ sqrt(|t|) (GeV/c)
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

tTOF_true_ns = P.Lpath_m ./ (beta * P.c_m_per_ns);     % ns

%% -------------------- Assign a true bunch and build measured times --------------------
% True bunch index (only relative offsets matter)
b_true = randi(2000, P.Nevents, 1);     % arbitrary large range

% Bunch arrival time jitter (intrinsic bunch width)
dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

% Ideal measured hit time stamp (ns)
t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns;

% Measured dt relative to the "current" bunch marker:
b0     = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;            % in [0,tau_b)

% True offset in the bunch search convention
n_true = b0 - b_true;                                  % integer >= 0 typically

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;                                      % 1 x Nn
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

% Keep one scenario as reference for diagnostic plots
ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    % Add detector timing noise
    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    % Effective sigma for window
    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    % Predicted TOF from measured energy (toy: use truth here)
    tTOF_pred_ns = tTOF_true_ns;

    % Residuals for candidate n: res = (dt_meas + n*tau_b) - tTOF_pred
    % Nevents x Nn (with implicit expansion only in 2nd dimension)
    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);      % Nevents x Nn
    res_ns  = cand_ns - tTOF_pred_ns;                   % Nevents x Nn

    % Best n by minimum absolute residual
    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';                         % column

    % Window cut
    accept = absmin < (P.window_k * sigma_eff_ns);

    % Correct bunch assignment
    correct = accept & (n_best == n_true);

    % Bin-by-bin correct fraction
    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    % Save reference arrays
    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns    = dt_meas_ns;
        REF.tTOF_pred_ns  = tTOF_pred_ns;
        REF.n_best        = n_best;
        REF.n_true        = n_true;
        REF.accept        = accept;
        REF.bin_id        = bin_id;
        REF.sigma_eff_ns  = sigma_eff_ns;
        REF.res_ns        = res_ns;                     % Nevents x Nn
        REF.t_true        = t_true;
    end
end

%% -------------------- Plot 1: Correct fraction vs |t| --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on');
box(ax,'on');
grid(ax,'on');

% Define nice colors (colorblind-friendly palette)
colors = [
    0.00, 0.45, 0.74;  % blue
    0.85, 0.33, 0.10;  % red-orange
    0.93, 0.69, 0.13;  % yellow
    0.49, 0.18, 0.56;  % purple
    0.47, 0.67, 0.19;  % green
    0.30, 0.75, 0.93;  % cyan
];

h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), '-o', ...
        'LineWidth', 2.5, ...
        'MarkerSize', 10, ...
        'MarkerFaceColor', colors(is,:), ...
        'Color', colors(is,:));
end

% Formatting
set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '$|t|$ [(GeV/$c$)$^2$]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');
ylabel(ax, 'Correct bunch fraction', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');

% Y-axis limits
ylim(ax, [0.7, 1.02]);
xlim(ax, [0, max(P.t_edges)]);

% Create legend labels in LaTeX format
leg = cell(numel(P.sigma_det_ns_list), 1);
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('$\\sigma_{\\mathrm{det}} = %.1f$ ns', P.sigma_det_ns_list(is));
end

% Legend outside to the right with LaTeX interpreter
lgd = legend(ax, h, leg, ...
    'Location', 'eastoutside', ...
    'Box', 'on', ...
    'Interpreter', 'latex', ...    % Changed from 'tex' to 'latex'
    'FontSize', 18);

% Tighten layout
ax.Position(3) = 0.62;  % Make plot narrower to fit legend

if P.writePNGs
    exportgraphics(fig, sprintf('toyMC_correctFraction_vs_t_k%.1f.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_correctFraction_vs_t_k%.1f.png\n', P.window_k);
end

%% -------------------- Plot 2: tTOF vs |t| with m*tau_b lines --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig); 
hold(ax,'on'); 
box(ax,'on');
grid(ax,'on');

tgrid = linspace(min(P.t_edges), max(P.t_edges), 600).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
tTOFgrid = P.Lpath_m ./ (betagrid * P.c_m_per_ns);

% Main TOF curve - thicker and darker
plot(ax, tgrid, tTOFgrid, '-', 'LineWidth', 3.5, 'Color', [0.0 0.3 0.7]);

% Bunch spacing lines - solid, gray
mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(ax, m*P.tau_b_ns, '-', ...
        'LineWidth', 1.8, ...
        'Color', [0.85 0.33 0.10], ...
        'Alpha', 1);
    % Add text label at the right side
    text(ax, max(P.t_edges)*0.98, m*P.tau_b_ns, ...
        sprintf(' %d\\tau_b', m), ...
        'FontSize', 24, ...
        'VerticalAlignment', 'bottom', ...
        'HorizontalAlignment', 'right', ...
        'Color', [0.85 0.33 0.10]);
end

% Formatting
set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '|{\it t}| [(GeV/{\it c})^2]', 'FontSize', 24, 'FontWeight', 'bold');
ylabel(ax, '{\it t}_{TOF} [ns]', 'FontSize', 24, 'FontWeight', 'bold');
% title(ax, sprintf('Time-of-Flight vs Momentum Transfer (L = %.0f mm)', 1e3*P.Lpath_m), ...
%    'FontSize', 22, 'FontWeight', 'bold');

% Set reasonable axis limits
xlim(ax, [0, max(P.t_edges)]);
ylim(ax, [0, 30]);

if P.writePNGs
    exportgraphics(fig, 'toyMC_tTOF_vs_t.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_tTOF_vs_t.png\n');
end

%% -------------------- Plot 3: Residual histograms for reference sigma_det --------------------
if ref_keep
    % residual of best candidate
    [~, idxBest] = min(abs(REF.res_ns), [], 2);
    resBest = REF.res_ns(sub2ind(size(REF.res_ns), (1:P.Nevents).', idxBest));

    % Choose two bins
    ib1 = 1;
    ib2 = min(P.Nbins, 5);

    % Bin 1
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib1) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Time-of-flight residual $r_n$ [ns]', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Probability density', ...
       'Interpreter','latex', 'FontSize',36);
    %title(ax, sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ...
    %    ib1, ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f.png', ib1, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f.png\n', ib1, ref_sigma_det);
    end

    % Bin 2
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');
    idx = (REF.bin_id == ib2) & REF.accept;

    histogram(ax, resBest(idx), 200, 'Normalization','pdf');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Time-of-flight residual $r_n$ [ns]', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Probability density', ...
       'Interpreter','latex', 'FontSize',36);
    %title(ax, sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ...
    %    ib2, ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_residualHist_bin%d_sigmaDet%.1f.png', ib2, ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_residualHist_bin%d_sigmaDet%.1f.png\n', ib2, ref_sigma_det);
    end
end

%% -------------------- Plot 4: n_best distribution and dt mod tau_b diagnostic --------------------
if ref_keep
    % n_best distribution
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

    histogram(ax, REF.n_best(REF.accept), 'BinMethod','integers');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Selected bunch offset $n_{\rm best}$', 'FontSize', 36, 'Interpreter', 'latex');
    ylabel(ax, 'Counts (accepted)', 'FontSize', 36, 'Interpreter', 'latex');
    %title(ax, sprintf('Chosen bunch offsets, \\sigma_{det}=%.1f ns, k=%.1f', ...
    %    ref_sigma_det, P.window_k), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_nBest_sigmaDet%.1f.png', ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_nBest_sigmaDet%.1f.png\n', ref_sigma_det);
    end

    % dt mod tau_b vs |t| (subset)
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

    Nsub = min(20000, P.Nevents);
    dt_mod = mod(REF.dt_meas_ns, P.tau_b_ns);

    scatter(ax, REF.t_true(1:Nsub), dt_mod(1:Nsub), 18, 'filled');
    set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, '|t| [(GeV/c)^2]', 'FontSize', 36);
    ylabel(ax, 't_{hit} mod \tau_b [ns]', 'FontSize', 36);
    title(ax, sprintf('Diagnostic scatter (subset), \\sigma_{det}=%.1f ns', ...
        ref_sigma_det), 'FontSize', 34, 'FontWeight','bold');

    if P.writePNGs
        exportgraphics(fig, sprintf('toyMC_dtMod_vs_t_sigmaDet%.1f.png', ref_sigma_det), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: toyMC_dtMod_vs_t_sigmaDet%.1f.png\n', ref_sigma_det);
    end
end

%% -------------------- Done --------------------
fprintf('\nAll done.\n');