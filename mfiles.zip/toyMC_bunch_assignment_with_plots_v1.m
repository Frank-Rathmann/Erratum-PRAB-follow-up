% toyMC_bunch_assignment_with_plots_v1.m
%
% Self-contained toy MC for recoil-proton bunch assignment with detailed plots.
% Writes publication-ready PNGs for LaTeX.
%
% Conventions
%  - |t| in (GeV/c)^2
%  - times in ns
%  - p_R ~= sqrt(|t|) (GeV/c), beta from relativistic kinematics
%  - t_TOF = L_path / (beta c)
%  - measured Delta_t = (t_hit - t0) modulo tau_b (i.e. folded to [0,tau_b))
%  - bunch assignment searches integer n = 0..nmax such that:
%        residual(n) = (Delta_t_meas + n*tau_b) - t_TOF_pred
%    accept if min |residual| < k*sigma_eff, with sigma_eff^2 = sigma_det^2 + sigma_model^2
%
% Output
%  - fig_correct_vs_t.png
%  - fig_tof_vs_t.png
%  - fig_residual_examples.png
%  - fig_residual_hist_by_tbin.png
%  - fig_n_solution_multiplicity.png
%  - fig_delta_t_folded_vs_tof.png
%
% No external functions required.

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Statistics and scanning
P.Nevents = 1000000;
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch structure
P.tau_b_ns = 11.027;        % EIC flattop example
P.sigma_bunch_ns = 0.200;   % rms bunch temporal width (Table II type number)

% Bunch assignment search and consistency window
P.nmax = 5;                 % test n = 0..nmax
P.window_k = 3.0;           % accept if |residual| < k*sigma_eff
P.sigma_model_ns = 0.0;     % extra model uncertainty (path length, calibration), optional

% Kinematics and TOF model
P.mp_GeV = 0.9382720813;    % proton mass
P.Lpath_m = 0.220;          % representative trajectory length (straight-line baseline)

% |t| sampling and binning (CNI region)
P.t_min = 0.002;            % (GeV/c)^2
P.t_max = 0.019;
P.Nt_bins = 9;              % to match your style of points
P.t_edges = linspace(P.t_min, P.t_max, P.Nt_bins+1);
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));

% Plot and export
P.outdir = 'toyMC_plots';
P.pngDPI = 300;

% RNG
rng(1);

if ~exist(P.outdir,'dir')
    mkdir(P.outdir);
end

%% -------------------- Helpers --------------------
c_m_per_ns = 0.299792458;   % speed of light in m/ns

% sample |t| uniformly within bins to get stable per-bin statistics
bin_id = randi(P.Nt_bins, P.Nevents, 1);
t_true = P.t_edges(bin_id) + (P.t_edges(bin_id+1) - P.t_edges(bin_id)).*rand(P.Nevents,1); % (GeV/c)^2

% recoil momentum p ~= sqrt(|t|) in GeV/c
p_GeV = sqrt(t_true);

% beta from relativistic kinematics
beta = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

% true TOF in ns
tTOF_true = P.Lpath_m ./ (beta * c_m_per_ns);

% choose a true bunch offset for bookkeeping
% setting all to 0 is sufficient, but randomizing is also fine
n_true = randi(P.nmax+1, P.Nevents, 1) - 1;   % uniform in [0..nmax]

% machine reference time t0 for each event, include intrinsic bunch width
t0_smear = P.sigma_bunch_ns .* randn(P.Nevents,1);

% detector hit-time smearing (will be added per sigma_det scenario)
% model smearing optional (added in sigma_eff only)

%% -------------------- Precompute predicted TOF model --------------------
% In a pure toy model we assume the predictor uses the same Lpath and kinematics.
tTOF_pred = tTOF_true;

% The measured Delta_t is folded into [0,tau_b) by definition:
% Delta_t_meas = mod( (t_hit - t0), tau_b )
% where t_hit - t0 = tTOF_true - n_true*tau_b + det_smear
% Folding removes absolute bunch index and creates the ambiguity.

%% -------------------- Core results containers --------------------
correctFrac = zeros(numel(P.sigma_det_ns_list), P.Nt_bins);
ambigFrac   = zeros(numel(P.sigma_det_ns_list), P.Nt_bins); % more than one n accepted
failFrac    = zeros(numel(P.sigma_det_ns_list), P.Nt_bins); % no n accepted

% For diagnostic plots: keep one representative sigma_det scenario
sigma_det_diag = 3.0;
keep_diag = false(numel(P.sigma_det_ns_list),1);
[~,idxDiag] = min(abs(P.sigma_det_ns_list - sigma_det_diag));
keep_diag(idxDiag) = true;

diag = struct();

%% -------------------- Loop over detector timing resolutions --------------------
for is = 1:numel(P.sigma_det_ns_list)
    sigma_det = P.sigma_det_ns_list(is);

    % measured time difference (folded)
    det_smear = sigma_det .* randn(P.Nevents,1);
    delta_t_unfolded = (tTOF_true - n_true.*P.tau_b_ns) + det_smear;   % relative to ideal t0
    delta_t_meas = mod(delta_t_unfolded - t0_smear, P.tau_b_ns);       % fold to [0,tau_b)

    sigma_eff = sqrt(sigma_det^2 + P.sigma_model_ns^2);

    % evaluate residuals for all candidate n
    % residual matrix: Nevents x (nmax+1)
    n_list = 0:P.nmax;
    residual = (delta_t_meas + n_list) - tTOF_pred;  % implicit expansion (R2016b+)
    absres = abs(residual);

    % accept candidates within window
    accept = absres < (P.window_k * sigma_eff);

    % choose best n by minimum |residual|
    [minAbsRes, idxMin] = min(absres, [], 2);
    n_best = n_list(idxMin)';

    % accepted solution count
    nAccepted = sum(accept, 2);

    % classification
    ok_any  = (nAccepted >= 1);
    ok_uniq = (nAccepted == 1);
    ok_amb  = (nAccepted >= 2);

    correct = ok_any & (n_best == n_true);

    % per-|t| bin stats
    for ib = 1:P.Nt_bins
        m = (bin_id == ib);
        if ~any(m), continue; end

        correctFrac(is,ib) = mean(correct(m));
        ambigFrac(is,ib)   = mean(ok_amb(m));
        failFrac(is,ib)    = mean(~ok_any(m));
    end

    % store diagnostics for one scenario
    if keep_diag(is)
        diag.sigma_det = sigma_det;
        diag.delta_t_meas = delta_t_meas;
        diag.tTOF_pred = tTOF_pred;
        diag.t_true = t_true;
        diag.bin_id = bin_id;
        diag.residual = residual;
        diag.accept = accept;
        diag.n_true = n_true;
        diag.n_best = n_best;
        diag.nAccepted = nAccepted;
        diag.minAbsRes = minAbsRes;
        diag.sigma_eff = sigma_eff;
    end
end

%% -------------------- Plot 1: Correct bunch fraction vs |t| --------------------
figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
hold on; grid on;
for is = 1:numel(P.sigma_det_ns_list)
    plot(P.t_centers, correctFrac(is,:), 'o-','LineWidth',2,'MarkerSize',6);
end
xlabel('|t| [(\mathrm{GeV}/c)^2]','FontSize',18);
ylabel('Correct bunch fraction','FontSize',18);
title(sprintf('Toy MC bunch assignment, window k = %.1f, Nevents = %d', P.window_k, P.Nevents), ...
    'FontSize',18,'FontWeight','bold');

leg = cell(size(P.sigma_det_ns_list));
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('\\sigma_{\\mathrm{det}} = %.1f ns', P.sigma_det_ns_list(is));
end
legend(leg,'Location','southeast','FontSize',12);

exportgraphics(gcf, fullfile(P.outdir,'fig_correct_vs_t.png'), 'Resolution', P.pngDPI);

%% -------------------- Plot 2: t_TOF vs |t| (with tau_b overlay) --------------------
% show the deterministic relation and where it crosses multiples of tau_b
tt = linspace(P.t_min, P.t_max, 400)';
p = sqrt(tt);
bb = p ./ sqrt(p.^2 + P.mp_GeV^2);
tTOF = P.Lpath_m ./ (bb * c_m_per_ns);

figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
plot(tt, tTOF, 'LineWidth',2); grid on; hold on;
xlabel('|t| [(\mathrm{GeV}/c)^2]','FontSize',18);
ylabel('t_{\mathrm{TOF}} [ns]','FontSize',18);
title(sprintf('Recoil time of flight for L_{\\mathrm{path}} = %.0f mm', 1e3*P.Lpath_m), ...
    'FontSize',18,'FontWeight','bold');

for n = 0:P.nmax
    yline(n*P.tau_b_ns, ':', sprintf('%d\\tau_b', n), 'LabelVerticalAlignment','bottom');
end
yline(P.tau_b_ns, '--', '\\tau_b', 'LabelVerticalAlignment','bottom');

exportgraphics(gcf, fullfile(P.outdir,'fig_tof_vs_t.png'), 'Resolution', P.pngDPI);

%% -------------------- Plot 3: Folded Delta_t vs predicted TOF (diagnostic) --------------------
% audience-friendly: show the modulo ambiguity
figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
idx = randperm(P.Nevents, min(30000,P.Nevents)); % thin for plotting
scatter(diag.tTOF_pred(idx), diag.delta_t_meas(idx), 6, 'filled'); grid on;
xlabel('t_{\mathrm{TOF,pred}} [ns]','FontSize',18);
ylabel('\Delta t_{\mathrm{meas}} = (t_{\mathrm{hit}}-t_0)\bmod \tau_b [ns]','FontSize',18);
title(sprintf('Modulo timing observable, \\sigma_{\\mathrm{det}} = %.1f ns', diag.sigma_det), ...
    'FontSize',18,'FontWeight','bold');
xline(P.tau_b_ns,'--','\\tau_b');
exportgraphics(gcf, fullfile(P.outdir,'fig_delta_t_folded_vs_tof.png'), 'Resolution', P.pngDPI);

%% -------------------- Plot 4: Residual curves for a few example events --------------------
% show residual(n) vs n and the acceptance window
figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
hold on; grid on;

ex = randperm(P.Nevents, 6);
n_list = 0:P.nmax;
for k = 1:numel(ex)
    i = ex(k);
    plot(n_list, diag.residual(i,:), 'o-','LineWidth',1.8,'MarkerSize',5);
end
yline(+P.window_k*diag.sigma_eff,'--',sprintf('+k\\sigma_{\\mathrm{eff}} (k=%.1f)',P.window_k));
yline(-P.window_k*diag.sigma_eff,'--',sprintf('-k\\sigma_{\\mathrm{eff}}'));
xlabel('Candidate bunch offset n','FontSize',18);
ylabel('Residual r(n) = (\Delta t_{\mathrm{meas}} + n\tau_b) - t_{\mathrm{TOF,pred}} [ns]','FontSize',18);
title(sprintf('Residual vs n (examples), \\sigma_{\\mathrm{det}} = %.1f ns', diag.sigma_det), ...
    'FontSize',18,'FontWeight','bold');

exportgraphics(gcf, fullfile(P.outdir,'fig_residual_examples.png'), 'Resolution', P.pngDPI);

%% -------------------- Plot 5: Residual histogram in low-|t| vs high-|t| bins --------------------
% pick two bins for the story: lowest |t| and highest |t|
bLo = 1;
bHi = P.Nt_bins;

figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');

% residual of best n only
bestRes = diag.residual(sub2ind(size(diag.residual), (1:P.Nevents)', diag.n_best+1));

nexttile;
histogram(bestRes(diag.bin_id==bLo), 120);
grid on;
xlabel('Best residual [ns]','FontSize',16);
ylabel('Counts','FontSize',16);
title(sprintf('Lowest |t| bin (%.3g to %.3g)', P.t_edges(bLo), P.t_edges(bLo+1)), 'FontSize',16);

nexttile;
histogram(bestRes(diag.bin_id==bHi), 120);
grid on;
xlabel('Best residual [ns]','FontSize',16);
ylabel('Counts','FontSize',16);
title(sprintf('Highest |t| bin (%.3g to %.3g)', P.t_edges(bHi), P.t_edges(bHi+1)), 'FontSize',16);

exportgraphics(gcf, fullfile(P.outdir,'fig_residual_hist_by_tbin.png'), 'Resolution', P.pngDPI);

%% -------------------- Plot 6: Multiplicity of accepted solutions --------------------
% show how often the window admits 0,1,2,... solutions
figure('Color','w','Units','inches','Position',[1 1 8.5 5.5]);
edges = -0.5:1:(P.nmax+1.5);
histogram(diag.nAccepted, edges);
grid on;
xlabel('Number of accepted n solutions','FontSize',18);
ylabel('Counts','FontSize',18);
title(sprintf('Solution multiplicity, \\sigma_{\\mathrm{det}} = %.1f ns', diag.sigma_det), ...
    'FontSize',18,'FontWeight','bold');

exportgraphics(gcf, fullfile(P.outdir,'fig_n_solution_multiplicity.png'), 'Resolution', P.pngDPI);

%% -------------------- Print short summary --------------------
fprintf('\nToy MC completed.\n');
fprintf('Wrote PNGs to folder: %s\n', P.outdir);
fprintf('Diagnostic sigma_det used: %.1f ns\n', diag.sigma_det);
fprintf('k in the window is the multiplicative factor in |residual| < k * sigma_eff.\n');
fprintf('sigma_eff = sqrt(sigma_det^2 + sigma_model^2).\n');
