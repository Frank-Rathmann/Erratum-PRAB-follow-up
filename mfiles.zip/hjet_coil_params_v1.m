function P = hjet_coil_params_v1()
% hjet_coil_params_v1
% Single source of truth for coil geometry numbers (mm).
% Used by:
%   - xyz_sketch_3d_det220_plusBz_v9.m (visualization)
%   - compute_fields_from_geometry_v7d.m (field maps)
%   - Stage-6 absorber mask (track termination in coil material)

P = struct();

% Square coil pairs (Bx / By)
P.d_mm      = 80;     % coil offset / half separation
P.a_mm      = 20;     % conductor square cross section side
P.L_coil_mm = 66.2;   % coil loop side length
P.s_mm      = 33.1;   % half spacing (L_coil/2)

% Bz circular pair (centered on z-axis)
P.r_circle_mm = 50;                   % inner circle radius used in sketch
P.R_bz_mm     = P.r_circle_mm + P.a_mm/2;  % = 60 mm
P.z_bz_mm     = P.s_mm;               % = 33.1 mm

% Convenience derived values
P.Rin_bz_mm  = P.R_bz_mm - P.a_mm/2;  % = 50 mm
P.Rout_bz_mm = P.R_bz_mm + P.a_mm/2;  % = 70 mm
end
