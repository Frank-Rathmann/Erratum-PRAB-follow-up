% toyMC_bunch_assignment_with_plots_v7_consolidated_FIXED.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% FIXED: Restored proper LaTeX rendering that was working in v6

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Physics
P.mp_GeV      = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns  = 0.299792458;      % speed of light in m/ns

% Detector geometry (cylinder)
P.Rdet_m      = 0.220;            % detector radius (m)

% Beam beta for bunch-passage timing shift across z0
P.beta_beam   = 1.0;              % approx 1 at EIC flattop

% Vertex distribution (EIC IP4 flattop, Table II)
P.sigma_x_m   = 1.610e-3;         % sigma_x = 1.610 mm
P.sigma_y_m   = 0.268e-3;         % sigma_y = 0.268 mm
P.z0_min_m    = -5e-3;            % -5 mm
P.z0_max_m    = +5e-3;            % +5 mm

% Bunch timing
P.tau_b_ns        = 11.027;       % bunch spacing (ns), EIC flattop
P.sigma_bunch_ns  = 0.200;        % rms bunch temporal width (ns)
P.sigma_model_ns  = 0.0;          % extra model uncertainty (ns), optional

% Detector timing scenarios - EXTENDED RANGE FOR SYSTEMATIC STUDY
P.sigma_det_ns_list = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;                   % test n = 0..nmax
P.window_k = 5.0;                 % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges = [ ...
    0.0005, 0.0015, 0.0025, 0.0040, ...
    0.0075, 0.0125, 0.0175, 0.0250, 0.0350 ];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins     = numel(P.t_centers);

% Plot export
P.writePNGs = true;
P.pngDPI    = 300;                % 300 for LaTeX
P.figPosIn  = [1 1 10 6];         % inches, wider for legend

% Plot defaults (LaTeX friendly) - RESTORED
set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultLegendFontSize', 24, ...
    'defaultFigureColor', 'w');

rng(1);

%% -------------------- Generate truth |t| --------------------
bin_id = randi(P.Nbins, P.Nevents, 1);
bin_id = bin_id(:);

t_lo = P.t_edges(bin_id);
t_hi = P.t_edges(bin_id + 1);
t_lo = t_lo(:);
t_hi = t_hi(:);

t_true = t_lo + (t_hi - t_lo) .* rand(P.Nevents, 1);   % (GeV/c)^2

% Recoil kinematics
TR_GeV = t_true ./ (2*P.mp_GeV);
p_GeV  = sqrt(t_true);
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

%% -------------------- Vertex sampling --------------------
x0_m = P.sigma_x_m .* randn(P.Nevents,1);
y0_m = P.sigma_y_m .* randn(P.Nevents,1);
z0_m = P.z0_min_m + (P.z0_max_m - P.z0_min_m) .* rand(P.Nevents,1);

dt_z_ns = z0_m ./ (P.beta_beam * P.c_m_per_ns);

%% -------------------- Uniform azimuth phi, theta_R = 90 deg --------------------
phi = 2*pi .* rand(P.Nevents,1);
ux  = cos(phi);
uy  = sin(phi);

%% -------------------- Intersect with detector cylinder --------------------
B = 2*(x0_m.*ux + y0_m.*uy);
C = (x0_m.^2 + y0_m.^2 - P.Rdet_m^2);

disc = B.^2 - 4*C;
valid = disc >= 0;

s_hit = nan(P.Nevents,1);
sqrt_disc = sqrt(max(disc,0));
s_tmp = (-B + sqrt_disc) ./ 2;
s_hit(valid) = s_tmp(valid);

x_hit = x0_m + s_hit.*ux;
y_hit = y0_m + s_hit.*uy;
z_hit = z0_m;

L_m = s_hit;
tTOF_true_ns = L_m ./ (beta * P.c_m_per_ns);

%% -------------------- Assign true bunch and build measured times --------------------
b_true = randi(2000, P.Nevents, 1);
dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns + dt_z_ns;

b0     = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;

n_true = b0 - b_true;

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    tTOF_pred_ns = tTOF_true_ns;

    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);
    res_ns  = cand_ns - tTOF_pred_ns;

    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';

    accept  = absmin < (P.window_k * sigma_eff_ns);
    correct = accept & (n_best == n_true);

    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns    = dt_meas_ns;
        REF.tTOF_pred_ns  = tTOF_pred_ns;
        REF.n_best        = n_best;
        REF.n_true        = n_true;
        REF.accept        = accept;
        REF.bin_id        = bin_id;
        REF.sigma_eff_ns  = sigma_eff_ns;
        REF.res_ns        = res_ns;
        REF.t_true        = t_true;
        REF.x0_m          = x0_m;
        REF.y0_m          = y0_m;
        REF.z0_m          = z0_m;
        REF.dt_z_ns       = dt_z_ns;
        REF.phi           = phi;
        REF.x_hit         = x_hit;
        REF.y_hit         = y_hit;
        REF.z_hit         = z_hit;
        REF.L_m           = L_m;
    end
end

%% -------------------- Systematic Analysis --------------------
f_wrong = 1 - correctFrac;
f_wrong_avg_unweighted = mean(f_wrong, 1);

Ay_approx = [0.037, 0.040, 0.042, 0.043, 0.042, 0.040, 0.038, 0.035];
if numel(Ay_approx) ~= P.Nbins
    Ay_approx = 0.04 * ones(1, P.Nbins);
end

dN_dt_approx = exp(-P.t_centers / 0.01);
weight = (Ay_approx.^2 .* dN_dt_approx)';
weight = weight / sum(weight);

f_wrong_avg_weighted = f_wrong' * weight;

% Print consolidated results
fprintf('\n');
fprintf('============================================================================\n');
fprintf('           BUNCH MIS-IDENTIFICATION SYSTEMATIC ANALYSIS (k=%.1f)\n', P.window_k);
fprintf('============================================================================\n');
fprintf('Target: f_wrong < 0.001  (0.1%%)  for Delta_P/P < 0.1%%  systematic\n');
fprintf('        f_wrong < 0.0005 (0.05%%) for Delta_P/P < 0.05%% systematic\n');
fprintf('============================================================================\n\n');
fprintf('sigma_det [ns]  |  f_wrong (unweighted)  |  f_wrong (weighted)\n');
fprintf('----------------------------------------------------------------------------\n');
for is = 1:numel(P.sigma_det_ns_list)
    fprintf('    %.1f         |     %.4f  (%5.2f%%)    |    %.4f  (%5.2f%%)\n', ...
        P.sigma_det_ns_list(is), ...
        f_wrong_avg_unweighted(is), f_wrong_avg_unweighted(is)*100, ...
        f_wrong_avg_weighted(is), f_wrong_avg_weighted(is)*100);
end
fprintf('============================================================================\n\n');

% Interpolation for required timing
target_f_wrong = [0.001, 0.0005, 0.0001];
target_labels = {'0.1%', '0.05%', '0.01%'};

fprintf('REQUIRED TIMING RESOLUTION (by interpolation):\n');
fprintf('----------------------------------------------------------------------------\n');
for it = 1:numel(target_f_wrong)
    % Unweighted
    if min(f_wrong_avg_unweighted) <= target_f_wrong(it) && max(f_wrong_avg_unweighted) >= target_f_wrong(it)
        % Find unique points for interpolation
        [f_unique_unwt, idx_unwt] = unique(f_wrong_avg_unweighted(end:-1:1));
        sigma_unique_unwt = P.sigma_det_ns_list(end:-1:1);
        sigma_unique_unwt = sigma_unique_unwt(idx_unwt);
        
        if numel(f_unique_unwt) > 1
            sigma_req_unwt = interp1(f_unique_unwt, sigma_unique_unwt, ...
                target_f_wrong(it), 'linear', 'extrap');
        else
            sigma_req_unwt = NaN;
        end
    else
        if min(f_wrong_avg_unweighted) > target_f_wrong(it)
            sigma_req_unwt = Inf;  % Need better timing than tested
        else
            sigma_req_unwt = min(P.sigma_det_ns_list(f_wrong_avg_unweighted < target_f_wrong(it)));
        end
    end
    
    % Weighted
    if min(f_wrong_avg_weighted) <= target_f_wrong(it) && max(f_wrong_avg_weighted) >= target_f_wrong(it)
        % Find unique points for interpolation
        [f_unique_wt, idx_wt] = unique(f_wrong_avg_weighted(end:-1:1));
        sigma_unique_wt = P.sigma_det_ns_list(end:-1:1);
        sigma_unique_wt = sigma_unique_wt(idx_wt);
        
        if numel(f_unique_wt) > 1
            sigma_req_wt = interp1(f_unique_wt, sigma_unique_wt, ...
                target_f_wrong(it), 'linear', 'extrap');
        else
            sigma_req_wt = NaN;
        end
    else
        if min(f_wrong_avg_weighted) > target_f_wrong(it)
            sigma_req_wt = Inf;  % Need better timing than tested
        else
            sigma_req_wt = min(P.sigma_det_ns_list(f_wrong_avg_weighted < target_f_wrong(it)));
        end
    end
    
    % Format output
    if isinf(sigma_req_unwt)
        str_unwt = '> all tested (need better timing)';
    elseif isnan(sigma_req_unwt)
        str_unwt = 'N/A (insufficient data)';
    else
        str_unwt = sprintf('< %.2f ns', sigma_req_unwt);
    end
    
    if isinf(sigma_req_wt)
        str_wt = '> all tested (need better timing)';
    elseif isnan(sigma_req_wt)
        str_wt = 'N/A (insufficient data)';
    else
        str_wt = sprintf('< %.2f ns', sigma_req_wt);
    end
    
    fprintf('For f_wrong < %4s:  sigma_det %s (unwt),  %s (weighted)\n', ...
        target_labels{it}, str_unwt, str_wt);
end
fprintf('============================================================================\n\n');
% n_best distribution
if ref_keep
    fprintf('n_best DISTRIBUTION (sigma_det = %.1f ns):\n', ref_sigma_det);
    fprintf('----------------------------------------------------------------------------\n');
    for n = 0:P.nmax
        count = sum(REF.n_best(REF.accept) == n);
        fraction = count / sum(REF.accept) * 100;
        fprintf('n = %d:  %8d events (%6.3f%%)\n', n, count, fraction);
    end
    fprintf('============================================================================\n\n');
end

%% -------------------- PLOTS --------------------

% Extended color palette for 12 curves
colors = [
    0.00, 0.00, 0.80;   % dark blue
    0.00, 0.50, 0.80;   % medium blue
    0.00, 0.75, 0.75;   % cyan
    0.20, 0.80, 0.60;   % teal
    0.50, 0.85, 0.50;   % light green
    0.93, 0.69, 0.13;   % gold
    0.85, 0.33, 0.10;   % orange-red
    0.64, 0.08, 0.18;   % dark red
    0.49, 0.18, 0.56;   % purple
    0.47, 0.67, 0.19;   % green
    0.30, 0.30, 0.30;   % dark gray
    0.60, 0.40, 0.20    % brown
];

% Line styles and markers for 12 curves
lineStyles = {'-', '-', '-', '-', '-', '-', '--', '--', '--', '--', '-.', '-.'};
markers = {'o', 'o', 'o', 's', 's', 'd', 'd', '^', '^', 'v', 'v', '>'};

%% Plot 1: Correct fraction vs |t|
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), ...
        'LineStyle', lineStyles{is}, ...
        'Marker', markers{is}, ...
        'LineWidth', 2.5, ...
        'MarkerSize', 9, ...
        'MarkerFaceColor', colors(is,:), ...
        'Color', colors(is,:));
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '$|t|$ [(GeV/$c$)$^2$]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');
ylabel(ax, 'Correct bunch fraction', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');

ylim(ax, [0.7, 1.02]);
xlim(ax, [0, max(P.t_edges)]);

leg = cell(numel(P.sigma_det_ns_list), 1);
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('$\\sigma_{\\mathrm{det}} = %.1f$ ns', P.sigma_det_ns_list(is));
end

lgd = legend(ax, h, leg, ...
    'Location', 'eastoutside', ...
    'Box', 'on', ...
    'Interpreter', 'latex', ...
    'FontSize', 18);

ax.Position(3) = 0.58;

if P.writePNGs
    exportgraphics(fig, sprintf('Fig1_correctFraction_vs_t_k%.1f.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: Fig1_correctFraction_vs_t_k%.1f.png\n', P.window_k);
end

%% Plot 2: f_wrong vs sigma_det (FIXED)
fig = figure('Color','w', 'Units','inches', 'Position', [1 1 9 6]);
ax = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

h1 = plot(ax, P.sigma_det_ns_list, f_wrong_avg_unweighted*100, '-o', ...
    'LineWidth', 3, 'MarkerSize', 10, 'MarkerFaceColor', [0.0 0.45 0.74], ...
    'Color', [0.0 0.45 0.74]);

h2 = plot(ax, P.sigma_det_ns_list, f_wrong_avg_weighted*100, '-s', ...
    'LineWidth', 3, 'MarkerSize', 10, 'MarkerFaceColor', [0.85 0.33 0.10], ...
    'Color', [0.85 0.33 0.10]);

% Set axis limits BEFORE adding reference lines
set(ax, 'FontSize', 22, 'LineWidth', 1.5, 'YScale', 'log');
xlim(ax, [0, max(P.sigma_det_ns_list)*1.05]);  % Set x-limits explicitly
ylim(ax, [1e-4, 50]);

% Reference lines WITHOUT legend entry
yline(ax, 0.1, '--', 'LineWidth', 2, 'Color', [0.5 0.5 0.5], ...
    'HandleVisibility', 'off');
text(ax, max(P.sigma_det_ns_list)*0.95, 0.11, '0.1\% target', ...
    'FontSize', 16, 'Color', [0.5 0.5 0.5], 'VerticalAlignment', 'bottom', ...
    'Interpreter', 'latex');

yline(ax, 0.05, '-.', 'LineWidth', 2, 'Color', [0.7 0.7 0.7], ...
    'HandleVisibility', 'off');
text(ax, max(P.sigma_det_ns_list)*0.95, 0.055, '0.05\% target', ...
    'FontSize', 16, 'Color', [0.7 0.7 0.7], 'VerticalAlignment', 'bottom', ...
    'Interpreter', 'latex');

xlabel(ax, '$\sigma_{\mathrm{det}}$ [ns]', 'FontSize', 26, 'Interpreter', 'latex');
ylabel(ax, 'Bunch mis-identification $f_{\mathrm{wrong}}$ [\%]', ...
    'FontSize', 26, 'Interpreter', 'latex');

legend(ax, [h1, h2], {'Unweighted average', 'Weighted by $A_y^2\, dN/d|t|$'}, ...
    'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', 18);

if P.writePNGs
    exportgraphics(fig, sprintf('Fig2_fwrong_vs_sigmaDet_k%.1f.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: Fig2_fwrong_vs_sigmaDet_k%.1f.png\n', P.window_k);
end
%% Plot 3: tTOF vs |t| with bunch spacing lines
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

tgrid = linspace(min(P.t_edges), max(P.t_edges), 600).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
tTOFgrid = P.Rdet_m ./ (betagrid * P.c_m_per_ns);

plot(ax, tgrid, tTOFgrid, '-', 'LineWidth', 3.5, 'Color', [0.0 0.3 0.7]);

mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(ax, m*P.tau_b_ns, '-', ...
        'LineWidth', 1.8, ...
        'Color', [0.85 0.33 0.10], ...
        'Alpha', 1);
    text(ax, max(P.t_edges)*0.98, m*P.tau_b_ns, ...
        sprintf(' %d$\\tau_b$', m), ...
        'FontSize', 24, ...
        'VerticalAlignment', 'bottom', ...
        'HorizontalAlignment', 'right', ...
        'Color', [0.85 0.33 0.10], ...
        'Interpreter', 'latex');
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '$|t|$ [(GeV/$c$)$^2$]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');
ylabel(ax, '$t_{\mathrm{TOF}}$ [ns]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');

xlim(ax, [0, max(P.t_edges)]);
ylim(ax, [0, 30]);

if P.writePNGs
    exportgraphics(fig, 'Fig3_tTOF_vs_t.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: Fig3_tTOF_vs_t.png\n');
end

%% Plot 4: n_best distribution
if ref_keep
    fig = figure('Color','w', 'Units','inches', 'Position', [1 1 8 6]);
    ax  = axes(fig); hold(ax,'on'); grid(ax,'on'); box(ax,'on');

    histogram(ax, REF.n_best(REF.accept), 'BinMethod','integers', ...
        'FaceColor', [0.3 0.5 0.8], 'EdgeColor', 'k', 'LineWidth', 1.2);
    set(ax, 'FontSize', 28, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
    xlabel(ax, 'Selected bunch offset $n_{\mathrm{best}}$', 'FontSize', 32, 'Interpreter', 'latex');
    ylabel(ax, 'Counts (accepted)', 'FontSize', 32, 'Interpreter', 'latex');
    title(ax, sprintf('$\\sigma_{\\mathrm{det}} = %.1f$ ns, $k = %.1f$', ref_sigma_det, P.window_k), ...
        'FontSize', 30, 'Interpreter', 'latex');

    if P.writePNGs
        exportgraphics(fig, sprintf('Fig4_nBest_sigmaDet%.1f_k%.1f.png', ref_sigma_det, P.window_k), ...
            'Resolution', P.pngDPI);
        fprintf('Wrote: Fig4_nBest_sigmaDet%.1f_k%.1f.png\n', ref_sigma_det, P.window_k);
    end
end

%% Done
fprintf('\nAll figures and analysis complete (v7: k=%.1f, LaTeX fixed).\n\n', P.window_k);