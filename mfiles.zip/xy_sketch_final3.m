% xy_sketch_final3.m
% Step 1: All 22.5° construction lines with IDENTICAL dash style

clear; close all; clc;

%% Parameters
r_det   = 220;     % detector radius [mm]
detLen  = 100;     % detector bar length [mm]
detLW   = 6;       % detector line width
detCol  = [1 0 1]; % magenta

d       = 80;      % coil offset (centerline) [mm]
a       = 20;      % coil cross section side [mm]
s       = 50;      % half spacing between the two z-legs of one coil [mm]
coilCol = [0 0 1]; % blue
coilLW  = 2.0;

r_circle = 50;     % inner circle radius [mm]
oct_R    = 115;    % octagon "radius" to vertices [mm]
octCol   = [1.0 0.6 0.0]; % orange
octLW    = 2.5;

xlimv = 350;
ylimv = 250;

fs1 = 28;
fs2 = 32;

%% Figure/axes
fig = figure('Color','w','Position',[100 80 950 820]);
ax  = axes('Parent',fig); hold(ax,'on'); axis(ax,'equal');

xlim(ax,[-xlimv xlimv]);
ylim(ax,[-ylimv ylimv]);

% Axis through origin, no box
set(ax,'Box','off','XAxisLocation','origin','YAxisLocation','origin', ...
    'TickDir','out','LineWidth',1.0,'FontSize',fs1);

% Reverse x-direction so +x is to the LEFT
set(ax,'XDir','reverse');

% Note: xlabel position needs to be set AFTER the arrow position is defined
% Will set xlabel position later after arrowPos is calculated

ylabel(ax,'$y$ [mm]','FontSize',fs2,'Interpreter','latex');

%% ALL 22.5° construction lines - IDENTICAL DASH STYLE
L = 1.05*max(xlimv,ylimv);
angles = 0:22.5:337.5;

% Define ONE dash style to be used for ALL dashed lines (construction AND detector acceptance)
dashStyle = '--';
dashColor = [0 0 0];  % black
dashLW = 1.2;

for th = angles
    u = [cosd(th), sind(th)];
    p1 = -L*u;
    p2 = +L*u;
    % ALL construction lines use IDENTICAL style
    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)], dashStyle, 'Color', dashColor, 'LineWidth', dashLW);
end

%% Inner circle
t = linspace(0,2*pi,400);
plot(ax,r_circle*cos(t), r_circle*sin(t), 'Color',[0 0.45 0.35],'LineWidth',3.0);

%% Regular octagon - flat sides intercept axes at ±100 mm
k = 0:7;
phi0 = 22.5;  % Keep orientation so flats align with axes
% For octagon with phi0=22.5°, the flat sides are perpendicular to axes
% Distance from center to flat side = R * cos(22.5°)
% We want this distance = 100 mm, so R = 100/cos(22.5°)
oct_R = 100 / cosd(22.5);  % ≈ 108.24 mm
x8 = oct_R*cosd(phi0 + 45*k);
y8 = oct_R*sind(phi0 + 45*k);
plot(ax,[x8 x8(1)],[y8 y8(1)],'-','Color',octCol,'LineWidth',octLW);

%% Coils - blue squares centered on 22.5° lines
% Each coil has two squares whose centers should lie on specific 22.5° lines
% The coils are at distance d=80mm from origin

% For a square centered on a 22.5° line at distance d from origin:
% The center is at: (d/tan(angle), d) for horizontal coils
%                   (d, d*tan(angle)) for vertical coils

% Top By coil (at y=+80): squares on 67.5° and 112.5° lines
% At y=80: x = 80/tan(67.5°) for 67.5° line, x = 80/tan(112.5°) for 112.5° line
x_right_top = d / tand(67.5);   % ≈ 33.1 mm
x_left_top = d / tand(112.5);   % ≈ -33.1 mm

% Bottom By coil (at y=-80): squares on 292.5° and 247.5° lines
x_right_bot = -d / tand(67.5);  % ≈ -33.1 mm (292.5° = -67.5°)
x_left_bot = -d / tand(112.5);  % ≈ 33.1 mm (247.5° = -112.5°)

% Right Bx coil (at x=+80): squares on 22.5° and 337.5° lines
% At x=80: y = 80*tan(22.5°) for 22.5° line, y = 80*tan(337.5°) for 337.5° line
y_top_right = d * tand(22.5);   % ≈ 33.1 mm
y_bot_right = d * tand(337.5);  % ≈ -33.1 mm

% Left Bx coil (at x=-80): squares on 157.5° and 202.5° lines
y_top_left = -d * tand(22.5);   % ≈ -33.1 mm (157.5° = 180°-22.5°)
y_bot_left = -d * tand(337.5);  % ≈ 33.1 mm (202.5° = 180°+22.5°)

% Draw By coils (horizontal, parallel to x-axis)
% Top coil
drawSquare(ax, [x_left_top, d], a, coilCol, coilLW);
drawSquare(ax, [x_right_top, d], a, coilCol, coilLW);
% Connect the two squares
plot(ax, [x_left_top+a/2, x_right_top-a/2], [d+a/2, d+a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);
plot(ax, [x_left_top+a/2, x_right_top-a/2], [d-a/2, d-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);

% Bottom coil
drawSquare(ax, [x_left_bot, -d], a, coilCol, coilLW);
drawSquare(ax, [x_right_bot, -d], a, coilCol, coilLW);
% Connect the two squares
plot(ax, [x_right_bot+a/2, x_left_bot-a/2], [-d+a/2, -d+a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);
plot(ax, [x_right_bot+a/2, x_left_bot-a/2], [-d-a/2, -d-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);

% Draw Bx coils (vertical, parallel to y-axis)
% Right coil
drawSquare(ax, [d, y_bot_right], a, coilCol, coilLW);
drawSquare(ax, [d, y_top_right], a, coilCol, coilLW);
% Connect the two squares
plot(ax, [d+a/2, d+a/2], [y_bot_right+a/2, y_top_right-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);
plot(ax, [d-a/2, d-a/2], [y_bot_right+a/2, y_top_right-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);

% Left coil
drawSquare(ax, [-d, y_bot_left], a, coilCol, coilLW);
drawSquare(ax, [-d, y_top_left], a, coilCol, coilLW);
% Connect the two squares
plot(ax, [-d+a/2, -d+a/2], [y_bot_left+a/2, y_top_left-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);
plot(ax, [-d-a/2, -d-a/2], [y_bot_left+a/2, y_top_left-a/2], '-', 'Color', coilCol, 'LineWidth', coilLW);

%% Detectors (6 total) all at r = 250 mm
detAngles = [0 180 45 225 135 315];

for th = detAngles
    cx = r_det*cosd(th);
    cy = r_det*sind(th);

    % Detector bar: oriented perpendicular to radial direction
    % Tangent unit vector
    tx = -sind(th);
    ty =  cosd(th);

    p1 = [cx cy] + 0.5*detLen*[tx ty];
    p2 = [cx cy] - 0.5*detLen*[tx ty];

    % Acceptance lines from origin to BOTH outer edges of detector
    plot(ax,[0 p1(1)],[0 p1(2)], dashStyle, 'Color', dashColor, 'LineWidth', dashLW);
    plot(ax,[0 p2(1)],[0 p2(2)], dashStyle, 'Color', dashColor, 'LineWidth', dashLW);

    % Detector bar (solid line)
    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)],'-','Color',detCol,'LineWidth',detLW);
end

%% Axes arrow heads at the END
arrowLen = 60;  % Increased from 30 to 60 (2x larger)
arrowPosx = xlimv * 0.82;  % Reduced from 0.90 to keep arrows fully within plot
arrowPosy = ylimv * 0.75;  % Reduced from 0.90 to keep arrows fully within plot

% +x arrow (points LEFT due to XDir reverse) - arrow at left end pointing left
quiver(ax, arrowPosx, 0, arrowLen, 0, 0, 'k', 'LineWidth',1.8, 'MaxHeadSize',1.5);

% +y arrow (points UP) - arrow at top pointing up
quiver(ax, 0, arrowPosy, 0, arrowLen, 0, 'k', 'LineWidth',1.8, 'MaxHeadSize',1.5);

% Set xlabel position near the arrow (left side on screen = positive x value)
% Since x is reversed, positive x appears on left
xlabel(ax,'$x$ [mm]','FontSize',fs2,'Interpreter','latex','Position',[arrowPosx*0.80, -ylimv*0.12, 0]);

plot(ax,0,0,'k.','MarkerSize',18);

%% Export PNG
outFile = 'xy_sketch_final3.png';
exportgraphics(fig,outFile,'Resolution',300);
fprintf('Step 1 complete. Wrote: %s\n', outFile);

%% ---------- local function ----------
function drawSquare(ax,c,a,col,lw)
x0 = c(1) - a/2; y0 = c(2) - a/2;
rectangle(ax,'Position',[x0 y0 a a],'EdgeColor',col,'LineWidth',lw);
plot(ax,[x0 x0+a],[y0 y0+a],'-','Color',col,'LineWidth',lw*0.9);
end