% compute_fields_from_geometry_v7a.m
%
% Field calculation for the coil geometry defined in a separate geometry .m file.
%
% Features
%  - Prompts for which coil pair to compute (Bx, By, or Bz).
%  - Reads geometry parameters by parsing the geometry file text (does not execute it).
%  - Supports assignments like z_bz = s; and R_bz = r_circle + a/2;
%  - Computes Bx, By, Bz, and |B| on a coarse cube x,y,z in [-250, +250] mm.
%  - Scales current so the intended component at the origin is +0.400 T.
%  - ALWAYS makes 1D sanity plots along x, y, z axes for the selected pair(s).
%
% Model
%  - Filament centerline loops (Biot–Savart via discretized line elements):
%      * Bx pair: square loops in yz plane at x = ±d, side length 2*s
%      * By pair: square loops in xz plane at y = ±d, side length 2*s
%      * Bz pair: circular loops in xy plane at z = ±z_bz, radius R_bz
%
% Coarse grid first for debugging; increase Ngrid later.

clear; close all; clc;

%% -------------------- User settings --------------------
% Set this to YOUR actual geometry filename:
geometryFile = 'xyz_sketch_3d_det220_plusBz.m';  % change if needed

% Cube half-size and coarse grid
Lbox_mm = 250;
Ngrid   = 101;           % use odd so origin is on the grid

% Discretization (increase later)
NsubSquare = 60;        % subdivisions per square side segment
NphiCircle = 360;       % segments around circle polygon

% Target field at origin for each pair
Btarget = 0.400;        % Tesla

% Output
outMatFile = 'Bfield_map_selectedPair.mat';
makeQuickPlots = true;

%% -------------------- Ask which coil pair --------------------
fprintf('\nSelect coil pair to compute:\n');
fprintf('  1 = Bx coil pair (square loops in yz plane at x = ±d)\n');
fprintf('  2 = By coil pair (square loops in xz plane at y = ±d)\n');
fprintf('  3 = Bz coil pair (circular loops in xy plane at z = ±z_bz)\n');
sel = input('Enter selection (1..3): ');
if isempty(sel) || ~ismember(sel,1:3)
    error('Invalid selection.');
end

%% -------------------- Geometry file existence --------------------
if ~isfile(geometryFile)
    error('Geometry file not found: %s\nSet geometryFile at the top of this script.', geometryFile);
end

%% -------------------- Read geometry parameters from YOUR file --------------------
P = readGeometryParamsSafe(geometryFile);

fprintf('\nParsed geometry from %s:\n', geometryFile);
fprintf('  d        = %.6g mm\n', P.d_mm);
fprintf('  s        = %.6g mm\n', P.s_mm);
fprintf('  L_coil   = %.6g mm\n', P.L_coil_mm);
fprintf('  a        = %.6g mm\n', P.a_mm);
fprintf('  r_circle = %.6g mm\n', P.r_circle_mm);
fprintf('  R_bz     = %.6g mm\n', P.R_bz_mm);
fprintf('  z_bz     = %.6g mm\n', P.z_bz_mm);

%% -------------------- Build field grid --------------------
x_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
y_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
z_mm = linspace(-Lbox_mm, Lbox_mm, Ngrid);
[Xmm, Ymm, Zmm] = ndgrid(x_mm, y_mm, z_mm);

r_m = [Xmm(:), Ymm(:), Zmm(:)] * 1e-3;   % meters
sz  = size(Xmm);
mid = (Ngrid+1)/2;

%% -------------------- Compute / load maps (and save to per-pair .mat files) --------------------
% The saved MAT file contains a single variable named "results" (a MATLAB struct).
%
% Units:
%   results.x_mm, results.y_mm, results.z_mm   in mm
%   results.<Pair>.Bx,By,Bz,Bmag               in Tesla, as Ngrid×Ngrid×Ngrid arrays
%   results.<Pair>.I                           in Ampere
%   results.<Pair>.B0                          in Tesla, 1×3 at the origin
%
% Python reading:
%   For these map sizes (e.g. Ngrid=101), the default MAT v7 format is readable with:
%       scipy.io.loadmat('Bfield_map_Bx_Pair.mat')
%   (MAT v7.3 is HDF5 and usually requires h5py.)

matSaveVersion = '-v7';   % keep v7 for easy scipy.io.loadmat() compatibility

% Ask once whether to generate maps
ansMaps = input('\nGenerate (or load) field map(s) and save to .mat file(s)? y/n [y]: ','s');
if isempty(ansMaps), ansMaps = 'y'; end
if lower(ansMaps(1)) ~= 'y'
    fprintf('Skipped map generation.\n');
    return;
end

% Which pair(s)
pairs = {};
if sel==1, pairs = {'Bx'}; end
if sel==2, pairs = {'By'}; end
if sel==3, pairs = {'Bz'}; end
% Base metadata (common to all maps)
base = struct();
base.geometryFile = geometryFile;
base.P = P;
base.Lbox_mm = Lbox_mm;
base.Ngrid = Ngrid;
base.x_mm = x_mm; base.y_mm = y_mm; base.z_mm = z_mm;

% Container for plotting (may include multiple pairs)
resultsAll = base;

for ip = 1:numel(pairs)
    whichPair = pairs{ip};
    outFile = sprintf('Bfield_map_%s_Pair.mat', whichPair);

    doCompute = true;
    if isfile(outFile)
        a = input(sprintf('File exists: %s. Recompute and overwrite? y/n [n]: ', outFile), 's');
        if isempty(a), a = 'n'; end
        if lower(a(1)) ~= 'y'
            doCompute = false;
        end
    end

    if doCompute
        fprintf('\nComputing %s pair...\n', whichPair);
        [Bcube,Ireq,B0] = computePairScaled(whichPair, r_m, P, Btarget, NsubSquare, NphiCircle);

        pairField = [whichPair,'Pair'];  % 'BxPair', 'ByPair', 'BzPair'
        baseOne = base;
        baseOne.(pairField).I    = Ireq;
        baseOne.(pairField).B0   = B0;
        baseOne.(pairField).Bx   = reshape(Bcube(:,1), sz);
        baseOne.(pairField).By   = reshape(Bcube(:,2), sz);
        baseOne.(pairField).Bz   = reshape(Bcube(:,3), sz);
        baseOne.(pairField).Bmag = reshape(vecnorm(Bcube,2,2), sz);

        results = baseOne; %#ok<NASGU>
        save(outFile,'results',matSaveVersion);
        fprintf('\nSaved: %s  (variable: results struct; units: mm, T, A)\n', outFile);

        % Keep for plotting
        resultsAll.(pairField) = baseOne.(pairField);

    else
        fprintf('\nLoading existing map: %s\n', outFile);
        S = load(outFile,'results');
        if ~isfield(S,'results')
            error('File %s does not contain a variable named "results".', outFile);
        end
        R = S.results;

        % Copy pair field into resultsAll (if present)
        pairField = [whichPair,'Pair'];
        if isfield(R,pairField)
            resultsAll.(pairField) = R.(pairField);
        else
            error('File %s: results.%s not found.', outFile, pairField);
        end

        % Also refresh common grid in case file differs
        if isfield(R,'x_mm'), resultsAll.x_mm = R.x_mm; end
        if isfield(R,'y_mm'), resultsAll.y_mm = R.y_mm; end
        if isfield(R,'z_mm'), resultsAll.z_mm = R.z_mm; end
        if isfield(R,'Ngrid'), resultsAll.Ngrid = R.Ngrid; end
        if isfield(R,'Lbox_mm'), resultsAll.Lbox_mm = R.Lbox_mm; end
    end
end

% For the rest of this script, use resultsAll as "results"
results = resultsAll;


%% -------------------- Quick plots --------------------
if makeQuickPlots
    if isfield(results,'BxPair')
        figure('Color','w');
        imagesc(x_mm,y_mm,squeeze(results.BxPair.Bx(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar; xlabel('x [mm]'); ylabel('y [mm]');
        title('Bx from Bx pair at z = 0 [T]');
    end
    if isfield(results,'ByPair')
        figure('Color','w');
        imagesc(x_mm,y_mm,squeeze(results.ByPair.By(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar; xlabel('x [mm]'); ylabel('y [mm]');
        title('By from By pair at z = 0 [T]');
    end
    if isfield(results,'BzPair')
        figure('Color','w');
        imagesc(x_mm,y_mm,squeeze(results.BzPair.Bz(:,:,mid))'); axis image;
        set(gca,'YDir','normal'); colorbar; xlabel('x [mm]'); ylabel('y [mm]');
        title('Bz from Bz pair at z = 0 [T]');
    end
end

%% -------------------- 1D sanity plots along axes --------------------
% For each computed pair, plot (Bx,By,Bz) along x, y, z axes through origin.
plotSanity = @(coord, bx, by, bz, label) sanityPlot3(coord, bx, by, bz, label);

if isfield(results,'BxPair')
    P1 = results.BxPair;
    plotSanity(results.x_mm, squeeze(P1.Bx(:,mid,mid)), squeeze(P1.By(:,mid,mid)), squeeze(P1.Bz(:,mid,mid)), ...
        'Bx-pair: along x (y=z=0)');
    plotSanity(results.y_mm, squeeze(P1.Bx(mid,:,mid)), squeeze(P1.By(mid,:,mid)), squeeze(P1.Bz(mid,:,mid)), ...
        'Bx-pair: along y (x=z=0)');
    plotSanity(results.z_mm, squeeze(P1.Bx(mid,mid,:)), squeeze(P1.By(mid,mid,:)), squeeze(P1.Bz(mid,mid,:)), ...
        'Bx-pair: along z (x=y=0)');
end

if isfield(results,'ByPair')
    P2 = results.ByPair;
    plotSanity(results.x_mm, squeeze(P2.Bx(:,mid,mid)), squeeze(P2.By(:,mid,mid)), squeeze(P2.Bz(:,mid,mid)), ...
        'By-pair: along x (y=z=0)');
    plotSanity(results.y_mm, squeeze(P2.Bx(mid,:,mid)), squeeze(P2.By(mid,:,mid)), squeeze(P2.Bz(mid,:,mid)), ...
        'By-pair: along y (x=z=0)');
    plotSanity(results.z_mm, squeeze(P2.Bx(mid,mid,:)), squeeze(P2.By(mid,mid,:)), squeeze(P2.Bz(mid,mid,:)), ...
        'By-pair: along z (x=y=0)');
end

if isfield(results,'BzPair')
    P3 = results.BzPair;
    plotSanity(results.x_mm, squeeze(P3.Bx(:,mid,mid)), squeeze(P3.By(:,mid,mid)), squeeze(P3.Bz(:,mid,mid)), ...
        'Bz-pair: along x (y=z=0)');
    plotSanity(results.y_mm, squeeze(P3.Bx(mid,:,mid)), squeeze(P3.By(mid,:,mid)), squeeze(P3.Bz(mid,:,mid)), ...
        'Bz-pair: along y (x=z=0)');
    plotSanity(results.z_mm, squeeze(P3.Bx(mid,mid,:)), squeeze(P3.By(mid,mid,:)), squeeze(P3.Bz(mid,mid,:)), ...
        'Bz-pair: along z (x=y=0)');
end

fprintf('\nDone.\n');

%% =====================================================================
%% Functions
%% =====================================================================

function [Bcube,Ireq,B0_scaled] = computePairScaled(whichPair, r_m, P, Btarget, NsubSquare, NphiCircle)
    r0 = [0 0 0];
    B1 = computePairField(whichPair, r0, 1.0, P, NsubSquare, NphiCircle);

    switch whichPair
        case 'Bx', comp = 1;
        case 'By', comp = 2;
        case 'Bz', comp = 3;
        otherwise, error('Unknown pair.');
    end

    if abs(B1(comp)) < 1e-15
        error('%s pair: selected component at origin is too small for scaling.', whichPair);
    end

    Ireq = Btarget / B1(comp);   % keeps sign; produces +Btarget in that component
    fprintf('  For 1 A: B(0) = [%.3e %.3e %.3e] T\n', B1(1),B1(2),B1(3));
    fprintf('  Current for target: I = %.6g A\n', Ireq);

    Bcube = computePairField(whichPair, r_m, Ireq, P, NsubSquare, NphiCircle);
    B0_scaled = computePairField(whichPair, r0, Ireq, P, NsubSquare, NphiCircle);
    fprintf('  Check: B(0) = [%.6f %.6f %.6f] T\n', B0_scaled(1),B0_scaled(2),B0_scaled(3));
end

function B = computePairField(whichPair, r_m, I, P, NsubSquare, NphiCircle)
    if isrow(r_m), r_m = reshape(r_m,1,3); end
    mu0 = 4*pi*1e-7;

    s = P.s_mm * 1e-3;
    d = P.d_mm * 1e-3;

    B = zeros(size(r_m));

    switch whichPair
        case 'Bx'
            loop1 = squareLoopYZ(+d, s);
            loop2 = squareLoopYZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'By'
            loop1 = squareLoopXZ(+d, s);
            loop2 = squareLoopXZ(-d, s);
            B = B + biotSavartPolyline(r_m, loop1, I, mu0, NsubSquare);
            B = B + biotSavartPolyline(r_m, loop2, I, mu0, NsubSquare);

        case 'Bz'
            R  = P.R_bz_mm * 1e-3;
            z0 = P.z_bz_mm * 1e-3;
            circ1 = circleLoopXY(+z0, R, NphiCircle);
            circ2 = circleLoopXY(-z0, R, NphiCircle);
            B = B + biotSavartPolyline(r_m, circ1, I, mu0, 1);
            B = B + biotSavartPolyline(r_m, circ2, I, mu0, 1);

        otherwise
            error('Unknown pair.');
    end
end

function pts = squareLoopXZ(y0, s)
    pts = [-s, y0, -s;
            s, y0, -s;
            s, y0,  s;
           -s, y0,  s;
           -s, y0, -s];
end

function pts = squareLoopYZ(x0, s)
    pts = [x0, -s, -s;
           x0,  s, -s;
           x0,  s,  s;
           x0, -s,  s;
           x0, -s, -s];
end

function pts = circleLoopXY(z0, R, Nphi)
% Closed polyline for circle in xy-plane at z=z0 with radius R.
% Force exact closure to avoid floating-point mismatch.
    phi = linspace(0,2*pi,Nphi+1);
    pts = [R*cos(phi(:)), R*sin(phi(:)), z0*ones(numel(phi),1)];
    pts(end,:) = pts(1,:);   % enforce exact closure
end

function B = biotSavartPolyline(r, pts, I, mu0, NsubPerSegment)
% Biot–Savart for a (closed) polyline, tolerant closure check.

    tol = 1e-12; % meters
    if norm(pts(end,:) - pts(1,:), 2) > tol
        error('Polyline must be closed (last point equals first within tol=%.1e).', tol);
    end
    pts(end,:) = pts(1,:); % enforce exact closure

    pref = (mu0*I)/(4*pi);
    B = zeros(size(r));

    M = size(pts,1)-1;
    for m = 1:M
        p1 = pts(m,:);
        p2 = pts(m+1,:);
        B = B + pref * biotSegmentMidpointSum(r, p1, p2, NsubPerSegment);
    end
end

function dB = biotSegmentMidpointSum(r, p1, p2, Nsub)
    v  = (p2 - p1);
    dl = v / Nsub;

    k  = (1:Nsub)';
    rp = p1 + (k - 0.5).*(v/Nsub);   % Nsub x 3

    dB = zeros(size(r));
    for j = 1:Nsub
        R  = r - rp(j,:);
        R2 = sum(R.^2,2);
        R3 = R2 .* sqrt(R2);

        mask = (R3 > 0);
        if ~any(mask), continue; end

        Rx = R(mask,1); Ry = R(mask,2); Rz = R(mask,3);

        cx = dl(2)*Rz - dl(3)*Ry;
        cy = dl(3)*Rx - dl(1)*Rz;
        cz = dl(1)*Ry - dl(2)*Rx;

        invR3 = 1 ./ R3(mask);

        dB(mask,1) = dB(mask,1) + cx .* invR3;
        dB(mask,2) = dB(mask,2) + cy .* invR3;
        dB(mask,3) = dB(mask,3) + cz .* invR3;
    end
end

function P = readGeometryParamsSafe(fname)
% Parses scalar definitions from the geometry file text, including simple expressions.
% Allowed tokens in expressions: numbers, identifiers, + - * / ( ) and whitespace.

    txt = fileread(fname);

    env = struct();

    env.d        = parseScalar(txt,'d',env);
    env.a        = parseScalar(txt,'a',env);
    env.L_coil   = parseScalar(txt,'L_coil',env);
    env.s        = parseScalar(txt,'s',env);
    env.r_circle = parseScalar(txt,'r_circle',env);

    if hasVar(txt,'R_bz')
        env.R_bz = parseScalar(txt,'R_bz',env);
    else
        env.R_bz = env.r_circle + env.a/2;
    end

    if hasVar(txt,'z_bz')
        env.z_bz = parseScalar(txt,'z_bz',env);
    else
        env.z_bz = env.s;
    end

    P.d_mm        = env.d;
    P.a_mm        = env.a;
    P.L_coil_mm   = env.L_coil;
    P.s_mm        = env.s;
    P.r_circle_mm = env.r_circle;
    P.R_bz_mm     = env.R_bz;
    P.z_bz_mm     = env.z_bz;
end

function tf = hasVar(txt,varname)
    pat = ['(?m)^\s*', regexptranslate('escape',varname), '\s*='];
    tf = ~isempty(regexp(txt, pat, 'once'));
end

function val = parseScalar(txt, varname, env)
% Extracts RHS from "varname = <expr>;" and evaluates <expr> safely.

    pat = ['(?m)^\s*', regexptranslate('escape',varname), '\s*=\s*([^;]+)\s*;'];
    tok = regexp(txt, pat, 'tokens', 'once');
    if isempty(tok)
        error('Could not parse "%s" from geometry file.', varname);
    end
    expr = strtrim(tok{1});

    if ~isempty(regexp(expr, '[^0-9A-Za-z_\.\+\-\*\/\(\)\s]', 'once'))
        error('Unsafe characters in expression for %s: "%s"', varname, expr);
    end

    names = fieldnames(env);
    for k = 1:numel(names)
        nm = names{k};
        expr = regexprep(expr, ['(?<![A-Za-z0-9_])', nm, '(?![A-Za-z0-9_])'], num2str(env.(nm), '%.17g'));
    end

    if ~isempty(regexp(expr, '[A-Za-z_]', 'once'))
        error('Unknown identifier in %s expression after substitution: "%s"', varname, expr);
    end

    val = str2num(expr); %#ok<ST2NM>
    if isempty(val) || ~isfinite(val) || ~isscalar(val)
        error('Failed to evaluate %s expression: "%s"', varname, expr);
    end
end

function sanityPlot3(coord_mm, Bx, By, Bz, titleStr)
    figure('Color','w');
    plot(coord_mm, Bx, 'r-', 'LineWidth', 1.5); hold on;
    plot(coord_mm, By, 'g-', 'LineWidth', 1.5);
    plot(coord_mm, Bz, 'b-', 'LineWidth', 1.5);
    grid on;
    xlabel('position [mm]');
    ylabel('B [T]');
    legend('Bx','By','Bz','Location','best');
    title(titleStr);
end
