% toyMC_bunch_assignment_with_plots_v4_vertexZ.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% Adds longitudinal vertex z0 sampling (flat in [-5,+5] mm) and the
% corresponding bunch-passage timing offset at the vertex.
%
% Key idea:
%  - Measured dt = t_hit - floor(t_hit/tau_b)*tau_b  (in [0,tau_b))
%  - Test candidate offsets n = 0..nmax
%  - Accept best n if | (dt + n*tau_b) - tTOF_pred | < k*sigma_eff
%
% New in v4:
%  - Sample z0 uniformly in [-5,+5] mm
%  - Add dt_z = z0/(beta_beam*c) to the hit time stamp

clear; close all; clc;

%% -------------------- Parameters --------------------
P = struct();

% Physics and geometry
P.mp_GeV      = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns  = 0.299792458;      % speed of light in m/ns
P.Lpath_m     = 0.220;            % effective flight path (m), toy model

% Beam (for bunch-passage timing shift across z)
P.beta_beam   = 1.0;              % beta of the ion beam (approx 1 at RHIC/EIC)

% Vertex distribution along z (flat)
P.use_vertexZ = true;
P.z0_min_m    = -5e-3;            % -5 mm
P.z0_max_m    = +5e-3;            % +5 mm

% Bunch timing
P.tau_b_ns        = 11.027;       % bunch spacing (ns)
P.sigma_bunch_ns  = 0.200;        % rms bunch temporal width (ns)
P.sigma_model_ns  = 0.0;          % extra model uncertainty (ns), optional

% Detector timing scenarios
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;                   % test n = 0..nmax
P.window_k = 3.0;                 % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges = [ ...
    0.0005, 0.0015, 0.0025, 0.0040, ...
    0.0075, 0.0125, 0.0175, 0.0250, 0.0350 ];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins     = numel(P.t_centers);

% Plot export
P.writePNGs = true;
P.pngDPI    = 300;                % 300 for LaTeX
P.figPosIn  = [1 1 8.5 5.5];      % inches

% Plot defaults (LaTeX friendly)
set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultLegendFontSize', 24, ...
    'defaultFigureColor', 'w');

rng(1);

%% -------------------- Generate truth |t| --------------------
bin_id = randi(P.Nbins, P.Nevents, 1);
bin_id = bin_id(:);

t_lo = P.t_edges(bin_id);
t_hi = P.t_edges(bin_id + 1);
t_lo = t_lo(:);
t_hi = t_hi(:);

t_true = t_lo + (t_hi - t_lo) .* rand(P.Nevents, 1);

% Recoil kinematics (toy)
TR_GeV = t_true ./ (2*P.mp_GeV);        %#ok<NASGU> % TR in GeV (non-rel approx in CNI)
p_GeV  = sqrt(t_true);                  % p_R ~ sqrt(|t|) (GeV/c)
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

tTOF_true_ns = P.Lpath_m ./ (beta * P.c_m_per_ns);

%% -------------------- Vertex z0 sampling (NEW) --------------------
if P.use_vertexZ
    % Flat in [z0_min, z0_max]
    z0_m = P.z0_min_m + (P.z0_max_m - P.z0_min_m) .* rand(P.Nevents, 1);

    % Bunch-passage time offset at the vertex: dt_z = z0/(beta_beam*c)
    dt_z_ns = z0_m ./ (P.beta_beam * P.c_m_per_ns);
else
    z0_m   = zeros(P.Nevents,1);
    dt_z_ns = zeros(P.Nevents,1);
end

%% -------------------- Assign a true bunch and build measured times --------------------
b_true = randi(2000, P.Nevents, 1);

% Bunch arrival time jitter (intrinsic bunch width)
dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

% Ideal measured hit time stamp (ns)
% NEW: include dt_z_ns
t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns + dt_z_ns;

% Measured dt relative to the "current" bunch marker:
b0     = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;

% True offset in the bunch search convention
n_true = b0 - b_true;

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

% Keep one scenario as reference for diagnostic plots
ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    % Add detector timing noise
    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    % Effective sigma for window
    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    % Predicted TOF from measured energy (toy: use truth here)
    tTOF_pred_ns = tTOF_true_ns;

    % Residuals for candidate n
    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);
    res_ns  = cand_ns - tTOF_pred_ns;

    % Best n by minimum absolute residual
    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';

    % Window cut
    accept = absmin < (P.window_k * sigma_eff_ns);

    % Correct bunch assignment
    correct = accept & (n_best == n_true);

    % Bin-by-bin correct fraction
    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    % Save reference arrays
    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns    = dt_meas_ns;
        REF.tTOF_pred_ns  = tTOF_pred_ns;
        REF.n_best        = n_best;
        REF.n_true        = n_true;
        REF.accept        = accept;
        REF.bin_id        = bin_id;
        REF.sigma_eff_ns  = sigma_eff_ns;
        REF.res_ns        = res_ns;
        REF.t_true        = t_true;
        REF.z0_m          = z0_m;       % NEW
        REF.dt_z_ns       = dt_z_ns;    % NEW
    end
end

%% -------------------- Plot 1: Correct fraction vs |t| --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

colors = [
    0.00, 0.45, 0.74;
    0.85, 0.33, 0.10;
    0.93, 0.69, 0.13;
    0.49, 0.18, 0.56;
    0.47, 0.67, 0.19;
    0.30, 0.75, 0.93
];

h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), '-o', ...
        'LineWidth', 2.5, ...
        'MarkerSize', 10, ...
        'MarkerFaceColor', colors(is,:), ...
        'Color', colors(is,:));
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '$|t|$ [(GeV/$c$)$^2$]', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');
ylabel(ax, 'Correct bunch fraction', 'FontSize', 24, 'FontWeight', 'bold', 'Interpreter', 'latex');

ylim(ax, [0.7, 1.02]);
xlim(ax, [0, max(P.t_edges)]);

leg = cell(numel(P.sigma_det_ns_list), 1);
for is = 1:numel(P.sigma_det_ns_list)
    leg{is} = sprintf('$\\sigma_{\\mathrm{det}} = %.1f$ ns', P.sigma_det_ns_list(is));
end

lgd = legend(ax, h, leg, ...
    'Location', 'eastoutside', ...
    'Box', 'on', ...
    'Interpreter', 'latex', ...
    'FontSize', 18); %#ok<NASGU>

ax.Position(3) = 0.62;

if P.writePNGs
    exportgraphics(fig, sprintf('toyMC_correctFraction_vs_t_k%.1f_v4_vertexZ.png', P.window_k), ...
        'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_correctFraction_vs_t_k%.1f_v4_vertexZ.png\n', P.window_k);
end

%% -------------------- Plot 2: tTOF vs |t| with m*tau_b lines --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig);
hold(ax,'on'); box(ax,'on'); grid(ax,'on');

tgrid = linspace(min(P.t_edges), max(P.t_edges), 600).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
tTOFgrid = P.Lpath_m ./ (betagrid * P.c_m_per_ns);

plot(ax, tgrid, tTOFgrid, '-', 'LineWidth', 3.5, 'Color', [0.0 0.3 0.7]);

mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(ax, m*P.tau_b_ns, '-', ...
        'LineWidth', 1.8, ...
        'Color', [0.85 0.33 0.10], ...
        'Alpha', 1);
    text(ax, max(P.t_edges)*0.98, m*P.tau_b_ns, ...
        sprintf(' %d\\tau_b', m), ...
        'FontSize', 24, ...
        'VerticalAlignment', 'bottom', ...
        'HorizontalAlignment', 'right', ...
        'Color', [0.85 0.33 0.10]);
end

set(ax, 'FontSize', 20, 'LineWidth', 1.5, 'TickLength', [0.02 0.02]);
xlabel(ax, '|{\it t}| [(GeV/{\it c})^2]', 'FontSize', 24, 'FontWeight', 'bold');
ylabel(ax, '{\it t}_{TOF} [ns]', 'FontSize', 24, 'FontWeight', 'bold');

xlim(ax, [0, max(P.t_edges)]);
ylim(ax, [0, 30]);

if P.writePNGs
    exportgraphics(fig, 'toyMC_tTOF_vs_t_v4_vertexZ.png', 'Resolution', P.pngDPI);
    fprintf('Wrote: toyMC_tTOF_vs_t_v4_vertexZ.png\n');
end

%% -------------------- (Remaining plots identical to v3) --------------------
% Keep your existing Plot 3, 4 blocks unchanged if you want them.
% They will now include the vertexZ smearing automatically through dt0_ns.

fprintf('\nAll done (v4 with vertex z0 sampling).\n');
