% calc_deflection_circular_coils_fixed_png.m
% Produces TWO PNG files for Appendix figures:
%   fig_By_x.png      : By(x,0,0) along x-axis
%   fig_traj_zx.png   : z(x) trajectories for two t values
%
% Styling: large fonts, no titles, appendix-ready

clear; close all; clc;

%% Constants (SI)
mu0 = 4*pi*1e-7;                 
c   = 299792458;                 
qe  = 1.602176634e-19;           
mp_MeV = 938.272088;             
mp_GeV = mp_MeV*1e-3;            

%% Coil geometry and target field
R_coil   = 50e-3;     
y_coil   = 50e-3;     
B_target = 0.4;       

%% Analytic current magnitude
d = y_coil;
geom_factor = (mu0/2) * R_coil^2 / (R_coil^2 + d^2)^(3/2);
I_required = B_target / (2*geom_factor);

%% Enforce +By at origin
n_seg_field = 800;
By0_num = calc_By_at_point_xz(0, 0, R_coil, y_coil, I_required, mu0, n_seg_field);
if By0_num < 0
    I_required = -I_required;
end

%% Recoil proton parameters (correct p(t))
t_values = [1e-3, 2e-2];
TR_GeV = t_values ./ (2*mp_GeV);
p_recoil_GeV = sqrt(TR_GeV .* (TR_GeV + 2*mp_GeV));
p_recoil_SI  = p_recoil_GeV * 1e9 * qe / c;

%% Trajectory setup
x_max   = 0.25;     
n_steps = 2000;
x_traj  = linspace(0, x_max, n_steps);
dx      = x_traj(2) - x_traj(1);

%% Field along x-axis (z=0)
By_axis = zeros(size(x_traj));
for i = 1:numel(x_traj)
    By_axis(i) = calc_By_at_point_xz(x_traj(i), 0, R_coil, y_coil, I_required, mu0, n_seg_field);
end

%% Trajectories
use_field_on_trajectory = true;
z_store = zeros(2, numel(x_traj));

for k = 1:2
    p  = p_recoil_SI(k);
    pz = 0;
    z  = 0;

    for i = 1:(numel(x_traj)-1)
        x = x_traj(i);

        if use_field_on_trajectory
            By = calc_By_at_point_xz(x, z, R_coil, y_coil, I_required, mu0, n_seg_field);
        else
            By = By_axis(i);
        end

        pz = pz - qe * By * dx;
        z  = z + (pz/p) * dx;

        z_store(k, i+1) = z;
    end
end

%% ---------- FIGURE 1: By(x,0,0) ----------
fig1 = figure('Color','w','Units','pixels','Position',[100 100 1200 750]);
plot(x_traj*1e3, By_axis*1e3, 'LineWidth', 3);
xlabel('x [mm]','FontSize',28);
ylabel('B_y(x,0,0) [mT]','FontSize',28);
set(gca,'FontSize',24,'LineWidth',1.5);
grid on;

print(fig1, 'fig_By_x.png', '-dpng', '-r300');

%% ---------- FIGURE 2: z(x) trajectories ----------
fig2 = figure('Color','w','Units','pixels','Position',[120 120 1200 750]);
plot(x_traj*1e3, z_store(1,:)*1e3, 'LineWidth', 3); hold on;
plot(x_traj*1e3, z_store(2,:)*1e3, 'LineWidth', 3);
xlabel('x [mm]','FontSize',28);
ylabel('z [mm]','FontSize',28);
legend('t = 1e-3 (GeV/c)^2','t = 2e-2 (GeV/c)^2', ...
       'FontSize',22,'Location','northwest','Box','off');
set(gca,'FontSize',24,'LineWidth',1.5);
grid on;

print(fig2, 'fig_traj_zx.png', '-dpng', '-r300');

fprintf('PNG files written:\n');
fprintf('  fig_By_x.png\n');
fprintf('  fig_traj_zx.png\n');

%% Helper function
function By = calc_By_at_point_xz(x, z, R, y0, I, mu0, n_seg)
    dphi = 2*pi/n_seg;
    phis = ((1:n_seg) - 0.5) * dphi;
    By_total = 0;

    for sgn = [+1, -1]
        yc = sgn * y0;
        for i = 1:n_seg
            phi = phis(i);
            xc = R*cos(phi);
            zc = R*sin(phi);
            dlx = -R*sin(phi) * dphi;
            dlz =  R*cos(phi) * dphi;
            rx = x - xc;
            ry = -yc;
            rz = z - zc;
            rmag = sqrt(rx^2 + ry^2 + rz^2);
            cross_y = dlz*rx - dlx*rz;
            By_total = By_total + (mu0*I/(4*pi)) * cross_y / rmag^3;
        end
    end
    By = By_total;
end
