% xy_sketch_final.m
% Reproduces the “final accepted” XY sketch:
% - x axis reversed ( +x to the left ), y up
% - 6 detectors on radius r_det = 250 mm (3 opposing pairs)
% - acceptance lines from origin to each detector center
% - coils: 20×20 mm^2 rectangles (blue) + connecting lines
% - construction lines every 22.5° in identical dotted style
% - no box around plot, axes shown through origin + arrow heads
% - exports a PNG

clear; close all; clc;

%% Parameters
r_det   = 250;     % detector radius [mm]
detLen  = 110;     % detector bar length [mm]
detLW   = 6;       % detector line width
detCol  = [1 0 1]; % magenta

d       = 80;      % coil offset (centerline) [mm]  (d = ±80 mm)
a       = 20;      % coil cross section side [mm]  (20×20)
s       = 50;      % half spacing between the two z-legs of one coil [mm]
coilCol = [0 0 1]; % blue
coilLW  = 2.0;

r_circle = 50;     % inner circle radius [mm]
oct_R    = 115;    % octagon "radius" to vertices [mm]
octCol   = [1.0 0.6 0.0]; % orange
octLW    = 2.5;

xlimv = 360;
ylimv = 360;

%% Figure/axes
fig = figure('Color','w','Position',[100 80 950 820]);
ax  = axes('Parent',fig); hold(ax,'on'); axis(ax,'equal');

xlim(ax,[-xlimv xlimv]);
ylim(ax,[-ylimv ylimv]);

% Axis through origin, no box
set(ax,'Box','off','XAxisLocation','origin','YAxisLocation','origin', ...
    'TickDir','out','LineWidth',1.0,'FontSize',12);

% Reverse x-direction so +x is to the LEFT (as in your sketch)
set(ax,'XDir','reverse');

xlabel(ax,'x [mm]','FontSize',13);
ylabel(ax,'y [mm]','FontSize',13);

title(ax,'XY sketch: all 22.5° construction lines in identical style, d = ±80 mm, coil cross-section 20×20 mm^2', ...
      'FontSize',14);

%% 22.5° construction lines (identical style)
L = 1.05*max(xlimv,ylimv);
angles = 0:22.5:337.5;
for th = angles
    u = [cosd(th), sind(th)];
    p1 = -L*u;
    p2 = +L*u;
    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)],':','Color',[0 0 0],'LineWidth',1.2);
end

%% Inner circle
t = linspace(0,2*pi,400);
plot(ax,r_circle*cos(t), r_circle*sin(t), 'Color',[0 0.45 0.35],'LineWidth',3.0);

%% Regular octagon
k = 0:7;
phi0 = 22.5; % rotate so flats look like your reference
x8 = oct_R*cosd(phi0 + 45*k);
y8 = oct_R*sind(phi0 + 45*k);
plot(ax,[x8 x8(1)],[y8 y8(1)],'-','Color',octCol,'LineWidth',octLW);

%% Helper: draw one coil (two 20×20 squares + connecting lines)
% dir = 'H' : connect along x (top/bottom coils)
% dir = 'V' : connect along y (left/right coils)
drawCoil = @(xc,yc,dir) localDrawCoil(ax,xc,yc,dir,a,s,coilCol,coilLW);

% Top / bottom coil (By coil pack depiction)
drawCoil(0, +d,'H');
drawCoil(0, -d,'H');

% Left / right coil (Bx coil pack depiction)
drawCoil(+d, 0,'V');
drawCoil(-d, 0,'V');

%% Detectors (6 total) all at r = 250 mm
% Angles for 3 opposing pairs: 0°, 45°, 135° and opposite.
detAngles = [0 180 45 225 135 315];

for th = detAngles
    cx = r_det*cosd(th);
    cy = r_det*sind(th);

    % Acceptance line from origin to detector center
    plot(ax,[0 cx],[0 cy],'--','Color',[0 0 0],'LineWidth',2.0);

    % Detector bar: oriented perpendicular to radial direction
    % Tangent unit vector
    tx = -sind(th);
    ty =  cosd(th);

    p1 = [cx cy] + 0.5*detLen*[tx ty];
    p2 = [cx cy] - 0.5*detLen*[tx ty];

    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)],'-','Color',detCol,'LineWidth',detLW);
end

%% Axes arrow heads (add small arrows for +x and +y directions)
% Note: since x is reversed, +x points to the LEFT.
arrowLen = 40;
quiver(ax,0,0, +arrowLen,0, 0,'k','LineWidth',1.8,'MaxHeadSize',2.5); % +x (left on screen due to XDir reverse)
quiver(ax,0,0, 0,+arrowLen, 0,'k','LineWidth',1.8,'MaxHeadSize',2.5); % +y

% Slightly enlarge origin marker if you want
plot(ax,0,0,'k.','MarkerSize',18);

%% Export PNG
outFile = 'xy_FULL_all_22p5_same_style_new.png';
exportgraphics(fig,outFile,'Resolution',300);
fprintf('Wrote: %s\n', outFile);

%% ---------- local function ----------
function localDrawCoil(ax,xc,yc,dir,a,s,coilCol,coilLW)
% Draw a coil as two 20×20 mm^2 squares (z-legs) plus connecting lines.
% (xc,yc) is the midpoint between the two legs.

if dir=='H'
    % legs separated along x
    c1 = [xc - s, yc];
    c2 = [xc + s, yc];

    % squares
    drawSquare(ax,c1,a,coilCol,coilLW);
    drawSquare(ax,c2,a,coilCol,coilLW);

    % connect inner edges and outer edges (two horizontal lines)
    yTop = yc + a/2;
    yBot = yc - a/2;

    xLout = (xc - s) - a/2;
    xRout = (xc + s) + a/2;
    xLin  = (xc - s) + a/2;
    xRin  = (xc + s) - a/2;

    plot(ax,[xLout xRout],[yTop yTop],'-','Color',coilCol,'LineWidth',coilLW);
    plot(ax,[xLout xRout],[yBot yBot],'-','Color',coilCol,'LineWidth',coilLW);

    plot(ax,[xLin xRin],[yTop yTop],'-','Color',coilCol,'LineWidth',coilLW);
    plot(ax,[xLin xRin],[yBot yBot],'-','Color',coilCol,'LineWidth',coilLW);

elseif dir=='V'
    % legs separated along y
    c1 = [xc, yc - s];
    c2 = [xc, yc + s];

    % squares
    drawSquare(ax,c1,a,coilCol,coilLW);
    drawSquare(ax,c2,a,coilCol,coilLW);

    % connect inner edges and outer edges (two vertical lines)
    xR = xc + a/2;
    xL = xc - a/2;

    yBout = (yc - s) - a/2;
    yTout = (yc + s) + a/2;
    yBin  = (yc - s) + a/2;
    yTin  = (yc + s) - a/2;

    plot(ax,[xR xR],[yBout yTout],'-','Color',coilCol,'LineWidth',coilLW);
    plot(ax,[xL xL],[yBout yTout],'-','Color',coilCol,'LineWidth',coilLW);

    plot(ax,[xR xR],[yBin yTin],'-','Color',coilCol,'LineWidth',coilLW);
    plot(ax,[xL xL],[yBin yTin],'-','Color',coilCol,'LineWidth',coilLW);
else
    error('dir must be ''H'' or ''V''.');
end

end

function drawSquare(ax,c,a,col,lw)
% Center c = [x y], side a.
x0 = c(1) - a/2; y0 = c(2) - a/2;
rectangle(ax,'Position',[x0 y0 a a],'EdgeColor',col,'LineWidth',lw);

% simple hatch (one diagonal), to mimic “shaded” leg
plot(ax,[x0 x0+a],[y0 y0+a],'-','Color',col,'LineWidth',lw*0.9);
end
