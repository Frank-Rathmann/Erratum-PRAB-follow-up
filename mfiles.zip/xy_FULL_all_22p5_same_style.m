function make_xy_sketch_final()
% make_xy_sketch_final
% XY sketch with:
% - all 22.5° construction lines in identical style
% - 6 detectors at r = 250 mm (3 pairs: 0°, 180°, +45°, -45°, +135°, -135°)
% - coil cross-section 20x20 mm^2 + connecting lines (rectangular loop)
%
% Output: xy_FULL_all_22p5_same_style.png

close all; clc;

%% -------------------- Parameters --------------------
Lplot   = 350;     % axis extent [mm]
rCirc   = 50;      % inner circle radius [mm]
rDet    = 250;     % detector radius [mm]
detLen  = 110;     % detector segment length [mm] (tune to taste)
detLW   = 6;       % detector line width
detCol  = [1 0 1]; % magenta

% Regular octagon (orange)
octR    = 110;     % "outer" radius [mm] (tune)
octLW   = 3;
octCol  = [1 0.65 0]; % orange-ish

% Coil geometry (blue)
d       = 80;      % coil center offset [mm] (±d)
cs      = 20;      % coil cross section 20x20 [mm]
legSep  = 80;      % separation between the two z-legs along the coil span [mm]
coilLW  = 2.5;
coilCol = [0 0 1];

% Construction lines
rRay    = 330;     % ray length
ray22_style = ':'; % identical style for all 22.5° construction lines
ray22_LW    = 1.4;

% Extra "acceptance" rays (dashed) at 45° steps (optional, matches typical layout)
ray45_style = '--';
ray45_LW    = 2.0;

%% -------------------- Figure/Axes --------------------
fig = figure('Color','w','Position',[100 100 1100 950]);
ax  = axes('Parent',fig); hold(ax,'on'); axis(ax,'equal');
xlim(ax,[-Lplot Lplot]); ylim(ax,[-Lplot Lplot]);

% IMPORTANT: match your convention where +x points left (as in your screenshot)
set(ax,'XDir','reverse');

% turn off box; we will draw arrow axes ourselves
set(ax,'Box','off','FontSize',14);

% Labels
xlabel(ax,'x [mm]'); ylabel(ax,'y [mm]');

% Title
title(ax, sprintf('XY sketch: all 22.5^\\circ construction lines in identical style\\n d = \\pm%d mm, coil cross-section %d\\times%d mm^2', d, cs, cs));

%% -------------------- Axes with arrows (no box axes) --------------------
% Draw axis lines
plot(ax,[-Lplot Lplot],[0 0],'k-','LineWidth',2);
plot(ax,[0 0],[-Lplot Lplot],'k-','LineWidth',2);

% Arrowheads
ah = 18; % arrow size scaling
quiver(ax, Lplot*0.92,0, -1,0, 0,'k','LineWidth',2,'MaxHeadSize',ah/Lplot);
quiver(ax, 0,Lplot*0.92, 0,1, 0,'k','LineWidth',2,'MaxHeadSize',ah/Lplot);

% axis labels near arrows (optional)
text(ax, -Lplot*0.95,  12,'+x','FontWeight','bold'); % +x is left because XDir reversed
text(ax,  12, Lplot*0.95,'+y','FontWeight','bold');

%% -------------------- 22.5° construction rays (all identical) --------------------
ang22 = (0:15)*22.5; % degrees
for k = 1:numel(ang22)
    th = deg2rad(ang22(k));
    x2 = rRay*cos(th);
    y2 = rRay*sin(th);
    plot(ax,[0 x2],[0 y2],'k', 'LineStyle',ray22_style,'LineWidth',ray22_LW);
end

%% -------------------- Optional 45° dashed rays (heavier) --------------------
ang45 = (0:7)*45;
for k = 1:numel(ang45)
    th = deg2rad(ang45(k));
    x2 = (0.75*rRay)*cos(th);
    y2 = (0.75*rRay)*sin(th);
    plot(ax,[0 x2],[0 y2],'k', 'LineStyle',ray45_style,'LineWidth',ray45_LW);
end

%% -------------------- Regular octagon (flat top/bottom) --------------------
% For a regular octagon with flat top/bottom, place vertices at 22.5° + n*45°
angOct = deg2rad(22.5 + (0:7)*45);
xOct = octR*cos(angOct);
yOct = octR*sin(angOct);
plot(ax,[xOct xOct(1)],[yOct yOct(1)],'Color',octCol,'LineWidth',octLW);

%% -------------------- Inner circle --------------------
t = linspace(0,2*pi,600);
plot(ax, rCirc*cos(t), rCirc*sin(t), 'Color',[0 0.45 0.35],'LineWidth',3);

%% -------------------- Coils: 20x20 squares + connecting lines --------------------
% We draw 4 coils (top, bottom, left, right):
% Each coil consists of two 20x20 "z-leg" squares and a rectangular loop (connecting lines).

% TOP coil centered at (0, +d), legs at x = ±legSep/2
draw_coil_loop(ax, [ -legSep/2, +d], [ +legSep/2, +d], cs, coilCol, coilLW);

% BOTTOM coil centered at (0, -d)
draw_coil_loop(ax, [ -legSep/2, -d], [ +legSep/2, -d], cs, coilCol, coilLW);

% RIGHT coil centered at ( +d, 0), legs at y = ±legSep/2
draw_coil_loop(ax, [ +d, -legSep/2], [ +d, +legSep/2], cs, coilCol, coilLW);

% LEFT coil centered at ( -d, 0)
draw_coil_loop(ax, [ -d, -legSep/2], [ -d, +legSep/2], cs, coilCol, coilLW);

%% -------------------- Detectors: 6 at r = 250 mm --------------------
detAngles = [0 180 45 -45 135 -135]; % degrees (ALL at rDet)
for k = 1:numel(detAngles)
    th = deg2rad(detAngles(k));
    % center point on the circle rDet
    xc = rDet*cos(th);
    yc = rDet*sin(th);

    % detector segment is perpendicular to radial direction
    % unit perpendicular vector:
    upx = -sin(th);
    upy =  cos(th);

    x1 = xc - (detLen/2)*upx;
    y1 = yc - (detLen/2)*upy;
    x2 = xc + (detLen/2)*upx;
    y2 = yc + (detLen/2)*upy;

    plot(ax,[x1 x2],[y1 y2],'Color',detCol,'LineWidth',detLW);
end

%% -------------------- Final cosmetics --------------------
% minor ticks and grid off (matches your clean look)
grid(ax,'off');
set(ax,'TickDir','out');

%% -------------------- Export PNG --------------------
outname = 'xy_FULL_all_22p5_same_style.png';
exportgraphics(fig,outname,'Resolution',200);
fprintf('Wrote %s\n', outname);

end

%% =======================================================================
function draw_coil_loop(ax, p1, p2, cs, col, lw)
% draw_coil_loop
% p1, p2: centers of the two z-legs (20x20 squares), in [x y] mm
% cs: cross section size (square)
%
% The loop is drawn as the outer rectangle that touches the outside edges
% of the two squares, plus the inner rectangle touching the inside edges.
% This gives you "rectangles + connecting lines" instead of strange shapes.

x1 = p1(1); y1 = p1(2);
x2 = p2(1); y2 = p2(2);

% Draw the two 20x20 squares (z-legs)
draw_square(ax, x1, y1, cs, col, lw);
draw_square(ax, x2, y2, cs, col, lw);

% Determine if coil is horizontal or vertical by comparing coordinates
if abs(y2 - y1) < 1e-9
    % horizontal coil: legs separated in x, same y
    yC = y1;

    % outer and inner y-levels
    yOutTop = yC + cs/2;
    yOutBot = yC - cs/2;

    % outside edges in x
    xLeftOut  = min(x1,x2) - cs/2;
    xRightOut = max(x1,x2) + cs/2;

    % inside edges in x
    xLeftIn  = min(x1,x2) + cs/2;
    xRightIn = max(x1,x2) - cs/2;

    % Outer rectangle (top/bottom + verticals)
    plot(ax,[xLeftOut xRightOut],[yOutTop yOutTop],'Color',col,'LineWidth',lw);
    plot(ax,[xLeftOut xRightOut],[yOutBot yOutBot],'Color',col,'LineWidth',lw);
    plot(ax,[xLeftOut xLeftOut],[yOutBot yOutTop],'Color',col,'LineWidth',lw);
    plot(ax,[xRightOut xRightOut],[yOutBot yOutTop],'Color',col,'LineWidth',lw);

    % Inner rectangle (gives the “connecting lines” look)
    plot(ax,[xLeftIn xRightIn],[yOutTop yOutTop],'Color',col,'LineWidth',lw);
    plot(ax,[xLeftIn xRightIn],[yOutBot yOutBot],'Color',col,'LineWidth',lw);
else
    % vertical coil: legs separated in y, same x
    xC = x1;

    xOutR = xC + cs/2;
    xOutL = xC - cs/2;

    yBotOut = min(y1,y2) - cs/2;
    yTopOut = max(y1,y2) + cs/2;

    yBotIn = min(y1,y2) + cs/2;
    yTopIn = max(y1,y2) - cs/2;

    % Outer rectangle
    plot(ax,[xOutL xOutR],[yTopOut yTopOut],'Color',col,'LineWidth',lw);
    plot(ax,[xOutL xOutR],[yBotOut yBotOut],'Color',col,'LineWidth',lw);
    plot(ax,[xOutL xOutL],[yBotOut yTopOut],'Color',col,'LineWidth',lw);
    plot(ax,[xOutR xOutR],[yBotOut yTopOut],'Color',col,'LineWidth',lw);

    % Inner rectangle
    plot(ax,[xOutL xOutR],[yTopIn yTopIn],'Color',col,'LineWidth',lw);
    plot(ax,[xOutL xOutR],[yBotIn yBotIn],'Color',col,'LineWidth',lw);
end

end

function draw_square(ax, xc, yc, s, col, lw)
% draw_square: centered square of side s
x = [xc-s/2 xc+s/2 xc+s/2 xc-s/2 xc-s/2];
y = [yc-s/2 yc-s/2 yc+s/2 yc+s/2 yc-s/2];
plot(ax,x,y,'Color',col,'LineWidth',lw);

% simple hatch to mimic “coil leg” shading (diagonal lines)
n = 6;
for k=0:n
    t = k/n;
    xa = (xc-s/2) + t*s;
    ya = (yc-s/2);
    xb = (xc-s/2);
    yb = (yc-s/2) + t*s;
    plot(ax,[xa xb],[ya yb],'Color',col,'LineWidth',1);
end
end
