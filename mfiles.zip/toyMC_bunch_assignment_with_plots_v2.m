% % toyMC_bunch_assignment_with_plots_v2.m
%
% Toy MC for bunch assignment using TOF-energy consistency.
% Adds diagnostic plots for presentations and exports PNGs for LaTeX.
%
% Key idea:
%  - Measured dt = t_hit - floor(t_hit/tau_b)*tau_b  (in [0,tau_b))
%  - Test candidate offsets n = 0..nmax
%  - Accept best n if | (dt + n*tau_b) - tTOF_pred | < k*sigma_eff

clear; close all; clc;

%%
% ---------- Plot defaults (LaTeX-friendly) ----------
P.pngDPI = 300;   % override if already defined

set(groot, ...
    'defaultAxesFontSize', 28, ...
    'defaultAxesLineWidth', 1.2, ...
    'defaultAxesLabelFontSizeMultiplier', 1.1, ...
    'defaultAxesTitleFontSizeMultiplier', 1.1, ...
    'defaultLineLineWidth', 3.0, ...
    'defaultLineMarkerSize', 8, ...
    'defaultFigureColor', 'w');

P.figPosIn = [1 1 8.5 5.5];

%% -------------------- Parameters --------------------
P = struct();

% Physics and geometry
P.mp_GeV   = 0.9382720813;     % proton mass (GeV/c^2)
P.c_m_per_ns = 0.299792458;    % speed of light in m/ns
P.Lpath_m  = 0.220;            % effective flight path (m), toy model

% Bunch timing
P.tau_b_ns        = 11.027;    % bunch spacing (ns), EIC flattop example
P.sigma_bunch_ns  = 0.200;     % rms bunch temporal width (ns), Table II
P.sigma_model_ns  = 0.0;       % extra model uncertainty (ns), optional

% Detector timing scenarios
P.sigma_det_ns_list = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0];

% Bunch assignment search and consistency window
P.nmax     = 5;               % test n = 0..nmax
P.window_k = 3.0;             % accept if |residual| < k*sigma_eff

% Event generation
P.Nevents  = 1e6;

% |t| binning for plots (GeV/c)^2
P.t_edges  = [0.002, 0.004, 0.0065, 0.009, 0.012, 0.014, 0.0165, 0.019];
P.t_centers = 0.5*(P.t_edges(1:end-1) + P.t_edges(2:end));
P.Nbins = numel(P.t_centers);

% Plot export
P.pngDPI = 300;

rng(1);

%% -------------------- Generate truth |t| --------------------
% Choose a bin uniformly, then uniform within that bin
bin_id = randi(P.Nbins, P.Nevents, 1);
bin_id = bin_id(:);  % enforce column to avoid implicit expansion

t_lo = P.t_edges(bin_id).';
t_hi = P.t_edges(bin_id+1).';
t_lo = t_lo(:); t_hi = t_hi(:);

t_true = t_lo + (t_hi - t_lo).*rand(P.Nevents,1);   % (GeV/c)^2, column

% Recoil energy and kinematics
TR_GeV = t_true ./ (2*P.mp_GeV);     % TR in GeV (non-rel approx for CNI)
p_GeV  = sqrt(t_true);              % p_R ~ sqrt(|t|) (GeV/c)
beta   = p_GeV ./ sqrt(p_GeV.^2 + P.mp_GeV^2);

tTOF_true_ns = P.Lpath_m ./ (beta * P.c_m_per_ns);  % ns

%% -------------------- Assign a true bunch and build measured times --------------------
% True bunch index (only relative offsets matter here)
b_true = randi(2000, P.Nevents, 1);   % arbitrary large range

% Bunch arrival time jitter (intrinsic bunch width)
dt_bunch_ns = P.sigma_bunch_ns .* randn(P.Nevents,1);

% Detector timing noise will be added per sigma_det scenario.
% Measured hit time (absolute time stamp, ns)
t_hit_ideal_ns = b_true .* P.tau_b_ns + tTOF_true_ns + dt_bunch_ns;

% Derived measured dt relative to the "current" bunch marker:
b0 = floor(t_hit_ideal_ns ./ P.tau_b_ns);
dt0_ns = t_hit_ideal_ns - b0 .* P.tau_b_ns;      % in [0,tau_b)

% True offset in the bunch search convention:
% b0 = b_true + floor((tTOF + noise)/tau_b), so the offset is:
n_true = b0 - b_true;                            % integer >= 0 typically

%% -------------------- Run bunch assignment for each sigma_det --------------------
n_list = 0:P.nmax;
Nn = numel(n_list);

correctFrac = zeros(P.Nbins, numel(P.sigma_det_ns_list));

% For extra plots, keep one scenario as "reference"
ref_sigma_det = 3.0;
ref_keep = false;

for is = 1:numel(P.sigma_det_ns_list)

    sigma_det_ns = P.sigma_det_ns_list(is);

    % Add detector noise to dt0 (timing measurement)
    dt_meas_ns = dt0_ns + sigma_det_ns .* randn(P.Nevents,1);

    % Effective sigma for window
    sigma_eff_ns = sqrt(sigma_det_ns^2 + P.sigma_bunch_ns^2 + P.sigma_model_ns^2);

    % Predicted TOF from measured energy (toy: use truth TR, but structure is here)
    % In a later step you can smear TR and recompute beta.
    tTOF_pred_ns = tTOF_true_ns;

    % Residuals for all candidate n: res = (dt_meas + n*tau_b) - tTOF_pred
    % Size: Nevents x (nmax+1), manageable for nmax=5
    cand_ns = dt_meas_ns + (P.tau_b_ns .* n_list);     % implicit expansion
    res_ns  = cand_ns - tTOF_pred_ns;                 % Nevents x Nn

    % Choose best n by minimum absolute residual
    [absmin, idxBest] = min(abs(res_ns), [], 2);
    n_best = n_list(idxBest).';

    % Window cut
    accept = absmin < (P.window_k * sigma_eff_ns);

    % Correct bunch assignment if accepted and n_best equals true n_true
    correct = accept & (n_best == n_true);

    % Bin-by-bin correct fraction (conditional on being in that |t| bin)
    for ib = 1:P.Nbins
        inBin = (bin_id == ib);
        correctFrac(ib,is) = mean(correct(inBin));
    end

    % Save reference arrays for diagnostics
    if abs(sigma_det_ns - ref_sigma_det) < 1e-12
        ref_keep = true;
        REF.dt_meas_ns = dt_meas_ns;
        REF.tTOF_pred_ns = tTOF_pred_ns;
        REF.n_best = n_best;
        REF.n_true = n_true;
        REF.accept = accept;
        REF.bin_id = bin_id;
        REF.sigma_eff_ns = sigma_eff_ns;
        REF.res_ns = res_ns;  % Nevents x Nn (ok for nmax=5)
    end
end

%% -------------------- Plot 1: Correct fraction vs |t| --------------------
fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
ax  = axes(fig); hold(ax,'on'); grid(ax,'on');

% Plot
h = gobjects(numel(P.sigma_det_ns_list),1);
for is = 1:numel(P.sigma_det_ns_list)
    h(is) = plot(ax, P.t_centers, correctFrac(:,is), '-o', ...
        'LineWidth', 3.0, 'MarkerSize', 7);
end

% Axes styling (do not rely only on groot)
set(ax, 'FontSize', 32, 'LineWidth', 1.2, 'TickLength', [0.015 0.015]);
xlabel(ax, '|t| [(GeV/c)^2]', 'FontSize', 36);
ylabel(ax, 'Correct bunch fraction', 'FontSize', 36);
title(ax, sprintf('Toy MC bunch assignment, window k = %.1f, Nevents = %d', ...
    P.window_k, P.Nevents), 'FontSize', 34, 'FontWeight','bold');

% Legend text
leg = arrayfun(@(x) sprintf('\\sigma_{\\mathrm{det}} = %.1f ns', x), ...
    P.sigma_det_ns_list, 'UniformOutput', false);

% Legend OUTSIDE so it never covers data
lgd = legend(ax, h, leg, ...
    'Location','northoutside', ...
    'Orientation','horizontal', ...
    'NumColumns', min(numel(leg), 3), ...
    'Box','off');
lgd.FontSize = 26;

% Give the plot area a bit more breathing room under the legend
ax.Position(2) = ax.Position(2) - 0.03;
ax.Position(4) = ax.Position(4) - 0.05;

% Export
if P.writePNGs
    exportgraphics(fig, sprintf('toyMC_correctFraction_vs_t_k%.1f.png', P.window_k), ...
        'Resolution', P.pngDPI);
end

%% -------------------- Plot 2: tTOF vs |t| with tau_b lines --------------------
fig = figure('Color','w'); hold on; grid on;
tgrid = linspace(min(P.t_edges), max(P.t_edges), 400).';
pgrid = sqrt(tgrid);
betagrid = pgrid ./ sqrt(pgrid.^2 + P.mp_GeV^2);
tTOFgrid = P.Lpath_m ./ (betagrid * P.c_m_per_ns);

plot(tgrid, tTOFgrid, 'LineWidth', 2);
xlabel('|t| [(GeV/c)^2]');
ylabel('t_{TOF} [ns]');
title(sprintf('TOF vs |t| for L = %.0f mm', 1e3*P.Lpath_m));

% Horizontal lines at m*tau_b
mmax = ceil(max(tTOFgrid)/P.tau_b_ns);
for m = 1:mmax
    yline(m*P.tau_b_ns, ':', sprintf('%d\\tau_b', m));
end

exportgraphics(fig, 'toyMC_tTOF_vs_t.png', 'Resolution', P.pngDPI);

%% -------------------- Plot 3: Residual histograms for reference sigma_det --------------------
if ref_keep
    fig = figure('Color','w'); tiledlayout(1,2,'Padding','compact','TileSpacing','compact');

    % Pick two bins: lowest |t| and mid/high |t|
    ib1 = 1;
    ib2 = min(P.Nbins, 5);

    nexttile; hold on; grid on;
    idx = (REF.bin_id == ib1) & REF.accept;
    % residual of best candidate
    [~, idxBest] = min(abs(REF.res_ns), [], 2);
    resBest = REF.res_ns(sub2ind(size(REF.res_ns),(1:P.Nevents).', idxBest));
    histogram(resBest(idx), 200, 'Normalization','pdf');
    xlabel('Residual [ns]'); ylabel('PDF');
    title(sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ib1, ref_sigma_det));

    nexttile; hold on; grid on;
    idx = (REF.bin_id == ib2) & REF.accept;
    histogram(resBest(idx), 200, 'Normalization','pdf');
    xlabel('Residual [ns]'); ylabel('PDF');
    title(sprintf('Residuals (accepted), |t| bin %d, \\sigma_{det}=%.1f ns', ib2, ref_sigma_det));

    exportgraphics(fig, sprintf('toyMC_residualHists_sigmaDet%.1f.png', ref_sigma_det), 'Resolution', P.pngDPI);
end

%% -------------------- Plot 4: n_best distribution (reference sigma_det) --------------------
if ref_keep
    fig = figure('Color','w'); hold on; grid on;
    histogram(REF.n_best(REF.accept), 'BinMethod','integers');
    xlabel('Selected bunch offset n_{best}');
    ylabel('Counts (accepted)');
    title(sprintf('Chosen bunch offsets, \\sigma_{det}=%.1f ns, k=%.1f', ref_sigma_det, P.window_k));
    exportgraphics(fig, sprintf('toyMC_nBest_sigmaDet%.1f.png', ref_sigma_det), 'Resolution', P.pngDPI);

    fig = figure('Color','w'); hold on; grid on;
    % 2D diagnostic: dt_meas mod tau_b vs |t|
    dt_mod = mod(REF.dt_meas_ns, P.tau_b_ns);
    scatter(t_true(1:20000), dt_mod(1:20000), 6, 'filled'); % subset for visibility
    xlabel('|t| [(GeV/c)^2]');
    ylabel('t_{hit} mod \\tau_b [ns]');
    title(sprintf('Diagnostic scatter (subset), \\sigma_{det}=%.1f ns', ref_sigma_det));
    exportgraphics(fig, sprintf('toyMC_dtMod_vs_t_sigmaDet%.1f.png', ref_sigma_det), 'Resolution', P.pngDPI);
end

%%
fprintf('\nWrote PNGs:\n');
fprintf('  toyMC_correctFraction_vs_t_k%.1f.png\n', P.window_k);
fprintf('  toyMC_tTOF_vs_t.png\n');
if ref_keep
    fprintf('  toyMC_residualHists_sigmaDet%.1f.png\n', ref_sigma_det);
    fprintf('  toyMC_nBest_sigmaDet%.1f.png\n', ref_sigma_det);
    fprintf('  toyMC_dtMod_vs_t_sigmaDet%.1f.png\n', ref_sigma_det);
end
fprintf('\nDone.\n');

function fig = newFigLatex(P)
    fig = figure('Color','w', 'Units','inches', 'Position', P.figPosIn);
end

function exportPng(fig, filename, dpi)
    set(fig,'InvertHardcopy','off');
    exportgraphics(fig, filename, 'Resolution', dpi);
    fprintf('Wrote PNG: %s\n', filename);
end

