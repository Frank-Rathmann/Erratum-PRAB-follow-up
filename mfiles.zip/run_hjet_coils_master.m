% % run_hjet_coils_master.m
%
% Master entry point for the HJET coil workflow:
%   Geometry sketch  →  Field-map calculation  →  Recoil-proton deflection example
%
% PURPOSE
%   This script keeps the “what to run, in what order” in one place, and ensures
%   that all required files are in the same folder (or on the MATLAB path).
%
% REQUIRED FILES (expected in the same folder as this master script)
%   (1) xyz_sketch_3D_det220_plusBz.m
%       3D visualization of the geometry: detector planes + three coil pairs (Bx, By, Bz).
%       Output: figures only (no files), used for sanity checking placement/dimensions.
%
%   (2) compute_fields_from_geometry_v6.m   (or your updated v7a etc.)
%       Computes magnetic field maps on a user-defined 3D grid.
%       - Reads geometry parameters by parsing the geometry-file text (does not run it).
%       - Computes Bx, By, Bz, and |B| on a 3D grid.
%       - Scales current so that the intended component at the origin is 0.400 T.
%       Output: .mat file with the computed map (filename depends on selection).
%
%   (3) calc_deflection_circular_coils_fixed_png.m
%       Recoil-proton deflection example/diagnostic (trajectory + PNG output).
%       Output: figures and PNG files (script-defined filenames).
%
% NOTES
%   - Scripts (2) and (3) are interactive (prompt for settings/selections).
%   - This master script does NOT change any parameters inside the other scripts.
%   - If you rename files, update the filenames in the “Define file names” section below.
%
% TYPICAL WORKFLOW
%   1) Run geometry sketch (visual sanity)
%   2) Run field map script (coarse grid first; increase resolution later)
%   3) Run deflection script (physics/trajectory sanity check)

clear; close all; clc;

%% --------- Locate this master script and set working folder ----------
% Running everything from the same folder avoids “file not found” issues.
thisFile = mfilename('fullpath');
if isempty(thisFile)
    % If running unsaved code from the editor, fall back to current folder.
    baseDir = pwd;
else
    baseDir = fileparts(thisFile);
end
cd(baseDir);
fprintf('\nWorking directory set to:\n  %s\n\n', baseDir);

%% --------- Define the file names (edit here if you rename files) ----------
% Use the exact filenames as they exist on disk.
geomFile  = 'xyz_sketch_3D_det220_plusBz.m';
fieldFile = 'compute_fields_from_geometry_v7b.m';     % or compute_fields_from_geometry_v7a.m
deflFile  = 'calc_deflection_circular_coils_fixed_png.m';

%% --------- Check required files exist ----------
mustExist = {geomFile, fieldFile, deflFile};
for k = 1:numel(mustExist)
    if ~isfile(mustExist{k})
        error(['Required file not found:\n  %s\n\n',...
               'Fix: Put it in this folder, or add its folder to the MATLAB path.\n'], ...
               mustExist{k});
    end
end

%% --------- Menu ----------
fprintf('Available actions:\n');
fprintf('  1 = Show geometry sketch (3D)\n');
fprintf('  2 = Compute field map(s) from geometry\n');
fprintf('  3 = Run recoil-proton deflection example\n');
fprintf('  4 = Run 1 → 2 → 3 (full sequence)\n');
fprintf('  0 = Exit\n\n');

sel = input('Enter selection (0..4): ');
if isempty(sel) || ~ismember(sel, 0:4)
    error('Invalid selection.');
end
if sel == 0
    fprintf('Exit.\n');
    return;
end

%% --------- Action dispatcher ----------
switch sel
    case 1
        runGeometry(geomFile);

    case 2
        runFieldMaps(fieldFile, geomFile);

    case 3
        runDeflection(deflFile);

    case 4
        runGeometry(geomFile);
        runFieldMaps(fieldFile, geomFile);
        runDeflection(deflFile);
end

fprintf('\nMaster script finished.\n');

%% =====================================================================
%% Local helper functions
%% =====================================================================

function runGeometry(geomFile)
    fprintf('\n============================================================\n');
    fprintf('Running geometry sketch:\n  %s\n', geomFile);
    fprintf('============================================================\n\n');
    run(geomFile);
end

function runFieldMaps(fieldFile, geomFile)
    fprintf('\n============================================================\n');
    fprintf('Running field map script:\n  %s\n', fieldFile);
    fprintf('Geometry file (must match what the field script expects):\n  %s\n', geomFile);
    fprintf('============================================================\n\n');

    % IMPORTANT:
    % The field-map script contains (near its top) a line like:
    %   geometryFile = 'xyz_sketch_3D_det220_plusBz.m';
    %
    % Ensure that it matches geomFile EXACTLY.
    % If you rename geomFile, update that variable inside the field-map script too.

    run(fieldFile);
end

function runDeflection(deflFile)
    fprintf('\n============================================================\n');
    fprintf('Running deflection script:\n  %s\n', deflFile);
    fprintf('============================================================\n\n');
    run(deflFile);
end
