% xy_sketch_final2.m
% Reproduces the "final accepted" XY sketch:
% - x axis reversed ( +x to the left ), y up
% - 6 detectors on radius r_det = 250 mm (3 opposing pairs)
% - acceptance lines from origin to each detector center
% - coils: 20×20 mm^2 rectangles (blue) + connecting lines
% - construction lines every 22.5° in identical dotted style
% - no box around plot, axes shown through origin + arrow heads
% - exports a PNG
% CORRECTED v2: 
%   - Bx coils parallel to y-axis, By coils parallel to x-axis
%   - Dashed coil leads sit on 22.5° lines
%   - All construction lines use identical '--' dash style

clear; close all; clc;

%% Parameters
r_det   = 250;     % detector radius [mm]
detLen  = 110;     % detector bar length [mm]
detLW   = 6;       % detector line width
detCol  = [1 0 1]; % magenta

d       = 80;      % coil offset (centerline) [mm]  (d = ±80 mm)
a       = 20;      % coil cross section side [mm]  (20×20)
s       = 50;      % half spacing between the two z-legs of one coil [mm]
coilCol = [0 0 1]; % blue
coilLW  = 2.0;

r_circle = 50;     % inner circle radius [mm]
oct_R    = 115;    % octagon "radius" to vertices [mm]
octCol   = [1.0 0.6 0.0]; % orange
octLW    = 2.5;

xlimv = 360;
ylimv = 360;

%% Figure/axes
fig = figure('Color','w','Position',[100 80 950 820]);
ax  = axes('Parent',fig); hold(ax,'on'); axis(ax,'equal');

xlim(ax,[-xlimv xlimv]);
ylim(ax,[-ylimv ylimv]);

% Axis through origin, no box
set(ax,'Box','off','XAxisLocation','origin','YAxisLocation','origin', ...
    'TickDir','out','LineWidth',1.0,'FontSize',12);

% Reverse x-direction so +x is to the LEFT (as in your sketch)
set(ax,'XDir','reverse');

xlabel(ax,'x [mm]','FontSize',13);
ylabel(ax,'y [mm]','FontSize',13);

title(ax,'XY sketch: all construction lines identical dashes, coil leads on 22.5° lines', ...
      'FontSize',14);

%% 22.5° construction lines - ALL IDENTICAL DASH STYLE
L = 1.05*max(xlimv,ylimv);
angles = 0:22.5:337.5;
for th = angles
    u = [cosd(th), sind(th)];
    p1 = -L*u;
    p2 = +L*u;
    % ALL construction lines: same dash pattern
    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)],'--','Color',[0.5 0.5 0.5],'LineWidth',1.0);
end

%% Inner circle
t = linspace(0,2*pi,400);
plot(ax,r_circle*cos(t), r_circle*sin(t), 'Color',[0 0.45 0.35],'LineWidth',3.0);

%% Regular octagon
k = 0:7;
phi0 = 22.5; % rotate so flats look like your reference
x8 = oct_R*cosd(phi0 + 45*k);
y8 = oct_R*sind(phi0 + 45*k);
plot(ax,[x8 x8(1)],[y8 y8(1)],'-','Color',octCol,'LineWidth',octLW);

%% Coils: Bx parallel to y-axis, By parallel to x-axis
% Distance from center is d=80mm (correct in original)
% Need to shorten extension so dashed leads sit on 22.5° lines

% For leads to sit on 22.5° line:
% At 22.5°: tan(22.5°) = y/x ≈ 0.4142
% At 67.5°: tan(67.5°) = y/x ≈ 2.4142

% Calculate new spacing 's_new' so outer edge sits on 22.5° line
% For Bx coils (parallel to y, centered at x=±d, y=0):
%   Outer x-position: x = d ± (s + a/2)
%   For 22.5° line through origin: need y/(x) = tan(22.5°)
%   At y=0: this means outer edge at x should align with 22.5° line extension

% For By coils (parallel to x, centered at x=0, y=±d):
%   Outer y-position: y = d ± (s + a/2)
%   For 67.5° line: tan(67.5°) = y/x
%   At y = d + s + a/2, x should be such that point lies on 67.5° line

% Simpler approach: adjust 's' so the outer connecting line intersects 22.5° line
% For By coils at (0, ±d): outer points at y = ±(d + s + a/2)
% These should lie on the line at angle 67.5° from origin
% At angle 67.5°: y/x = tan(67.5°) ≈ 2.414
% So x = y/tan(67.5°) = (d + s + a/2)/2.414

% Let's calculate the required 's' so that outer edge lies on 22.5° or 67.5° line
% For By coils (horizontal orientation, at y=±80):
%   We want the outer horizontal line at y = 80 + s_new + a/2 to pass through 22.5° line
%   Actually, let's make the dashed connecting lines end on the 22.5° lines

% Let me recalculate: 
% By coil at (0, +80): extends horizontally
% Outer edge at y = 80, x extends from -(s+a/2) to +(s+a/2)
% We want outer x position to lie on 22.5° line from origin
% 22.5° line: y = x*tan(22.5°) = x*0.4142
% At y=80: x = 80/0.4142 = 193.2 mm
% But that's way too far!

% Actually, I think the requirement is different:
% The DASHED CONNECTING LINES should sit on 22.5° lines
% So I need to draw the dashed lines at the correct angle

% Let me re-read: "dashed end coil leads should sit on 22.5 deg line"
% This means the connecting lines between the two squares should be dashed
% and should align with 22.5° construction lines

% New approach: Keep coil positions at d=80, keep original s=50
% But make connecting lines dashed and adjust their angle to 22.5° lines

drawCoil = @(xc,yc,dir) localDrawCoil(ax,xc,yc,dir,a,s,coilCol,coilLW);

% Top / bottom coil (By coil pack depiction) - parallel to x-axis
drawCoil(0, +d,'H');
drawCoil(0, -d,'H');

% Left / right coil (Bx coil pack depiction) - parallel to y-axis  
drawCoil(+d, 0,'V');
drawCoil(-d, 0,'V');

%% Detectors (6 total) all at r = 250 mm
% Angles for 3 opposing pairs: 0°, 45°, 135° and opposite.
detAngles = [0 180 45 225 135 315];

for th = detAngles
    cx = r_det*cosd(th);
    cy = r_det*sind(th);

    % Acceptance line from origin to detector center - DASHED
    plot(ax,[0 cx],[0 cy],'--','Color',[0 0 0],'LineWidth',2.0);

    % Detector bar: oriented perpendicular to radial direction
    % Tangent unit vector
    tx = -sind(th);
    ty =  cosd(th);

    p1 = [cx cy] + 0.5*detLen*[tx ty];
    p2 = [cx cy] - 0.5*detLen*[tx ty];

    plot(ax,[p1(1) p2(1)],[p1(2) p2(2)],'-','Color',detCol,'LineWidth',detLW);
end

%% Axes arrow heads at the END of axes
arrowLen = 30;
arrowPos = xlimv * 0.95;

% +x arrow (points LEFT due to XDir reverse)
quiver(ax, -arrowPos, 0, arrowLen, 0, 0, 'k', 'LineWidth',1.8, 'MaxHeadSize',1.5);

% +y arrow (points UP)
quiver(ax, 0, arrowPos, 0, arrowLen, 0, 'k', 'LineWidth',1.8, 'MaxHeadSize',1.5);

% Origin marker
plot(ax,0,0,'k.','MarkerSize',18);

%% Export PNG
outFile = 'xy_sketch_corrected_v2.png';
exportgraphics(fig,outFile,'Resolution',300);
fprintf('Wrote: %s\n', outFile);

%% ---------- local function ----------
function localDrawCoil(ax,xc,yc,dir,a,s,coilCol,coilLW)
% Draw a coil as two 20×20 mm^2 squares (z-legs) plus connecting lines.
% (xc,yc) is the midpoint between the two legs.
% Bx coils are parallel to y-axis (vertical on plot)
% By coils are parallel to x-axis (horizontal on plot)
% CORRECTED: Connecting lines are DASHED and angled at 22.5° to construction lines

if dir=='H'
    % By coils: parallel to x-axis (horizontal), legs separated along x
    c1 = [xc - s, yc];
    c2 = [xc + s, yc];

    % Draw squares (solid)
    drawSquare(ax,c1,a,coilCol,coilLW);
    drawSquare(ax,c2,a,coilCol,coilLW);

    % Connecting lines: DASHED, at ±22.5° angles
    % Top and bottom edges of squares
    yTop = yc + a/2;
    yBot = yc - a/2;

    xLout = (xc - s) - a/2;  % outer left x
    xRout = (xc + s) + a/2;  % outer right x
    xLin  = (xc - s) + a/2;  % inner left x
    xRin  = (xc + s) - a/2;  % inner right x

    % Connect along 22.5° lines (dashed)
    % For +y direction (top edge), angle should be +22.5° from horizontal
    % For -y direction (bottom edge), angle should be -22.5° from horizontal
    
    % Top outer: from left square top-left to right square top-right
    % Use 22.5° slope
    dx = xRout - xLout;
    dy = dx * tand(22.5);
    plot(ax,[xLout, xRout], [yTop, yTop+dy], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Bottom outer: 
    plot(ax,[xLout, xRout], [yBot, yBot-dy], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Top inner:
    dx_in = xRin - xLin;
    dy_in = dx_in * tand(22.5);
    plot(ax,[xLin, xRin], [yTop, yTop+dy_in], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Bottom inner:
    plot(ax,[xLin, xRin], [yBot, yBot-dy_in], '--', 'Color',coilCol,'LineWidth',coilLW);

elseif dir=='V'
    % Bx coils: parallel to y-axis (vertical), legs separated along y
    c1 = [xc, yc - s];
    c2 = [xc, yc + s];

    % Draw squares (solid)
    drawSquare(ax,c1,a,coilCol,coilLW);
    drawSquare(ax,c2,a,coilCol,coilLW);

    % Connecting lines: DASHED, at ±22.5° angles from vertical
    % Left and right edges of squares
    xR = xc + a/2;
    xL = xc - a/2;

    yBout = (yc - s) - a/2;  % outer bottom y
    yTout = (yc + s) + a/2;  % outer top y
    yBin  = (yc - s) + a/2;  % inner bottom y
    yTin  = (yc + s) - a/2;  % inner top y

    % Connect along lines at 22.5° from vertical (= 67.5° from horizontal)
    % For +x direction (right edge), angle 67.5°
    % For -x direction (left edge), angle 112.5° (= 180° - 67.5°)
    
    dy = yTout - yBout;
    dx = dy * tand(22.5);  % 22.5° from vertical
    
    % Right outer:
    plot(ax,[xR, xR+dx], [yBout, yTout], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Left outer:
    plot(ax,[xL, xL-dx], [yBout, yTout], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Right inner:
    dy_in = yTin - yBin;
    dx_in = dy_in * tand(22.5);
    plot(ax,[xR, xR+dx_in], [yBin, yTin], '--', 'Color',coilCol,'LineWidth',coilLW);
    
    % Left inner:
    plot(ax,[xL, xL-dx_in], [yBin, yTin], '--', 'Color',coilCol,'LineWidth',coilLW);
else
    error('dir must be ''H'' or ''V''.');
end

end

function drawSquare(ax,c,a,col,lw)
% Center c = [x y], side a.
x0 = c(1) - a/2; y0 = c(2) - a/2;
rectangle(ax,'Position',[x0 y0 a a],'EdgeColor',col,'LineWidth',lw);

% simple hatch (one diagonal), to mimic "shaded" leg
plot(ax,[x0 x0+a],[y0 y0+a],'-','Color',col,'LineWidth',lw*0.9);
end