% calc_deflection_circular_coils.m
% Calculate magnetic deflection for recoil protons in circular coil pair

clear; close all; clc;

%% Constants (all in SI units: meters, kg, seconds, Tesla)
mu0 = 4*pi*1e-7;           % T*m/A
c = 299792458;             % m/s
mp_MeV = 938.272088;       % proton mass in MeV/c^2
mp = mp_MeV * 1e6 * 1.602176634e-19 / c^2;  % proton mass in kg
qe = 1.602176634e-19;      % elementary charge in C

%% Coil geometry
R_coil = 50e-3;   % coil radius [m]
y_coil = 50e-3;   % coil position [m] (at +y and -y)
B_target = 0.4;   % target field at origin [T]

%% Calculate required current
% Field at origin from two coils at y = ±50 mm
% For a circular loop in xz plane at y = y0, field at (0,0,0):
% B_y = (mu0/2) * I * R^2 / (R^2 + y0^2)^(3/2)
% Two coils contribute equally

d_origin = y_coil;  % distance from origin to coil center
B_single = @(I) (mu0/2) * I * R_coil^2 / (R_coil^2 + d_origin^2)^(3/2);
B_total_origin = @(I) 2 * B_single(I);

% Solve for current
I_required = B_target / (2 * (mu0/2) * R_coil^2 / (R_coil^2 + d_origin^2)^(3/2));
fprintf('Required current: I = %.2f A\n', I_required);
fprintf('Field at origin: By(0,0,0) = %.3f T\n\n', B_total_origin(I_required));

%% Function to calculate By field at position (x, 0, 0)
% Using Biot-Savart law for circular loop in xz plane

calc_By_field = @(x_pos) calc_By_at_point(x_pos, R_coil, y_coil, I_required, mu0);

%% Recoil proton parameters
t_values = [1e-3, 2e-2];  % (GeV/c)^2

% Calculate momentum: p = sqrt(2 * mp * t)
% t is in (GeV/c)^2, mp is in MeV/c^2 = 0.938272088 GeV/c^2
p_recoil_GeV = sqrt(2 * (mp_MeV*1e-3) * t_values);  % momentum in GeV/c

% Convert to SI: p [kg*m/s] = p [GeV/c] * (1e9 eV/GeV) * (1.602e-19 J/eV) / c
p_recoil_SI = p_recoil_GeV * 1e9 * qe / c;  % momentum in kg*m/s

fprintf('Recoil momenta:\n');
fprintf('  t = 1e-3 (GeV/c)^2: p = %.1f MeV/c = %.3e kg*m/s\n', ...
    p_recoil_GeV(1)*1e3, p_recoil_SI(1));
fprintf('  t = 2e-2 (GeV/c)^2: p = %.1f MeV/c = %.3e kg*m/s\n\n', ...
    p_recoil_GeV(2)*1e3, p_recoil_SI(2));

%% Trajectory integration
x_max = 0.25;  % detector at 250 mm
n_steps = 1000;
x_traj = linspace(0, x_max, n_steps);
dx = x_traj(2) - x_traj(1);

% Calculate field along trajectory
By_field = zeros(size(x_traj));
for i = 1:length(x_traj)
    By_field(i) = calc_By_field(x_traj(i));
end

fprintf('Field variation along x-axis:\n');
fprintf('  By(0 mm) = %.3f T\n', By_field(1));
fprintf('  By(50 mm) = %.3f T\n', By_field(round(n_steps*0.2)));
fprintf('  By(100 mm) = %.3f T\n', By_field(round(n_steps*0.4)));
fprintf('  By(150 mm) = %.3f T\n', By_field(round(n_steps*0.6)));
fprintf('  By(200 mm) = %.3f T\n', By_field(round(n_steps*0.8)));
fprintf('  By(250 mm) = %.3f T\n\n', By_field(end));

%% Calculate deflection for both momentum cases
fprintf('Deflections at x = 250 mm:\n');

for k = 1:2
    % Momentum in SI units
    p_SI = p_recoil_SI(k);
    p_GeV = p_recoil_GeV(k);
    
    % Calculate kinetic energy and velocity
    % E^2 = (pc)^2 + (mc^2)^2
    E_total = sqrt((p_GeV*1e9*qe)^2 + (mp*c^2)^2);  % total energy in J
    % E_total = gamma * m * c^2
    gamma = E_total / (mp * c^2);
    % p = gamma * m * v, so v = p / (gamma * m)
    v = p_SI / (gamma * mp);  % velocity in m/s
    beta = v / c;
    
    fprintf('  t = %.1e (GeV/c)^2: p = %.1f MeV/c, v/c = %.4f, gamma = %.4f\n', ...
        t_values(k), p_GeV*1e3, beta, gamma);
    
    % Integrate trajectory
    % Lorentz force: F = q(v × B)
    % For v in +x direction, B in +y direction: F is in -z direction
    % F_z = -q * v_x * B_y
    % a_z = F_z / (gamma * m)
    
    z_pos = 0;
    vz = 0;
    vx = v;  % velocity in x direction (approximately constant)
    
    for i = 1:length(x_traj)-1
        % Time step: dt = dx / vx
        dt = dx / vx;
        
        % Acceleration in z direction
        az = -qe * vx * By_field(i) / (gamma * mp);
        
        % Update velocity and position (simple Euler integration)
        vz = vz + az * dt;
        z_pos = z_pos + vz * dt;
    end
    
    fprintf('    Deflection in z: Δz = %.2f mm = %.4f m\n', z_pos*1e3, z_pos);
end

%% Plot field and trajectory
figure('Color','w','Position',[100 100 1000 400]);

subplot(1,2,1);
plot(x_traj*1e3, By_field*1e3, 'b-', 'LineWidth', 2);
xlabel('x position [mm]','FontSize',12);
ylabel('B_y field [mT]','FontSize',12);
title('Magnetic field along trajectory','FontSize',14);
grid on;

subplot(1,2,2);
% Calculate full trajectory for both cases
for k = 1:2
    p_SI = p_recoil_SI(k);
    p_GeV = p_recoil_GeV(k);
    
    E_total = sqrt((p_GeV*1e9*qe)^2 + (mp*c^2)^2);
    gamma = E_total / (mp * c^2);
    v = p_SI / (gamma * mp);
    vx = v;
    
    z_traj = zeros(size(x_traj));
    vz = 0;
    
    for i = 1:length(x_traj)-1
        dt = dx / vx;
        az = -qe * vx * By_field(i) / (gamma * mp);
        vz = vz + az * dt;
        z_traj(i+1) = z_traj(i) + vz * dt;
    end
    
    if k == 1
        plot(x_traj*1e3, z_traj*1e3, 'r-', 'LineWidth', 2); hold on;
    else
        plot(x_traj*1e3, z_traj*1e3, 'b-', 'LineWidth', 2);
    end
end

xlabel('x position [mm]','FontSize',12);
ylabel('z deflection [mm]','FontSize',12);
title('Particle trajectories','FontSize',14);
legend('t = 1e-3 (GeV/c)^2','t = 2e-2 (GeV/c)^2','Location','northwest');
grid on;

%% Helper function to calculate By field at point (x,0,0)
function By = calc_By_at_point(x, R, y0, I, mu0)
    % Two circular coils in xz plane at y = ±y0
    % Coil normal is +y direction
    % Current flows counterclockwise when viewed from +y
    % Calculate field at point P = (x, 0, 0)
    
    n_seg = 200;
    dphi = 2*pi/n_seg;
    
    By_total = 0;
    
    % Coil at +y0
    for i = 1:n_seg
        phi = (i-0.5)*dphi;  % midpoint of segment
        
        % Current element position
        xc = R*cos(phi);
        yc = y0;
        zc = R*sin(phi);
        
        % Current element dl (in +phi direction)
        dlx = -R*sin(phi)*dphi;
        dly = 0;
        dlz = R*cos(phi)*dphi;
        
        % Vector from current element to field point (x,0,0)
        rx = x - xc;
        ry = 0 - yc;
        rz = 0 - zc;
        r_mag = sqrt(rx^2 + ry^2 + rz^2);
        
        % dl × r, y-component: (dl_z * r_x - dl_x * r_z)
        cross_y = dlz*rx - dlx*rz;
        
        By_total = By_total + (mu0*I/(4*pi)) * cross_y / r_mag^3;
    end
    
    % Coil at -y0 (SAME current direction)
    for i = 1:n_seg
        phi = (i-0.5)*dphi;
        
        xc = R*cos(phi);
        yc = -y0;  % ONLY difference
        zc = R*sin(phi);
        
        dlx = -R*sin(phi)*dphi;
        dly = 0;
        dlz = R*cos(phi)*dphi;
        
        rx = x - xc;
        ry = 0 - yc;  % ry = 0 - (-y0) = +y0
        rz = 0 - zc;
        r_mag = sqrt(rx^2 + ry^2 + rz^2);
        
        cross_y = dlz*rx - dlx*rz;
        
        By_total = By_total + (mu0*I/(4*pi)) * cross_y / r_mag^3;
    end
    
    By = By_total;
end