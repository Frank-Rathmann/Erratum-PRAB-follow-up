% xyz_sketch_3d_det220_plusBz.m
% 3D visualization of HJET magnet and detector geometry
% Detectors at r = 220 mm
%
% Update (Jan 2026):
%  - Added third coil pair for Bz: circular coils centered on z-axis,
%    20×20 mm^2 cross section, outside r = 50 mm (inner radius = 50 mm).
%  - Lighting (Gouraud + camlight) for better 3D perception.
%  - Semi-transparent coils with darker edges (adjustable per coil pair).
%  - Coordinate axes now run through origin (± directions) and are black.

clear; close all; clc;

%% Parameters
r_det   = 220;      % detector radius [mm]
detSize = 100;      % detector square size [mm]
detCol1 = [1 0 1];          % layer 1: magenta
detCol2 = [0.0 0.45 0.0];    % layer 2: dark green
detSep  = 6;                % layer separation along radial direction [mm] (visual only)

d       = 80;       % coil offset / half-separation [mm]
a       = 20;       % coil cross section side [mm]
L_coil  = 66.2;     % coil loop side length [mm]
s       = 33.1;     % half spacing (L_coil/2) [mm]

r_circle = 50;                 % inner circle radius [mm]
oct_R    = 100 / cosd(22.5);   % octagon radius for flats at ±100 mm

% --- Coil colors (distinct): x=green, y=blue, z=orange ---
coilCol_By = [0.10 0.35 0.85];   % blue
coilCol_Bx = [0.10 0.65 0.20];   % green
coilCol_Bz = [0.90 0.55 0.10];   % orange

% --- Coil rendering (per pair) ---
% Face alpha: smaller => more transparent
alpha_By     = 1;
alpha_Bx     = 1;
alpha_Bz     = 1;     % make Bz notably more transparent (your request)

edgeAlpha_By = 1.00;
edgeAlpha_Bx = 1.00;
edgeAlpha_Bz = 0.85;

edgeScale_By = 0.55;     % edge color = edgeScale*FaceColor (darker edge)
edgeScale_Bx = 0.55;
edgeScale_Bz = 0.60;

lw_By        = 1.6;
lw_Bx        = 1.6;
lw_Bz        = 1.2;

% --- Lighting / material ---
useLighting  = true;
materialMode = 'shiny';   % 'dull' or 'shiny'

% --- Bz circular coils (centered on z-axis) ---
% Requirement: stay outside central 50 mm radius around z direction
% -> choose mean radius R0 so that inner radius Rin = R0 - a/2 = 50 mm
R_bz    = r_circle + a/2;   % = 60 mm, so Rin=50, Rout=70
z_bz    = s;                % place circular coil pair at z = ± 70
nseg_bz = 500;              % segmentation for smooth circle

xlimv = 250;
ylimv = 250;
zlimv = 150;

fs1 = 22;
fs2 = 28;

%% Figure/axes
fig = figure('Color','w','Position',[100 100 1200 900]);
ax  = axes('Parent',fig); hold(ax,'on');
axis(ax,'equal');
grid(ax,'on');

xlim(ax,[-xlimv xlimv]);
ylim(ax,[-ylimv ylimv]);
zlim(ax,[-zlimv zlimv]);

xlabel(ax,'x [mm]','FontSize',fs2);
ylabel(ax,'y [mm]','FontSize',fs2);
zlabel(ax,'z [mm]','FontSize',fs2);

view(ax,3);
set(ax,'FontSize',fs1);

% --- Lighting (helps a lot for 3D perception) ---
if useLighting
    lighting(ax,'gouraud');
    material(ax, materialMode);
    camlight(ax,'headlight');
    camlight(ax,'right');
    camlight(ax,'left');
  %  light(ax,'Position',[0 0 1],'Style','infinite');
end

%% 22.5° construction lines in xy-plane at z=0
L = 1.2*max(xlimv,ylimv);
angles = 0:22.5:337.5;
dashColor = [0.7 0.7 0.7];  % gray

for th = angles
    u = [cosd(th), sind(th)];
    p1 = -L*u;
    p2 = +L*u;
    plot3(ax,[p1(1) p2(1)],[p1(2) p2(2)],[0 0], '--', ...
        'Color', dashColor, 'LineWidth', 0.8);
end

%% Inner circle at z=0
t = linspace(0,2*pi,200);
plot3(ax, r_circle*cos(t), r_circle*sin(t), zeros(size(t)), ...
    'Color',[0 0.45 0.35],'LineWidth',2.0);

%% Octagon at z=0
k = 0:7;
phi0 = 22.5;
x8 = oct_R*cosd(phi0 + 45*k);
y8 = oct_R*sind(phi0 + 45*k);
plot3(ax,[x8 x8(1)],[y8 y8(1)],zeros(1,9), ...
    '-','Color',[1.0 0.6 0.0],'LineWidth',2.0);

%% Outer octagon: flats pass through detector centers (in xy plane, z=0)
oct_R_det = r_det / cosd(22.5);   % circumradius corresponding to apothem=r_det

k = 0:7;
phi0 = 22.5;                      % keep same orientation as inner octagon
x8d = oct_R_det*cosd(phi0 + 45*k);
y8d = oct_R_det*sind(phi0 + 45*k);

plot3(ax, [x8d x8d(1)], [y8d y8d(1)], zeros(1,9), ...
    '-', 'Color', [1.0 0.6 0.0], 'LineWidth', 2);

%% By coils (horizontal, at y = ±d)  [blue]
drawCoilLeg(ax, [-s,  d, 0], a, a, L_coil, 'z', coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawCoilLeg(ax, [ s,  d, 0], a, a, L_coil, 'z', coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawConnector(ax, [-s-a/2, d, -s], [s+a/2, d, -s], a, coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawConnector(ax, [-s-a/2, d,  s], [s+a/2, d,  s], a, coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);

drawCoilLeg(ax, [ s, -d, 0], a, a, L_coil, 'z', coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawCoilLeg(ax, [-s, -d, 0], a, a, L_coil, 'z', coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawConnector(ax, [-s-a/2, -d, -s], [s+a/2, -d, -s], a, coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);
drawConnector(ax, [-s-a/2, -d,  s], [s+a/2, -d,  s], a, coilCol_By, alpha_By, edgeAlpha_By, edgeScale_By, lw_By);

%% Bx coils (vertical, at x = ±d)  [green]
drawCoilLeg(ax, [ d, -s, 0], a, a, L_coil, 'z', coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawCoilLeg(ax, [ d,  s, 0], a, a, L_coil, 'z', coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawConnector(ax, [d, -s-a/2, -s], [d, s+a/2, -s], a, coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawConnector(ax, [d, -s-a/2,  s], [d, s+a/2,  s], a, coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);

drawCoilLeg(ax, [-d,  s, 0], a, a, L_coil, 'z', coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawCoilLeg(ax, [-d, -s, 0], a, a, L_coil, 'z', coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawConnector(ax, [-d, -s-a/2, -s], [-d, s+a/2, -s], a, coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);
drawConnector(ax, [-d, -s-a/2,  s], [-d, s+a/2,  s], a, coilCol_Bx, alpha_Bx, edgeAlpha_Bx, edgeScale_Bx, lw_Bx);

%% Bz coils (circular, centered on z-axis, at z = ±z_bz)  [orange, more transparent]
drawCircularCoil(ax, R_bz, a, +z_bz, coilCol_Bz, nseg_bz, alpha_Bz, edgeAlpha_Bz, edgeScale_Bz, lw_Bz);
drawCircularCoil(ax, R_bz, a, -z_bz, coilCol_Bz, nseg_bz, alpha_Bz, edgeAlpha_Bz, edgeScale_Bz, lw_Bz);

%% Detectors (6 total) at r = 220 mm, 100×100 mm squares
detAngles = [0 180 45 225 135 315];

detRayCol = [0.65 0.65 0.65];   % light grey (background element)
detRayLW  = 1;               % thinner so it recedes
detRayLS  = '-';

for th = detAngles
    cx = r_det*cosd(th);
    cy = r_det*sind(th);

    tx = -sind(th);
    ty =  cosd(th);

    drawDetectorTwoLayers(ax, [cx cy 0], [tx ty], detSize, detCol1, detCol2, detSep);

    hs = detSize/2;
    corner1 = [cx - hs*tx, cy - hs*ty, -hs];
    corner2 = [cx + hs*tx, cy + hs*ty, -hs];
    corner3 = [cx + hs*tx, cy + hs*ty, +hs];
    corner4 = [cx - hs*tx, cy - hs*ty, +hs];

    plot3(ax, [0 corner1(1)], [0 corner1(2)], [0 corner1(3)], detRayLS, 'Color', detRayCol, 'LineWidth', detRayLW);
    plot3(ax, [0 corner2(1)], [0 corner2(2)], [0 corner2(3)], detRayLS, 'Color', detRayCol, 'LineWidth', detRayLW);
    plot3(ax, [0 corner3(1)], [0 corner3(2)], [0 corner3(3)], detRayLS, 'Color', detRayCol, 'LineWidth', detRayLW);
    plot3(ax, [0 corner4(1)], [0 corner4(2)], [0 corner4(3)], detRayLS, 'Color', detRayCol, 'LineWidth', detRayLW);
end

%% Coordinate axes (black, through origin, with arrowheads)

% --- Axis colors (bright, high contrast) ---
colX = [0.40 0.70 1.00];   % X: light sky blue  (you like this one)
colY = [0.65 0.40 0.85];   % Y: light green
colZ = [0.85 0.35 0.35];   % Z: light orange
axLW  = 2.2;
arrowScale = 0.08;   % arrow head size (relative)

hold(ax,'on')

% X axis
quiver3(ax, -xlimv, 0, 0,  2*xlimv, 0, 0, 0, ...
    'Color', colX, 'LineWidth', axLW, 'MaxHeadSize', arrowScale);

% Y axis
quiver3(ax, 0, -ylimv, 0,  0, 2*ylimv, 0, 0, ...
    'Color', colY, 'LineWidth', axLW, 'MaxHeadSize', arrowScale);

% Z axis
quiver3(ax, 0, 0, -zlimv,  0, 0, 2*zlimv, 0, ...
    'Color', colZ, 'LineWidth', axLW, 'MaxHeadSize', arrowScale);

% Axis labels (offset, larger, readable)
labelOffset = 0.06;  % relative offset

text(ax, xlimv*(1+labelOffset), 0, 0, 'X', ...
    'FontSize', fs2+6, 'FontWeight', 'bold', 'Color', colX);

text(ax, 0, ylimv*(1+labelOffset), 0, 'Y', ...
    'FontSize', fs2+6, 'FontWeight', 'bold', 'Color', colY);

text(ax, 0, 0, zlimv*(1+labelOffset), 'Z', ...
    'FontSize', fs2+6, 'FontWeight', 'bold', 'Color', colZ);

%% Enable rotation
view(ax, 25, 30);
rotate3d(fig, 'on');

fprintf('3D visualization complete. Use mouse to rotate.\n');

%% ---- Export high-resolution PNG ----
% Fix view (already set above, but keep it here so export is reproducible)
view(ax, 25, 30);

% Make sure OpenGL is used (best with lighting)
set(fig, 'Renderer', 'opengl');

% Optional: reduce jaggies a bit
set(fig, 'GraphicsSmoothing', 'on');

% Output file
pngFile = 'xyz_sketch_3d_det220_plusBz_2detlayers.png';

% High-res export (MATLAB R2020a+)
exportgraphics(fig, pngFile, 'Resolution', 400);   % try 300, 400, 600

fprintf('Wrote PNG: %s\n', pngFile);


%% ---------- Local functions ----------

function drawCoilLeg(ax, center, width, height, length, direction, color, alphaVal, edgeAlpha, edgeScale, lw)
    cx = center(1); cy = center(2); cz = center(3);

    half_len = length/2;
    half_w = width/2;
    half_h = height/2;

    if direction == 'z'
        corners = [
            cx-half_w, cy-half_h, cz-half_len;
            cx+half_w, cy-half_h, cz-half_len;
            cx+half_w, cy+half_h, cz-half_len;
            cx-half_w, cy+half_h, cz-half_len;
            cx-half_w, cy-half_h, cz+half_len;
            cx+half_w, cy-half_h, cz+half_len;
            cx+half_w, cy+half_h, cz+half_len;
            cx-half_w, cy+half_h, cz+half_len
        ];
    elseif direction == 'x'
        corners = [
            cx-half_len, cy-half_w, cz-half_h;
            cx+half_len, cy-half_w, cz-half_h;
            cx+half_len, cy+half_w, cz-half_h;
            cx-half_len, cy+half_w, cz-half_h;
            cx-half_len, cy-half_w, cz+half_h;
            cx+half_len, cy-half_w, cz+half_h;
            cx+half_len, cy+half_w, cz+half_h;
            cx-half_len, cy+half_w, cz+half_h
        ];
    elseif direction == 'y'
        corners = [
            cx-half_w, cy-half_len, cz-half_h;
            cx+half_w, cy-half_len, cz-half_h;
            cx+half_w, cy+half_len, cz-half_h;
            cx-half_w, cy+half_len, cz-half_h;
            cx-half_w, cy-half_len, cz+half_h;
            cx+half_w, cy-half_len, cz+half_h;
            cx+half_w, cy+half_len, cz+half_h;
            cx-half_w, cy+half_len, cz+half_h
        ];
    else
        error('drawCoilLeg: direction must be ''x'', ''y'', or ''z''.');
    end

    faces = [
        1 2 3 4;
        5 6 7 8;
        1 2 6 5;
        2 3 7 6;
        3 4 8 7;
        4 1 5 8
    ];

    edgeCol = edgeScale * color;

    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', 'none', 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);
end

function drawConnector(ax, p1, p2, width, color, alphaVal, edgeAlpha, edgeScale, lw)
    hw = width/2;

    v = [p2(1)-p1(1), p2(2)-p1(2), p2(3)-p1(3)];
    len = norm(v);
    if len < eps
        return;
    end
    v = v/len;

    if abs(v(3)) < 0.9
        u1 = cross(v, [0 0 1]);
    else
        u1 = cross(v, [1 0 0]);
    end
    u1 = u1/norm(u1);
    u2 = cross(v, u1);
    u2 = u2/norm(u2);

    c1 = [
        p1 - hw*u1 - hw*u2;
        p1 + hw*u1 - hw*u2;
        p1 + hw*u1 + hw*u2;
        p1 - hw*u1 + hw*u2
    ];

    c2 = [
        p2 - hw*u1 - hw*u2;
        p2 + hw*u1 - hw*u2;
        p2 + hw*u1 + hw*u2;
        p2 - hw*u1 + hw*u2
    ];

    corners = [c1; c2];

    faces = [
        1 2 3 4;
        5 6 7 8;
        1 2 6 5;
        2 3 7 6;
        3 4 8 7;
        4 1 5 8
    ];

    edgeCol = edgeScale * color;

    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', 'none', 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);
end

function drawDetectorTwoLayers(ax, center, tangent, size, color1, color2, sep)
    % Draw two stacked detector layers (no strip pattern in overview).
    % Layer 1 (color1): strips conceptually along azimuth (tangent direction).
    % Layer 2 (color2): strips conceptually along beam axis (z direction).
    % The physical strip orientation is indicated by a short guide line on each layer.

    cx = center(1); cy = center(2); cz = center(3);

    rnorm = norm([cx cy]);
    rx = cx/rnorm;
    ry = cy/rnorm;

    % Place layers symmetrically around the nominal radius (visual separation only)
    c1 = [cx - 0.5*sep*rx, cy - 0.5*sep*ry, cz];
    c2 = [cx + 0.5*sep*rx, cy + 0.5*sep*ry, cz];

    % Strip-direction guide lines (short, subtle, no full strip rendering)
    stripDir1 = [tangent(1) tangent(2) 0];   % azimuth
    stripDir2 = [0 0 1];                     % along z

    drawDetectorSingle(ax, c1, tangent, size, color1, stripDir1);
    drawDetectorSingle(ax, c2, tangent, size, color2, stripDir2);
end

function drawDetectorSingle(ax, center, tangent, size, color, stripDir)
    cx = center(1); cy = center(2); cz = center(3);
    tx = tangent(1); ty = tangent(2);

    hs = size/2;
    thickness = 1;     % mm
    ht = thickness/2;

    rnorm = norm([cx cy]);
    rx = cx/rnorm;
    ry = cy/rnorm;

    corners = [
        cx - hs*tx - ht*rx, cy - hs*ty - ht*ry, cz - hs;
        cx + hs*tx - ht*rx, cy + hs*ty - ht*ry, cz - hs;
        cx + hs*tx - ht*rx, cy + hs*ty - ht*ry, cz + hs;
        cx - hs*tx - ht*rx, cy - hs*ty - ht*ry, cz + hs;
        cx - hs*tx + ht*rx, cy - hs*ty + ht*ry, cz - hs;
        cx + hs*tx + ht*rx, cy + hs*ty + ht*ry, cz - hs;
        cx + hs*tx + ht*rx, cy + hs*ty + ht*ry, cz + hs;
        cx - hs*tx + ht*rx, cy - hs*ty + ht*ry, cz + hs
    ];

    faces = [
        1 2 3 4;
        5 6 7 8;
        1 2 6 5;
        2 3 7 6;
        3 4 8 7;
        4 1 5 8
    ];

    patch(ax, 'Vertices', corners, 'Faces', faces, ...
        'FaceColor', color, 'FaceAlpha', 0.50, ...
        'EdgeColor', color, 'LineWidth', 2);

    % Strip-direction guide line (short orientation cue, centered on module)
    if nargin >= 6 && ~isempty(stripDir)
        sd = stripDir / norm(stripDir);
        % Center the guide line on the detector module (avoid apparent offsets)
        p0 = [cx, cy, cz];
        Lm = 0.6*hs;
        p1 = p0 - 0.5*Lm*sd;
        p2 = p0 + 0.5*Lm*sd;

        % Use a light color for strong contrast (avoid dark lines on dark green)
        guideCol = [1 1 1];  % white
        plot3(ax, [p1(1) p2(1)], [p1(2) p2(2)], [p1(3) p2(3)], '-', ...
            'Color', guideCol, 'LineWidth', 2.0);
    end
end

function drawCircularCoil(ax, R0, a, z0, color, nseg, alphaVal, edgeAlpha, edgeScale, lw)
    if nargin < 6 || isempty(nseg)
        nseg = 120;
    end

    Rin  = R0 - a/2;
    Rout = R0 + a/2;
    zlo  = z0 - a/2;
    zhi  = z0 + a/2;

    th = linspace(0, 2*pi, nseg+1);
    edgeCol = edgeScale * color;

    % Outer cylindrical face (R = Rout)
    Xo = Rout*cos(th);
    Yo = Rout*sin(th);
    Zo = [zlo*ones(1,numel(th)); zhi*ones(1,numel(th))];
    surf(ax, [Xo; Xo], [Yo; Yo], Zo, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', 'none', 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);

    % Inner cylindrical face (R = Rin)
    Xi = Rin*cos(th);
    Yi = Rin*sin(th);
    Zi = [zlo*ones(1,numel(th)); zhi*ones(1,numel(th))];
    surf(ax, [Xi; Xi], [Yi; Yi], Zi, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', edgeCol, 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);

    % Top and bottom annular faces
    Rt = [Rin; Rout];
    Xt = Rt*cos(th);
    Yt = Rt*sin(th);

    Zt = zhi*ones(size(Xt));
    surf(ax, Xt, Yt, Zt, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', edgeCol, 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);

    Zb = zlo*ones(size(Xt));
    surf(ax, Xt, Yt, Zb, ...
        'FaceColor', color, 'FaceAlpha', alphaVal, ...
        'EdgeColor', edgeCol, 'EdgeAlpha', edgeAlpha, 'LineWidth', lw, ...
        'AmbientStrength', 0.25, 'DiffuseStrength', 0.70, ...
        'SpecularStrength', 0.45, 'SpecularExponent', 18);
end
