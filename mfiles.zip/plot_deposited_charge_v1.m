function [E_grid, Q_fC, E_peak, Q_peak] = plot_deposited_charge_v1()
% plot_deposited_charge_v1
% Computes the charge deposited by a proton of kinetic energy E
% as it traverses a silicon detector of thickness t_Si (default 320 um),
% using the CSDA range table from the NIST PSTAR database.
%
% Method (range-difference / CSDA approximation):
%   Let R(E) be the CSDA range in Si.
%     - If R(E0) <= t_Si:  proton stops in the detector. E_dep = E0.
%     - If R(E0) >  t_Si:  proton punches through.
%                          Residual range after t_Si is  R_res = R(E0) - t_Si.
%                          Inverting R(E) gives the exit energy E_exit.
%                          E_dep = E0 - E_exit.
%
%   Q [C] = (E_dep / W_Si) * e ,    with W_Si = 3.62 eV/(e-h pair) in Si.
%
% Reads:   PSTAR_stopping_power_protons-in-Si.dat (same format used by
%          make_recoil_table_from_PSTAR_v4.m)
%
% Outputs (also returned):
%   E_grid  - swept proton kinetic energies [MeV]
%   Q_fC    - deposited charge at each E_grid [fC]
%   E_peak  - kinetic energy at the maximum of Q [MeV]
%   Q_peak  - peak deposited charge [fC]

clc; close all;

%% --- User inputs ---
fname    = 'PSTAR_stopping_power_protons-in-Si.dat';
t_Si_um  = 320;                 % detector thickness [um]
E_lo     = 0.05;                % low end of plot [MeV]
E_hi     = 20.0;                % high end of plot [MeV]
N_grid   = 4000;                % number of energy points

% Points to annotate on the plot
E_marks  = [0.5, 16];           % [MeV]

%% --- Physical constants ---
rho_Si   = 2.329;               % Si density [g/cm^3]
W_Si_eV  = 3.62;                % mean energy per e-h pair in Si [eV]
                                % (3.6-3.62 eV is standard; PDG quotes 3.62)
e_C      = 1.602176634e-19;     % elementary charge [C]

%% --- Read PSTAR file ---
[E_MeV, R_gcm2] = read_pstar_energy_range(fname);

% Convert CSDA range to silicon thickness:
%   x[cm]  = R[g/cm^2] / rho[g/cm^3]
%   x[um]  = 1e4 * x[cm]
R_um = (R_gcm2 ./ rho_Si) * 1e4;

%% --- Sweep proton energy ---
E_grid = logspace(log10(E_lo), log10(E_hi), N_grid).';   % column [MeV]
E_dep  = zeros(size(E_grid));

% Range at each test energy
R0_um = interp1(E_MeV, R_um, E_grid, 'pchip');

% Case A: proton stops inside detector  (R0 <= t)
stops = R0_um <= t_Si_um;
E_dep(stops) = E_grid(stops);

% Case B: proton punches through  (R0 > t)
punch = ~stops;
R_res = R0_um(punch) - t_Si_um;                          % residual range [um]
E_exit = interp1(R_um, E_MeV, R_res, 'pchip');           % invert R(E)
E_dep(punch) = E_grid(punch) - E_exit;

% Convert to charge (fC)
Q_fC = E_dep .* 1e6 ./ W_Si_eV .* e_C .* 1e15;

%% --- Locate peak (analytically: where R(E) = t_Si) ---
E_peak = interp1(R_um, E_MeV, t_Si_um, 'pchip');
Q_peak = E_peak * 1e6 / W_Si_eV * e_C * 1e15;

%% --- Values at the labeled marker energies ---
Q_marks = interp1(E_grid, Q_fC, E_marks);

%% --- Console summary ---
fprintf('========================================================================\n');
fprintf('Deposited charge in %.0f um of Si (W = %.2f eV/eh pair, rho = %.3f g/cm^3)\n', ...
        t_Si_um, W_Si_eV, rho_Si);
fprintf('========================================================================\n');
fprintf('Peak (proton just barely stops): E = %.3f MeV,  Q = %.2f fC\n', E_peak, Q_peak);
for k = 1:numel(E_marks)
    fprintf('  E = %5.2f MeV  ->  Q = %6.2f fC\n', E_marks(k), Q_marks(k));
end
fprintf('========================================================================\n');

%% --- Plot ---
figure('Color','w','Position',[100 100 820 560]);
plot(E_grid, Q_fC, 'b-', 'LineWidth', 1.8); hold on; grid on; box on;

% Peak marker
plot(E_peak, Q_peak, 'p', 'MarkerSize', 16, ...
     'MarkerFaceColor',[0.20 0.70 0.20], 'MarkerEdgeColor','k');

% Marker points
plot(E_marks(1), Q_marks(1), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor',[0.10 0.45 0.85], 'MarkerEdgeColor','k');
plot(E_marks(2), Q_marks(2), 'o', 'MarkerSize', 10, ...
     'MarkerFaceColor',[1.00 0.55 0.10], 'MarkerEdgeColor','k');

% Text annotations
text(E_peak+0.7, Q_peak,  sprintf('Peak: %.2f MeV, %.1f fC', E_peak, Q_peak), ...
     'FontSize', 11);
text(E_marks(1)+0.4, Q_marks(1), sprintf('%.1f MeV (%.1f fC)', E_marks(1), Q_marks(1)), ...
     'FontSize', 11);
text(E_marks(2)+0.4, Q_marks(2), sprintf('%g MeV (%.1f fC)', E_marks(2), Q_marks(2)), ...
     'FontSize', 11);

xlabel('Proton kinetic energy  E  [MeV]');
ylabel('Deposited charge  Q  [fC]');
title(sprintf('Charge deposited in %d \\mum silicon (PSTAR CSDA)', t_Si_um));
legend({'CSDA estimate','Peak (R = t_{Si})', ...
        sprintf('%.1f MeV', E_marks(1)), ...
        sprintf('%g MeV',   E_marks(2))}, ...
        'Location','northeast');
xlim([0 E_hi]);
ylim([0 1.10*Q_peak]);

%% --- Save CSV ---
T = table(E_grid, E_dep, Q_fC, ...
          'VariableNames', {'E_MeV','E_dep_MeV','Q_fC'});
writetable(T, 'deposited_charge_320um_Si.csv');
fprintf('Curve saved to: deposited_charge_320um_Si.csv\n');

end

%% =======================================================================
function [E_MeV, R_gcm2] = read_pstar_energy_range(fname)
% Reads PSTAR file numeric lines with:
%   Energy(MeV)  Range(g/cm^2)
% Identical to the reader in make_recoil_table_from_PSTAR_v4.m.

if ~isfile(fname)
    error('File not found: %s (put it in the same folder or give a full path)', fname);
end

fid = fopen(fname,'r');
if fid < 0
    error('Could not open %s', fname);
end

E = [];
R = [];
while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    ln = strtrim(ln);
    if isempty(ln), continue; end
    vals = sscanf(ln, '%f %f');
    if numel(vals) == 2
        E(end+1,1) = vals(1); %#ok<AGROW>
        R(end+1,1) = vals(2); %#ok<AGROW>
    end
end
fclose(fid);

if isempty(E)
    error('No numeric data found in %s. Check file formatting.', fname);
end

[E_MeV, idx] = sort(E);
R_gcm2 = R(idx);
end
